<template>
	<view class="box">
		网站已关闭
	</view>
</template>

<script>
	// +----------------------------------------------------------------------
	// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
	// +----------------------------------------------------------------------
	// | Copyright (c) 2016~2023 https://www.crmeb.com All rights reserved.
	// +----------------------------------------------------------------------
	// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
	// +----------------------------------------------------------------------
	// | Author: CRMEB Team <admin@crmeb.com>
	// +----------------------------------------------------------------------
</script>

<style lang="scss">
	.box{
		position: fixed;
		left: 50%;
		top: 50%;
		transform: translate(-50%,-50%);
		font-size: 40rpx;
		font-weight: bold;
		color: #666;
		text-align: center;
	}
</style>
