<template>
	<view class="user-grade">
		<view class="head">
			<view class="user-card">
				<view class="bg"></view>
				<view class="user-info acea-row">
					<image class="avatar" :src="userInfo.avatar" v-if="userInfo.avatar && userInfo.avatar !='/static/f.png'"></image>
					<image v-else class="avatar" src="/static/images/f.png"></image>
					<view class="info">
						<view class="name" v-if="userInfo.uid">
							{{userInfo.nickname}}
						</view>
					</view>
					<view class="grade"><image class="image" :src="(curLevel && curLevel.brokerage_icon) ? curLevel.brokerage_icon : '' " alt=""></view>
					<view class="vip" v-if="userInfo.is_svip > 0 && svip_switch_status == 1">
						<image src="/static/images/svip.png"></image>
					</view>
					<view @click="showProtocol=true" class="rule acea-row row-center-wrapper">
						<view>规则说明</view>
						<text class="iconfont wenhao">?</text>
					</view>
				</view>
			</view>
			<view v-if="next_level" class="card-wrapper" :style="'background-image: url('+brokerage_bg+')'">
				<view class="growth">
					<view class="info">今日获得成长值{{growthValue}}点</view>
				</view>
				<view class="wait">
					<view class="wait_count">
						<text class="value">{{member_value || 0}}</text>
						<text class="text">距{{next_level.brokerage_name ? next_level.brokerage_name : ''}}还需{{next_level.brokerage_rule && next_level.brokerage_rule.value ? next_level.brokerage_rule.value-member_value : 0 }}
						<navigator class="iconfont icon-gengduo3" url="/pages/users/user_grade_list/index" hover-class='none'></navigator></text>
					</view>
					<view class="progress"><text class="current_value" :style="'width:'+curPercent+'%'"></text></view>
				</view>
			</view>
		</view>
		<view class="grade_main">
			<view v-if="gradeList.length > 0" class="grade_privilege">
				<view class="title">会员可专项优质特权</view>
				<view class="grade_list acea-row row-between-wrapper">
					<view v-for="(item,index) in gradeList" class="item acea-row">
						<view class="picture" :class="item.status == 0 ? 'isLocked' : ''">
							<image class="bg_image" :src="item.pic"></image>
							<view class="suozi" v-if="item.status == 0">
								<image class="image" src="./images/suozi.png"></image>
							</view>
						</view>
						<view class="desc">
							<view class="name line1">{{item.name}}</view>
							<view class="detail line1">{{item.info}}</view>
						</view>
					</view>
				</view>
			</view>
			<view class="upgrade">
				<view class="title acea-row row-center-wrapper">
					<image src="./images/title.png"></image>
					<view class="name">快速升级技巧</view>
					<image src="./images/title.png" class="right"></image>
				</view>
				<view class="upgrade-svip acea-row">
					<view class="svip-view acea-row">
						<image src="../static/images/upgrade_icon.png"></image>
						<text>{{userInfo.is_svip > 0 && svip_switch_status == 1 ? 'SVIP 会员中心，惊喜多多！' : '升级成为SVIP，成长值奖励可翻倍哦！'}}</text>
					</view>
					<navigator v-if="userInfo.is_svip > 0 && svip_switch_status == 1" url="/pages/annex/vip_center/index" class="svip-btn" hover-class="none">去看看<text class="iconfont icon-jinru2"></text></navigator>
					<navigator v-else url="/pages/annex/vip_paid/index" class="svip-btn" hover-class="none">立即开通<text class="iconfont icon-jinru2"></text></navigator>
				</view>
				<view class="upgrade-main">
					<view class="item acea-row row-between-wrapper">
						<view class="item-icon"><text class="iconfont icon-qiandao"></text></view>
						<view>
							<view class="name">
								签到
								<text class="add"><text class="iconfont icon-chengchangzhi"></text>+{{valueList.member_sign_num}}点成长值</text>
							</view>
							<view class="text">每日签到可获得经验值</view>
						</view>
						<view v-if="userInfo.sign_status" class="get_btn">已完成</view>
						<navigator v-else class="get_btn" hover-class='none' url='/pages/users/user_sgin/index'>去完成</navigator>
					</view>
					<view class="item acea-row row-between-wrapper">
						<view class="item-icon"><text class="iconfont icon-goumaishangpin"></text></view>
						<view>
							<view class="name">
								购买商品<text class="add"><text class="iconfont icon-chengchangzhi"></text>+{{valueList.member_pay_num}}点成长值</text></view>
							<view class="text">购买商品可获得对应的成长值</view>
						</view>
						<navigator class="get_btn" open-type='switchTab' hover-class='none' url='/pages/index/index'>去完成</navigator>
					</view>
					<view class="item acea-row row-between-wrapper">
						<view class="item-icon"><text class="iconfont icon-pingjia3"></text></view>
						<view>
							<view class="name">
								评价商品<text class="add"><text class="iconfont icon-chengchangzhi"></text>+{{valueList.member_reply_num}}点成长值</text></view>
							<view class="text">评价商品可获得对应的成长值</view>
						</view>
						<navigator class="get_btn" hover-class='none' url='/pages/users/order_list/index?status=3'>去完成</navigator>
					</view>
					<view class="item acea-row row-between-wrapper">
						<view class="item-icon"><text class="iconfont icon-yaoqing1"></text></view>
						<view>
							<view class="name">
								邀请好友<text class="add"><text class="iconfont icon-chengchangzhi"></text>+{{valueList.member_share_num}}点成长值</text></view>
							<view class="text">邀请好友注册商城可获得成长值</view>
						</view>
						<view class="get_btn" @click="shareIntegral">去完成</view>
					</view>
					<view v-if="valueList.member_community_num" class="item acea-row row-between-wrapper">
						<view class="item-icon"><text class="iconfont icon-fabu1"></text></view>
						<view>
							<view class="name">
								发布种草
								<text class="add">+{{valueList.member_community_num}}点成长值</text></view>
							<view class="text">发布一条种草可获得成长值</view>
						</view>
						<navigator class="get_btn" hover-class='none' url='/pages/plantGrass/plant_release/index'>去完成</navigator>
					</view>
				</view>
			</view>
		</view>
		<view class='hotList'>
			<recommend v-if="recommend_switch == 1" :hostProduct='hostProduct' :isLogin="isLogin"></recommend>
		</view>
		<view class="instructions" v-if="showProtocol">
			<view class="setAgCount">
				<i class="icon iconfont icon-cha" @click="showProtocol = false"></i>
				<div class="title">会员规则</div>
				<view class="content">
					<jyf-parser :html="protocol" ref="article" :tag-style="tagStyle"></jyf-parser>
				</view>
			</view>
		</view>
		<view class="success" v-if="isShowbox">
			<view class="bg"></view>
			<view class="con">
				<view class="title">恭喜您升级为</view>
				<view class="upgrade">
					{{upgradeInfo.brokerage_name}}
				</view>
				<view class="level">
					<image class="imgae" :src="upgradeInfo.brokerage_icon"></image>
				</view>
				<view class="btn" @click="close">查看我的权益</view>
				<view class='iconfont icon-guanbi3' @click="close"></view>
			</view>
		</view>
		<authorize @onLoadFun="onLoadFun" :isAuto="isAuto" :isShowAuth="isShowAuth" @authColse="authColse"></authorize>
	</view>
</template>
<script>
	// +----------------------------------------------------------------------
	// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
	// +----------------------------------------------------------------------
	// | Copyright (c) 2016~2023 https://www.crmeb.com All rights reserved.
	// +----------------------------------------------------------------------
	// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
	// +----------------------------------------------------------------------
	// | Author: CRMEB Team <admin@crmeb.com>
	// +----------------------------------------------------------------------
	import { getUserInfo, getInstructions, memberInfo, brokerageNotice } from '@/api/user.js';
	import { openEextractSubscribe } from '@/utils/SubscribeMessage.js';
	import { getProductHot } from '@/api/store.js';
	import recommend from '@/components/recommend';
	import { mapGetters } from "vuex";
	import { configMap } from '@/utils';
	import authorize from '@/components/Authorize';
	import parser from "@/components/jyf-parser/jyf-parser";
	export default {
		components: {
			recommend,
			authorize,
			"jyf-parser": parser,
		},
		data() {
			return {
				loading: false, //是否加载中
				loadend: false, //是否加载完毕
				loadTitle: '加载更多', //提示语
				userInfo: {},
				isAuto: false, //没有授权的不会自动授权
				isShowAuth: false ,//是否隐藏授权
				protocol: '',
				showProtocol: false,
				tagStyle: {
					img: 'width:100%;display:block;',
					video: 'width:100%;'
				},
				gradeList: [],
				hostProduct: [],
				hotScroll: false,
				hotPage: 1,
				hotLimit: 10,
				isShowbox: false,
				curLevel: {},
				next_level: {},
				growthValue: '',
				brokerage_bg: '',
				member_value: '',
				curPercent: '',
				valueList: {},
				upgradeInfo: {}
			};
		},
		computed: configMap({hide_mer_status: 1,recommend_switch:0,svip_switch_status:0},mapGetters(['isLogin'])),
		onLoad() {
			if (this.isLogin) {
				this.getInstructions();
				this.getUserInfo();
				this.getHostProduct();
				this.getMemberInfo();
				this.upgradeRemind();
			} else {
				this.isAuto = true;
				this.isShowAuth = true
			}
		},
		methods: {
			/**
			 * 获取个人用户信息
			 */
			getUserInfo: function() {
				let that = this;
				getUserInfo().then(res => {
					that.userInfo = res.data
				});
			},
			shareIntegral(){
				uni.setStorageSync('isIntegral',true)
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			// 推荐列表
			getHostProduct: function() {
				let that = this;
				getProductHot(1,10).then(res => {
					that.hostProduct = res.data.list
				});
			},
			/*升级提醒*/
			upgradeRemind(){
				let that = this;
				brokerageNotice({type: 1}).then(function(res) {
					that.isShowbox = true;
					that.upgradeInfo = res.data.level;
				}).catch(res => {
					that.isShowbox = false;
				});
			},
			// 获取佣金说明
			getInstructions() {
				getInstructions('sys_member').then(res => {
					if(res.status == 200) {
						this.protocol = res.data.sys_member
					}
				})
			},
			onLoadFun: function() {
				this.isShowAuth = false;
				this.getInstructions();
				this.getUserInfo();
				this.getHostProduct();
				this.getMemberInfo();
				this.upgradeRemind();
			},
			// 授权关闭
			authColse: function(e) {
				this.isShowAuth = e
			},
			// 获取会员信息
			getMemberInfo(){
				let that = this;
				memberInfo().then(res => {
					let info = res.data
					let value = info.next_level && info.next_level.brokerage_rule || null;
					this.curLevel = info.member;
					this.gradeList = info.interests;
					this.next_level = info.next_level ? info.next_level : null;
					this.growthValue = info.today;
					this.brokerage_bg = value && value.image || '';
					this.member_value = info.member_value;
					this.curPercent = (value && value.value!=0) ? ((info.member_value/value.value)*100).toFixed(2) : 100;
					this.valueList = info.config;
				}).catch(err => {
					this.$util.Tips({
						title: err
					});
					setTimeout(()=>{
						uni.switchTab({
							url: '/pages/user/index',
						});
					},1000)
				})
			},
			// 弹窗关闭
			close(){
				this.isShowbox = false
			},
		},
		// 滚动监听
		onPageScroll() {
			uni.$emit('scroll');
		},
	}
</script>

<style scoped lang="scss">
	.user-grade {
		background: #fff;
		.head {
			height: 525rpx;
			.user-card {
				position: relative;
				width: 100%;
				padding: 60rpx 0 200rpx;
				background: #181818;
				.bg {
					position: absolute;
					left: 0;
					top: 0;
					width: 100%;
					height: 100%;
					background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABdwAAAK8CAMAAADCuI2CAAAAOVBMVEUAAAD/xj3/xT7/xjf/xj3/xTz/xTz/xjr/xTv/xTv/xjz/xj3/xj3/xj3/xD3/xT3/xDz/xTz/xT09jyrYAAAAE3RSTlMAKSUILQ0aEhYeITE2PENHSkBQIa2mqwAAd/pJREFUeNrsne16mzAMRm2/cUCGfGz3f7FDcTPFKHZTN21pq/NrROCYbDvmEUK4Eu/Hsfggxt2OP1IfhuAYdfxuB/CfiDyT0vWA/d4peLd8QEE+MAc0gAw2jrvb3dKCu0MIp9M43vnycXyJ385uGXJ9eBgGV2O/4KrIWBrvAdlSUxsrsWGQH18zTfWZMo2ZAs4wjAcAEMLaGaIhQHYM5Y7y5yIgf2atjTFG+ab9vnGQDgAQDz5L7vgvd7xD7jC5v0PuaMidTO6G8SPljrbcgdV/b8B7IqWy4kOZjmeIwoXL2UlEJrcaycdYamvwPgSOVGwaGJneOBYrTozqAGBmJKKk7PnLGjbmcEvtRK5DmGrFUFNrqL1rLSFqLULTZGo3jAdhazinBa5jElArQusivLJUDIyMRiT6k6vBGKP6r/7L5E5VuePXyR0md8P4ILnj6+U+TaUKyHtXwqmStZDAmZHz+XBgK4cYVz+AHKCyMTGqjxan8XByiPp653Adu3DcSwJIW/JwKLMsMhj/FgBLDfLx+hRcOU+9prXVHmNV3620S33QGL13NeZWSoZq35d/BWcYxk+9cu+SO1xV7vgQucOZ3GtMnXJ3JnfDeANa4AJQ3PnzviJtVjO15d7+psWW4hf+c7xN2au51lMRKS3m2C+EW47H8/lu5oGolG+5yK2yMTkXw6uNl0SLcrH3QLGhY/oewuEgS9j6/PIXKwPqtEpnSoZPqaHvnrQLp56aGRl0XbcvRxqG8Rlyx3vljo3IHV8pd/d+ueObyR3O5G4YHw5RjFELXDaER5PxKbXkLhvV0YqsC7CSO55/5Q67crcrd8P4Ybwmdzwkd9kP7uPkHiNl27BhuSh8mrxwOByP3i97DAMglSq7nFJWwtvtKvXbiZPmt+eAPMw4ckxG05YUx+55fOD220r/SuR4rEhrypUhtNAqJ0G+C9Gn9pTSMLTy5h0xsL97ShlTqqoddjPVMH7ylfvPlTv65e6wMbk7mNwNYwPsdkX9dvHfSz3OpHTc3q9f7vrwFNjmIcNp+VU6IaX9XpW0p3Q3E+PvpiKwjMGDAxCH8QdEdE3KABXT3cRy+fsgE6tVwwOHw58/FaG9nA3X5GgDtjMgeiVoPV/akQVBW99T4x9bp9p3lpIxDJN7W+6pKncHk/uDcneNmMndMDbA4iDVraQVE/Ms0cLTtf1ijEXtTZfcJYFU3PB0wuoxSoCzKI9mYmKMXvQshs6PrF6CMtydQYmKzRhVgzINn9nfv0RVmQ1DjFF5crVOjGMIrk5iYXY2m5mmnhhbv0vtvM7YnVTDeBqxIfD4bLm7p8rd/WS5O5E7vkjus8ndML4x3+rK3fuaRMax0BRRSjpv4mOsJNn/Sw4gChneOW9oA4pY86Aq/8LBUVYLxTDMs5yZVnIOpfIsAJR2TCoTpfIc3WpvljLugA5982/V0eMX8N4ZhvH8zgPthpDZY8Og5a59vN8D2JLcHdZyd8+Wu/uZcncmd8PYNo/L3X2p3PVQ8pWrGBHdxoBdzpso23Ovd+C/iSUxs4hGNmptIsv8iJf8C8B/HnK0UvuovS7RPI7S6+WxrMeaQEq8v9kM0FB0fMPjUBLrUnuMlpIxjB9+5b7sgYrc8dVyh8nd5G4YG0LZvN1yBu33dLTz6iJtKbp8k9xvZASVoSkemKdSieqUF9tPU7hhmUye+TUjE6t5GKYI5/SL/JwhpdaDP6fTPFfESURZyHlQVTxTeV9J3cE9atfH6tuenbGOucRoKRnD6OJNcofbitwdfoPc0ZC7M7kbhqGo2bwsc9nrrgQSG4ammNty1zcL8Wo7+OpEs2x10RzAZpjnlPyVaToe59n71SP3L3ukBDgNwM5VSfab/MvFxUypdbXnbp6rrQt4xYnX2OqNULx4vDFVMU1Ap9pDZx+x/UJH2mUYUrJOYYbhvoXc8Wa5w32h3CFyv19yXpW7M7mb3A1jk3zPK3d+ORDAOZLs66P/z+nkM5wd2S3EWLwjVYmM9wTqd00rcSLi27E8pLa+zgKxL3eVx6A44j3wf7MQc0qSf1Hn0av2lDr7EbT6iIVQDzVi3ts79Qzj+XivWsKomhfV6FHFUtkEUpXRvC5t3m/4fLnjE+TuTO69cncmd8PoA8+Ru/u2crcr903L3a7cDaO7xF1tqstxFVNyZ/m9+j4PHWuV6aRU6y3DNvZ//oRw7dleJGXFkeKNSp4ZEG2XxeSZlKrJ8T9/zucpV9s0PEhEeZw8E6J7nR+8X6XX+YCieB5Q3y8H1JQItB5LJep7aLXZAdj7RqivFsby7YbxDrnjKXJ3T5U7KnLHBuSOttyFJ8gdblNyh/tUucPkbhi/5co9BUB1hAeKbE0xSa12cVj5jQD8hWqB+8i1LtM0z6qWRKUgrrkcXAs+UtJPoS6sRDoMLw25JFejPNkWNx/WrqNhs1OziOaTOwDXR7SUjGH0oTtAimvEtq1GjxIr5FKO4lflNw/IfeD8+6bkDpP7R8gdJnfDEH6D3Acldz1NXXUNhFDRzVjeQiTiMYrcQEqp8jjqPJ/P/FDp3CzUDlf2+yLCI99J+uj7r+D0jCwPvKHn43USQ8+4pfaF9n3Wnnu0kjx67ooAZxhGB5JNUYpWch8ZFdObOtOjYm25S+CXyR3uM+RO30nu5nbD6Je726zcUWwqIag56wggipUh9Is6iXKwcP3MSp/n+0WO4AG9IMOtEy85ct29/uQnEZ8JZ35U/8qH7qPKK2T74zzLriaRqhOPOqyjXzxM7YbxHrnDbVXubrtyhzO5m9wNY8N4X6TKU6pkx9viT0TqySf1ZJKWu47p/aRe/MZPgLqZKkuV6ueuK/FWKZGsZuCSuOEczDQdDiEUaxmwZFMEaUtTL0XkPE7I8GDtVMrxmHeuDxuj6K6neTuj5qESOu1mMx1p/MZh3vt6jEOGYXyx3Omj5e5M7iZ3wzAeJaUUY7OMXcC6Z1jjyHYLMa9s/mpx/MDc2y1GIrWRPT3P87jA3iE6nV5ud/qFeT4cvHA6TZNfIIoxql6MfK5FJ+Bqn0R/5Xg8nzkbA7g24KEnXgWaKpPEURupkGyovzMlk9JQPba8JtA9It42pKy+hmH8Krnjdbnjk+WOPrnDPVXucCZ3wzDeKne4rcjdl/dPOZXAXKR6TZkQHQ6XdmXxwjxjQb0MSBX3Qb22jki0q6seJUeTTZ7nUvUSeAlYpXa8b9YtyrTqspOHn1wTbp9WP5xPqlka39M8gAd925DyV2QYRg+ib+1duQymIuMKPHYkrxixIvcY1UNS7RfuSZYd75U7HL5U7nAmd5O7YdQwuefjU0psc1GvPLQv46o7eurZ+nlaPfhf3hKdbk8E0FWPMuxNwWSM/C1+TQirTI1fcA+g9K/h9ey1/r+dzz21+xEAu6mjsYC0Bq5o3zD+sXe2a2rCQBQOOXwFXNu9/5stI21HHBljxJV1z/unpYJAn+1LOkxOSDkpXUgYgL9Kdl7PS13bWotueKuE+OWb7eWOMP4QuWNjuSsYKXdCdka53LFTuZ/vD47cXz1yD6DcCcljL3J/8ci9mgCgf3wRNiMtMuFiQ/1sIge1V8Rb50jkbGMiZTeZx3rWfhOjLC0L3BK2aVovXhy6vlGRB/RO/TYZ/9PyuF7/MKt9Qsj2y2LbT22pfBi8tDHd9FfYs3kD30zuAV8g97CV3LEjuYNyJ+SC3cg9vEzuTaPnMee0OqyqldqEyBU2C1EDWJbPk4vKgfSyH4+ahJgNgBhzD5PaU3AB9D78bhZ/WmrpEnhOSCTuD4kEwIWXCHmMJEWZ1WWxY36emG5am/uLMLVtaxLbF0+TMrkHLDbODsVDcgflTrkTsn++r9xnOinE6KGAO1S3ZQLVq7ZjrzSES9Hjf3qZLN368eFmEfgmltvMomn0fa7B/JfCV3dpfDtQVX7YjNOpXvBEqKl2Qih3yp1yJ4RkzV9SasfmAIahKIggIAxDXrJ7SsDK+c3BQIyX7081vcQGjqt79I2hdc/8fInx9++qiickZbKb49kdPA+nFPIA/J01zPKxcPe29c4yr8Tq6Lsv6J0cBi/3nQnuhHyl3LGR3BFwj9xBubuAcieEKKaX0XS82/yACBit+puq3WhqP47c/a4aRQo63dUPpWRSCZK2eDxWEyYIchw/P/9v1PXxuIiIrOt/DY3T9S7LSF5JxTe1m+tiyx16S3eL19aTHD876m/cM7QTBbUcffZaYmSAOyGU+5rc8aPkDsqdEPKY3MO+5F7XC8vFfxyPOsO/Nq2S/qKrmk+jJYtkstDvAYhCSiGblLSF0EGLNn6LZEHFXjsgq7I8gvWwmcbpq2xbBkES8sz5S3bTr8f7TS7DcF+EAeX+BnIPlDsh9/Id5Y7t5a5rqLat1FH6/kymaklTuLmldtWqrTuMI3Cn1jWvIJO2dYs3+jC7pe058iZ41HIq9xyleQRuoEzt5b4TQkpRqZqe9tXul/7CuvJpYwo6xqLeIkz2OeAf2ciuWXIPP0bugXInhLyd3OX6o9iz6/qJS21rvoyGii1exZpZONo2aeoO+mVZSPfkhKoq+7i8sk9OkSdG/Zst6Tk0xZOiPAL/pPYNLCGEcnflPoNt5K5flkn6DnLHU+XufUS5E/I8Tl4snM6UX623igaQUsp9ZWqabDhy58idEPLWch+GwyFGc1gji77ezJfBeQR8Ssn2X9tI8XHMk7MwXUVByk9eF3zfW3VaNJDGa1Uslbef2ij3X9DFzkAZQgrxLQpAN09j4dVVsgMufe2UTzr5LrPQUp7cbQbNNnJHuF/ueC+5B8qdkPfkEbkjPCZ3bCH3j0/V3YQaojZhM5pl4kbA6+mtv7wpOcMQZ0onVyLGzOcBnCCZ5SqwpXtoJ0xh5sEgha2CCa11zUAZQsIPGbnji+WOVbkjPFHuCJQ75U7Io2jtomytPdWsnx/gf6o4m34mvHW1PpSstnE4SMlFOKXKTF89IZYCFoUbfzIrIFWc6hzRVRk6sTZkEYXHXrZqOk5x+Lu/SlIrFDwxZD5CIITsT+7YSO7Vd5Q7KHfKnZBdYDtjAN3sBVuEsYfrZklMga2qt32fkQmvaIujeQr1/SLm8fOzbU82nzgcDk0jG+IweSn7f59xlF/NxvF4lIhIQdLLgc1i2+raeNgxLm6fGdAXqV6L5AOLMo3jWFTNcZ4JzenVNSHkKXIPL5E7Qhx0q6fc9y53BMqdkB1z18gd4StG7uVy1+8HxNUnuk73VulryrHbKdPNGSeaU9iHTWnbKAD5xZuc96itU27JTbVsBfcnx7/KgiMBLplKyAZomJadzuRL1ejRLphh4wS6TjftpyklwIh/c7kjQ+6g3IXkyx3byV2h3Amh3JXLlVwBSYZsGvOmVsfk+nuNF77mnvPKAxCrTbU+T3EKFq+csfCts95Sd7NmMwJuoch9kGEcS+c1yYk5d4mQJ+O3wvSCJ9WMIAK/jb28iTJf7thI7gHVt5A7vkDuCJQ7ITsG98kd+5Z7jHGuBwwDzj3sVNyv7aOtoTqfa0PzNE3ZJKf5xvKeGeEGmu1eWLFBXZeqXW6cS6YSchWO3IvlDsp9C7kjUO6E7Bkxpjudybdzq1m5WhVx9b2R3PtuIhhqoW3Nldb18kvtzS1uxGQWmH0KpV4yi1VXWkopr2wjV1ne/6jT/8tDJJ1Pk/SPcslUQq7wcrljXe7hq+TePSB35MpdoNyvQrkTsmu0W8V0oev6S+WxMklWZDIRYmvDfE12N5vG5qpuT+5YGbmDI3eO3Al5a54hd7xO7nUtjS32Sue7MFc8X53xeS/485ryAdo2zohQi3tqMg+NEzn6v71yB+B/Q6HaT4k+qz+NXA+bkB3LPVDuP1vuoNwJeTn6b1QnIPlFcCDn2aCH+5t+2i8A59Mr48XDYfFouJokEIXqxFnYzMeHZsf8+vWr+sscSBNjlFLCOHadr7ymkSCW6hydllVGjFpl8enzlmSSvW7Lv3xFPjdsxguNAdjhTsjbyh2UO+VOCHkDuWOzkXtVq8TV57rzXB05HicHAo7+T6tMmT8G+v5waNuU4iryAFD9F6OulscKkB8204ebaH2nMNy9k5QeV+0AnKt0C/XkD3tnu502DARRWeMvyXB6+v4vW9aEbs2StVAxMTD3V0MEdnLaa3W1GhHyEGxWlZMaU7J/KaXFeMgVvPTIgg1O28g9UO67kzsod0J+TO4okruCZ8ndLpsuPS8lF/mer3/b4q4v64gtUQeaZBiPts25sJky+DiLvlrVctW+uqWViTKEbIa2JmQnxR2A6YxZPZvPzzG4Cp/MOe9b7gEvIXc0d8gdG8vduQAod0IctpV7UBBuyR13yh1PlHuMiw8/+/4ktOPR6F91YiJmnLSxzQHOa7ChnBjLbiznGOtTgvUs1ap9TzqrZ6IMIbfgzP3pcsdLyB2UOyHkm39rcop/ciriAGL09i/Nh5B6/9P2K+yDsLhcSqVyBxD0JV1BlVqMank5QvdTLUakBJg71v1OW5FSFIzWXaKIHSgryKzdPuCpWZDV5Eq1+wHuPUMHCKHc31PuoNwDIWSbRpm2ta53VA6tqlQGF8R4RyDkKDUd+6Ve6+ps7fbEMJjYSrM+ag78jtE5mOnRACk1TXnDo7MNwB2Y8/+Hu+csAq6St//rG4bM0AFCXlju2FzuqJS73NoPyT18kNxBuRPyLa8s94qZO+6Se8rA36+Px+Xn2l1LMV5CvY7HY9vGL37/jtd/7AXjvmrGMV7IGahedi16qyYS1Of/6qFM9Wr39zURQqqxbS5pOS3Lvon1HapyO8CRdVaRaSBk9Ql7dvDLyB2UO+VOyF/eQ+5BQfhUuXPmTrkTshXTNNnjmm/FsCu+yu3DANABjp1NAlm93PUO2nbu67BDYwS+5H9OhJQfU0domV31LwCHwyGl5hY5S0m/6zqcMBGRw9D3VyGRMcoV6hkGkzXgtL+0WievjW5XdVdGfrnPIQZBEvKGcscbyx1vJHdsJ3cwdYCQN5T7JjP3k9CAnIEbQ0WLURDtivZ0hP0pAPuAsADnzxrleZKz1ltyStK9LdYPDwGY29qNretOZNKV6BjXSniuf4FpRe3DMDDll5BnIPaD908MWMhMuwkdlSPnq4tYd/uBkHZ8hdxBuT9Z7mGWO6rkDsqdkAfLPbyn3IFpMgcvfaWcA1KJAcwPANj4dr0jDcH5SXJuWyNhT9m6glkbJaPt703VmUwaGcPTOQh5BimlYSgJdfdzBtS8blKB7/ryyLG+t5FjlPsO5B4od0J2whvLPeXzVWyYjIg9ZxPmaw8k8Uc8HyDOFF9eA3Xqt6Qqslq8Flnjq30YVvojCSGU+3ZyD6tyD5Q75U7IjrFNLuLp3k/oE7fAqtwPhreu90v2dwXDpwTAuP5wuDE+Ck3jxEDqrTkjns0wNELOdx66OgfqFFDSI6lBknXbj5qGaifE4R3kHjaWe6DcKXdCPhjpE7Sv+I0ynZjbHFRqeuBNLcEUTays/Uyy4sgxdb0d33WyhorLjQPfqxsYx8OhaaLNITge53ahrWV0SUMQVL2F9L3pOfSGlgTAA2shCmtLqTx4iZDngDCtyj08QO6Bcq+EcieElOKr/C1n7pciz9mU9l36hdzqKYZAyHkY9DJhucmp67pxzLlZIg4G/r8CE+PfDwQqGyXLXAlgmtYfAWZnkyElf6nVXdSN80IrIeQxaKncvuI3ytgh/uF6N1TerGUbtL7rCw7Sptwpd0I+lI+Ru6R/XWJsr+WuS8AXm94ekTOwtqAKyIkm36SJ9XIX3Qmc6AT5RYk2myVztagOAE1TvjI5X/oRi60rIQiNq/ZeCISQR9E0uJKARLh3pgfeDjEJf9bcftFEPmOpcvN0GO2AZVVnj3IP63IX0AGU+18S5U7IS8odnyN3hAfN3MMnyZ0zd0L2KvfwAzN33CP3lIBLk7VVt9jlcNBLmBEme+ZuFwFnl5/ovxgFsT0QHoRExefyHng1rt8k0wJr1b2u88vtzvdpdkIeitX2IJNOv8kFoki7W8lMkgff9aXH8fnZAsosyb3LHd/LPVDuhJDXlDt+WO5Nc/GPUXffy7c60X+p3Mdxdy3ZXac/YgGAVlo8ctZfgJ/wW7vxdBxTCoSQRzHPH4223Rm2ntdkh/gt7uUmtnJXwzpyt434fU+5P1HuoNwJ2QmfJvdfv8R75tOmSWo1+mqh3HPeUQjKOMYTfX/XcyDnsgfAMKwH3nDeTsiOoNxvyB2U++PlPlHuhGyPFtdz9rStLY5+FmRWy1UnwVt35wznM5wlW6N+/fY0mcvJ65oauTZzB3A4yHrlJWMmpaTHof4AQIyNYP3r+7r1xK5IQ+f6mDU1T9Pa+m8ghFDuG8sdLyX38AJyn+vxlDshz6HrYoyrE6yUVKB61pLfwwLzyrxQuRSzUNwoqUWW+lSynIdl8SDGL83JG72Z+zBoEOTcLIkT53uGIOkyKcUl5eky9bkzgj5X66ox/tCSEHgdU3coU9+zJEPIE+SOLeSOMrljH3IH5U65E/K6fNbMfRznNy/lPsr+HSdc4Hi8FDzMgqr+yT3bqvkX3VFQf2BHc2Ecq54IbVtq0vnBsf6XaJrWl1qpdkK2R015Q6YtcG1gI/L2RutMRcakM6TspG3r1llFlPsf9s5tsU0YCKKSplwkaJL+/8+2C4nXsFjIqu1gZ85DLxThuk2P6bI7otwJ+clckrvbk7s7tNxxQe6A96aiPu2i5PSwbjgy1y5C0BcwcteD5QCS/B4ukFL8JF04SfOQa0hJksjKEwkA7D9H3dF/Oz8qZVIYIfdH67X53A+t21gn59tiZNu5Ln+kFYPa7LI9lfvMNaxqgRjjhtxxU7mDcqfcCTkMh5S7u5/c9T8X6scQhmG9VOf327ZkiEnz1m8CPnE15B9omn7WmkQC+xy1c5ZV3Sv74UC1E/ID5I6fLnd84UC5E0JqRpe2xvhXpgSwpVdgda3WFOV9cHUb9Nl8SLvTdX4GyvwUzyR31bsD5U4IOZTcYRxbInfcSe7Qd7Pa3Dqlvl+qWx8Yj2NptkzXHX035xC0PaZ4S6aSr6Fh+N/29xhpdkJuSNvaUfEQrKRsWWTaVcJkjNll16cXbNWIXOaILspXepy7Vu5wlDvlTshTUiZ3vJjcTwCyTOJgFr6eQ9ynLnJZmJO7lnZkqGoYWuFrW9TjhESGGeDKfhqg5Nox7pd2gL2SjSOEvP6dOx4kd3cHuUfKfQ3lTshDSbL3frbcbueS7NZ7VuR202xdF5frAIRgfBvsKfnkgZQKumsubs8f48rXcv2vMsK23FOavT4lS8rkqsTMyMAnhHljVGnq9ueIwfBo4fe9vPTVXxk6n7w7kgrsP8HdK9kcvZ5FyHNxSLk7rOXukA4pd1yUe0O5U+6EfBsSktJlu9utJ23Hu+1Mt+FgSk0QgaqpflG8OM05jvJWjNw/PoCtCVR9gDiO8tllzzCYtp9wIiX5G4C7OQC+XqfrKkZXC0dfS/IkZWx1T+3HKV8R8gpcI3dQ7neT+/Q6lDshhHfu/y33sx9/fJiNnLpuUcjwfnFGCPNQz+YZIdQMB/sTtXExejE/kSq3c5W1QGGgpEq5vuACNw5UOyE3Axi0VGoyfu02e3tNMSmlfH+NCtcGEZhPBJvKbo+YEnzBiNOryx3/K3c8XO5wbqDcCXm83DHJHRVyx6HlnsLps+vXr1U7pSQ1LtQtW6J+RUn++fNnvnC53CtSgFOoQf8OKph2pSr93QMSKFkSc/Cr4AxCyI2Yt6RYAtG9czDHNrdSLghqtSt7oSplpnLRreXufoLccWu5g3InJMOD5L6+bZ+OvaLcvT91fZ4PO3nTF6nKloLH4jqb4e4x4vmKDHOhqa9IJKh9jqp7MhFCeOdOuZ9DuRNCFMxDO73xru1+aRrrzEYO5seZbKh7eTSBLcEDsIrYyrDMLxKBNyu5a9Kkrh7HMUbdn1S+PxVvAP2Q0IgCjYrXS/umkTyydqKfcwjcMZGAhasyCWIseeAK7E8lxci9Ugm5JTiW3HG13LEvd/d9cscluR/zdp5yJ+RF4J37ve/cwTt3yp2QR9P3xqezr6ztNd3c6H53g74Yy0Ilt86q6JUXOeHKEnzwpxdTuXed9sLoYfnB7982bFLPEMbRf/L29ta24nMAaAQJmQnBn5PSN/s+iqV1ELWEXr58ShbYRzoW7xkmQ8iPkTuq5e4od8qdkJ9J02w5vJFGY9veIVmRbU73WpFJKd85oxHuMFmQu9ruBbMsXH+7b9agSelM3l+jUaZlHfMuE2r01RlNE2aGwbyNvXb2oDzO9V0XJrRMVSh2reZVbLhqzzlsoYqQZ+M55A7KfQXlTgh5Abnf/c5deX93X8zqHoaVumPUMtbWOGpK7+8xLq5hshAKAdpWM98zFq3Hz/R9VTGvbFkr72L/44VDqYRUY8eOVMKK97ZhAaJGe1sV45buU0rmmLmk2bHDxpHVjzjZvhz7cpqhtZI7jiN3t5Y7HOVOCMkDty93BT9E7uO4vNfXp6tqobe3szMWW6bKRkXNUuPem5MrmZIn6zZvsuHx/hMn3FHscCVTrnGaWyWEKLWamPSw3a7sgbI7Ly+tDfbUGK2fY7Tn2X/xW1WaLZEDxlXRRtQWVmnK5Y5vlnv/jHJ3oNwJyUG5F8hdQbXc39+hV//9+/QGvwag5tz2RePm6Ye6Vs6wr1un0vzmTTW0LeCKsbuUl/crpuR90e4wbIAkhHK/2517Xu7uaHLvHih3BZQ7IYckxvhPam3rDG27tYMO5onxbmNv+8EZtKPDlNt3j8UYC0acus6uHIadIAKdMVKkdNIuDzRy+bY91QeAcVzVV0Ttq9QC7z/3OJnCDO10rCQOLO7+BaAT+l6+fZa4SHnk6f0Vp+c7G/UryRFCjiV3HFju+Ha5u3K5HzQ+bFvuuLncn+PtE3JQMP9/WqxkCGFr4hzAtOfmxulho5tms50mSWt8pkqTbYPXkZpMEEEygz5lvfJb/TVz/ID3i7T21ZyPuZ7389yTelwvpy/V90F4ewsTc3CYMCWJpWQKJ4ea5pGZLG2XLByfKGn8TInPUQl5uNwd3L7clQfIHe5p5A7KnXIn5DJPdefueefOO3fKnZDHoBWTEJwFzguAM3hhOwEQwNbhsi6Ito1F7TRRBkFzJXj9yNo9a/Lo8n27Lf/n5Q58fGwMQA2D6WRf6F+Mfkoxl1740tyBI0RFiqS9eroIHXzOAwzDoT7CCHk69uVuf+G15e5Aud9L7nCUOyH3p2l2vO4sKnzbN9O27db59jAkSQCwxrYXkJSxlDmWj4O3V7O/mb3wd02RF7kvaixn9RH5gwQWF52zIVdTqqesANG+LKmfUlXTPzgoEkhpLg9duUzHJ3aQ6ztCyF/2znC9TRiGorbvCNhJv+3b+z/sJugiQCIzkKSkuefXSojBrDtmsiw/Tu6LERnsknvA0eWOG3LH28s9bJJ7QKLcCVmEb+5f9+YuX22arutUyDF+toFppL4UjUV9HtbTpcbMj8tlelAz4PcwCthkHUvuOuse45a7RG2pGuDMgAwhO8OlOQcDhv88p5UfiG0NvWi8EHyMtetXu1JsNfmKEvGaKHNb5GrAisozm+SOZ8od4aByR6DcCXE5jtzxzeV+o/IMcE1jVLn3V5L3+llm5M+fttrAp3qb5vM/ESrNB1SYgQZshP75VkjZPljNwNz+u1YbZUmJ8RhCdqXHiNctUb0+Qz8wyQ/6wWyzJkkCMbglXt0ozclLnenbdSbqYkXkJollK2q9W8GdTjvlHm7JPbyQ3EG5E3JYjid3HFrujWh42oyWZI9x1EbOwGjfDJN/CfTRGD16OzADyJXlKZyEtt0ZrGi0UnstO/bu05JEtW/8Msn8KmXSCDkix5P7q7y5r5Q7HiB3PF/uoNwJOTwIWqndmk8zAG35Af8rC17XBBlbDj4oNgRvt9u2TRuz43z2+hkqKkZu2oI7CXpLlwsAPXc01qQ0GVaGGVa9QH/ibLWVdPDnzzggk7JidKARxPQpzdwbjktKZni/AfpBgBCyEfxH7gFLcse95I47yz3gx9n2c6vcA8rT5B7uIPfD1sPFOrkjUO6E7CrWvrD9vFYNcKu4G6Qpt62FvJm21fy2iiiNlpCcbxDlBXSqjgVb/F10X1HCIOfsDYO6H9NstLg2EeNkD6euM4EX3XDq4+PjfB7mLFdkME6nO09HiWnkfE2X5DQqIY9F5Y47yh175Y6lEPybyR3fUe6BcidkCb65H17uwETuKeml++IE12U58hz1KpP+D5ULYOZX1wGglNhTyhdp/vMGKq+uv0lHGZUIeTnaYVOzxvtAizPaVU7ygevYpqnbPluALRyoOd/+HbkDUClWZ77FAXjStsdqixPsk3ug3Cl3Qh5DsyT35vFyR9ggd1TJPYjcUSt3bJc739wpd0IOSF9mZNUHC4nwwELWctNo1MVGfBbqh7RtXZUxDd7YNsIcHXhmiemNOdEbAmwmj72dnLNGiGcVU2a1ymMcMvNnCfQSVW+Gx2MT322S/r5Ckc/IQWnb1FMtaR3eWUWGkOfJHSr3Gavlnu8ud4Vyr5W7VS7lTsh34Lu+uf94sty1T3ozfVqIfjIraiaxMDd5pg95DWngo/pmOsOr17jTDqdCSumuKtUKlG27ae0qxU7IvortQDB0ncZG5+qKcWG34sXlT6W4i93FXm1tQ22rt2p74M0QB4M3sSCa7Hw/2yHAC8tT7pQ7IYfjP3IPS3IH5b4o937GUvebawXV96RrOZ/Po57krLOwHynpVaaVZfSPWmGmaEJ7zlJnBkBYT9elEScZjXYUmtwq55QYjiFkD0VYiLp0nRt18XXcSNjFaNPuiK2kHk8OfkO9s0Lww9uGLHi98ouP1W3uZJsUveLr5R7uJXcEHEHuoNwJebbcwza5h/eS+ygVspTPA8PDGKIsfh1ztfgQ91Kl9/KenjMkhP7+/a/CzOSJAbIbVCklXtno2UaqW8YK9m/upK8PMgNNCOGb+9HlDit3PETu0DH45eXOtHZCtgLY+LMNVvsTqVZm7hiBoHs5+KthrZMXS787Fl0aabw68QC8NryC8ABi9L5uj5leG7kP3YkxqpaBnK8iM1GaprnW6S1lUkxS04gul5Sk40MLVUziLaUcMuSRswwOgRCyCwTclDt2yx3hsXJHeEu5h01yB+VOyFvQJ574XlpIbFeP2nx0P9mm+gra0ErhBz+qs5ASZEcrIVQta/W+rufVyR1IaWLq4fs5A3r18OsXMLrseK41y99aSnpYAzbrgKYolnKEhf3SsRiPcCeEvDpr5Y6jyb29JXfUyT0buQtfKvfwFLkHUO6EfFPWv7mfjyX3F3xz1xjOZLoUco7eZoxB0R9y/vXr13hllDlnG0DOqedLNP+ZNnnozQAJeR26rlNd2iLpfumANVOspsqjGQlqG9IaBFb4Xse2b8GqV/S6Y2cItGDBTrkH3JQ7KuQOyp0Qslnu+AK548XlDpxOV7mnNKmP07b64zUv0kRpUpIOyN8LAG2hFNj6wMI+zT8tVgPII+JCJULuSc4qNZtNUp8Kb6LwJrXFCNwfUmxOjXWyTYYxaO3a2w7Xyi11EZk+1u1t0WSP3V/ueKLcA+VOyEtzU+6hWu7YLXdtaJXc8WC540ByxxPf3APf3Al5bW7JPfDN/a5v7mJqR+4pTSZoY5xMEM+i7lJC2bH4qIXuL+Ge6I5NKSXt1n3qTx4oSYeQb4SdvLI7S9siivXJNkWoHQk0jcUipj7Vr54NWrPAOLyuVxC11w2FgD6tiW0pd8qdkFoo9zHNgtxxB7mHe8kduM4Px3i9D6krY9bF6jWkRXW9avvjY3SnTaP3YgI7j8DWAO66bpWW0UqdntGeT4SQ+5OGRet+8kx9akvOuZSFYPjakcDNeF9qSE7PdQOEzhBX9apZkwjvxbiHY99Q7tgndwTKnRCPV5I7wkvIPbhyr1/CivA/ubfCRO7S0/N5fHJKaXz1j4+gXD+SgMxU3P4Puvj18TSyVDZWM/zGEUIMLyT3/7y54yBy3//m/tZybyl3Qo6G/XemIQJfjQvLkxZzZFbssIdw1ih5bY7Mwv7apSwMKN5d+sUJYoy1aUWaUGP339N9UpuJ3OUuL5eRiQX9UVw/W03UD3CASXTMeXYh/XsBpygJeU8OJfeAV5X7Zbfcg8q9h3InhLye3Mv7vbn3pp7IXXolctfPVe52W1W5xujmxzOx6nr7AzenI+QdKbIVm6NGYX9mpAi2VJ1vBW4TIKvWRWkSSlcv/JRS7YxDkcVPXoduPESVNyh38oe9c11uEwaisLSHm4g7bvP+D9sq7nRtViJLMb7A+X40g2ouwTOfFLEcEVLj9eSOhXLHXeUeXkTu+O4mxmhG7n0+t5G75rGL3Fznr1+Tu1J7pHq9pNLIF4MIORwVhw9DSqmk0mr8rve9KJsTbAXuT4wUkfLETmV16orwU6pOSlm1l45RusBhGL46EsqdEOLmpeSO15I7wgvLHcA4Th6oDkNR7k2j+ta/L6QudyClmVkaQsiR4MidcieE7I22bVU/c1ZSt3hWr7OPTP3Lgfhn4WOM3iwcPb5X+CnXw7h7K/NMt3a3Yuwz/7SsQZb6fFRELvtfzpQSgEtD/lK+dlfmXC8CXPVJjNAl5DgcSe54KbmDcieEbMdHtbTbPd2enVk5NFArEPd3ECL1z5cOnwn+41eFrwq1zfYYgD2h3q2NR+6g3AkhN+Aecg/3kzsWyj3gDeU+juNtiOMPDXe87CIiunH5ZJd/aIzkJF59biDPWXdCDglH7k+ROyh3QsiGWP3UJVB2OELFydns8BfPNDN5Bo78AL3yYRh8n9er9J5VRByLe2g6TuWW/1W3zq6cz2fAyl3FnBvyeezXZje1z7D/J8Jad0KOQYwBRUV6Z18QQLkXV26i3AkhT2LIhMocg6Hsqo9qM1ASmzsxXiPX/RMveuXuzy+IyImx1Bxzs6N7tHLX1MbPz88QjNzHEdDmOF1WNbg2L2dRmDBDyAHoVssdZbnjPnIPLrkr/yN3vJPcQbkTQtaN3MMdRu7hyCP3j+/lnhJg5C7yT+7q4a9Hrl1XVbTInOubhnIn5FgU3ZZSyb9VDYYS1bIUYEFifKXf8CbG62krHUqMzpQDW1Nj+wHb49kLdMgd/yt3UO6EkL9godxxBLnr3xyby/3yr8pdw9mt3H9pEqTuap6hzke8a90kIWTPFN0GiHiFH2MEnA63GrS56P5wGH9ivHOixnYQ9leC/zcFUJoCuq/cQbkTQipyx7vJHUvl/vEkuYe63JsmX2tJ7tokItnQaus/0zJhou8+ON9cyiEGfJGJkOOw/5E7wrNG7gGUOyHkGaD853ll2eiFwoe3HxhHPYYJpDQgrEyMn39DaRjcgZf6+pO3wP/qGD9/Arg2MHA+n43crzu3mAmT1PZkbO7b7DrGhxGyX95Q7ghPkXvIcsc6uWNe7oFyJ4RsWAXZdV2lUMYbAp9SPWzLvyi3esuTT9A0ntJ5xVE6b8/qL5gEULmDKveJctv2dDrNyj1vRdOjLZM7yyEJOQRHlTvWyF2h3Akhr8lR5X6vkXuj1fCbyx2UOyHEgeaDT8gCKSjY+5ZO3/dG+Lr4s7WpZ51q7UvWJsZnvO9F6S8k4giG9zxLtduq3Hzfxhm5iwDL5K5LN+nm7YcJIbtkL3LHU+Qe0CyUOyh3QsgjcFrclr2rbeDoG1RcdtIky9c2V+ZGRKQcK+YqnrGqtqXzK6eHADiLZ4DTaeLYlNq2vW2KMYpcf1sL5Q7c3naITN9gJYTskC3kjkfLPbyS3PNoHqikYz5d7giUOyGHgCP3TUbuwTFyF2maiZBPJwDTplPf++SuxevtzLcRIx+pEnIARHwBj5VVslPyrrpqmo2sjXy9i3JXg+SLWewpjeNYdvKyDiLGRan2IUO5E0IeATaSO+yJ3kLuWCt3zMgd9pZGlbvWRt42nc/na22X5W4ekVPuhBwaESm1AVZ9KSV/hXxYs8KH1oM4mgHMBHwFb0V921bTyVpHOpmzkodyJ4RsjWoBz5M7jiH32jKyTZPSd3Lv+0sIpDbNyd026A6ztZGEkH3BkfvjRu6BcieEbIpVrm2zjb6aGqsem0Xgf/RoH3f6p9sBrFiU2wy4bfC8v4MoX+Iowx9utN22WeTapFEyfrmbT9gdkDsmvshEyJ55QbljkdxDXe5hldx1wL1W7ng1uSNQ7oTsm1LywDBY/QHw19QAsLuXpCdS6huaanDM6tW3RaTvKzMs/srIWM0ncFXyKLHpOmCi7fzTNMlKuXfT2HYRodwJ2THbyD2sljvuIPfwInIPlDsh5DveQ+4cuftG7joXVJI7kFJJ7vql+eUOoOsod0KOQ4zetliadwaqye7W19aFKVXW2lu/JjXgdXKXuUfxTEppUSXPI+XeUu6EHAvK/Rhy/83eGWi3CcNQ1PYjBjsk3fr/HzvshSlDplWXZGPw7jk7XRlg4p5dXCEkrtwJORjtYIlF7nWbLaSiWzrZha/DN4Kp+7Y+h671bq4ag/MXi8+shpjcTxZyB3KeN1WHi9zF95KlbpW7DLVejAZMdSdkT1DuVrlL2vujcocD5U4IUVDu/3jljlet3OVPpZ8ok3dXWW0YTifZ44lyhwuMzBCyH6A9MejWDbJUVMZWMosxWu8gKzF0a7X3lNJq921rlkwqam852VIxXvD+dDq1rrv1+AGoH3Jjcneg3AnZEVuTO44ud+9lk5hcTFy+PkXuOvHdszQkIbshxgjooIa1m4fV4gEwZM2rw/UV6S5NWtb27tsuFtqF5O3Z6uvFZ+TkuqwY5U4IueOQcscx5A6k1PfDcLcpJWAhd++bPw5ABjPKHeUYyp2QfZL+B7kfZOVOuRNCXlbK3S53ADkbtskzUj2IlmqM1mrvWBW+uft22dvQwVuH2/XrUtYQ/zAsZnzx9LSOIZtC+On8ttxVy1Sz3GUXyp2QfUK5P0PujnInhGwLm9xjUYc+0l6hQJcoeLylk1X4kkao82HsEZlutbmSvT5BjFF9asjtMKV58BBEvvXPQu6SzqQ0/YjcE9sxEbIbdiV39zflLuH2x+TuKHdCyATlvq+V+93M+jp9Su5lYGleK75/rtzlCSshZA9owQ2DeElpQh1pCq7bwugpmfv1tVv7FdEaQ+WnYvz1MpD2cHt7a/dBlQPKnRCyAuW+DbnDnR+Xu/d3x4Wg5F5zI6XCr13u9RCT3Fn3l5AdohWtNpjl3hfUtmEYtFlTag1iTpQJ4YFKNWqz6rpkzm5vbwbQLiu2uLl47yl3QsjMhuU+vELueIHc8bjc4UbKnRCyWbhy387K/XJRPwM/sZhG75svE3jfSnyn3Ak5Kna529Wh7Wzv12d/JUq39jMXcDfI2rTzpz3/AAxDjPF8vlwu57P3/vv39/f3cZy+/Vag3AkhM8eR+2nrcnfPlHvfz3IHUlpEauQpt3RYFZqJ73Uvyp2Qo7JluW9j5T6u7gzKnRCyTYDmQzfDozl7bz733CTKodByrbVSTSjGX3l0aw/ZA1jp2AHknMNPxsJk8xBijNfr9E01fPlyzgXn7jzuvTL15aJapfiJ5tRT7oQQyl1RxkfzskC5E0L+M/rCp/+9c7ZK21C1QDz1cZBHXsrUEtYXaEiUEeFHu/BXzouW8G/UWQC89103DVdF33XzZ/EFYNL8t2/X6/XuAqRy5a/q98D1qqZ2HGOk3AkhT5I7KHe73OHgPpP75atyB+VOCHm63MGV+2tW7lJGLQQ1t35CTff7u1OY5A4gRsqdkENgyHmxxtJTSvpU9vwZq8WzvV8fAFttx5rQ0hqr720JOABqGB2Y69Pcrqimx8zPCEKoXq9z9fb2VhNgKHdCSIVy18Z2Zrm7vyl32OV+PsscyN+K8pXcm2/RNm95KbV+j6LcCTkEKkRikrteLNsLR9r79bWN7a3RF2tIx6EaTp/B3H3b+0nVfT//ZpDSfAlvb/NNI0aJ5YzjeBuQcieECFuQu4Ozyd10JNyx5V6/03Kvyldy77oYLZ8rBKA1eZQ7IYfgX6zcPVfulDsh5LXk/EdyH9Tb7la555T0gOtH6qj+qd2vz3AxQ8FZO3zYhB+j9/7WhKNG2uXw8Zay2PfTP9xmq77JlHO+XWM9W43syyxLUV+PiZQWEh7HYWhMQdPalDshh+X1cteCbq4ocXS5wyR3UO6EkJfJXdRrry1mP9IefxE7qYH7vrcdru4Xlu7bslffT4fX/Jl6hAj/dh+o6pdi8SGEnKvwZYSvrdxBuRNCKPenyt0t5X5eyB0GuWeR+23/mBaZLEA5YdlRisxIXH4l44VyJ4RQ7i9aueOPVu5a7o5yJ4Q8SEovkru9IGQtomgoQzkUrAXfWwOb+/VVWbdi8/pV1/o1RvkE3vsqfO+r8AHchB9C6Pv66X0xtGTLqHmJsRy5qNjm/S3+EiPw0TzLOT7/CZ3KPFPuhOyRY8kdlDvlTsgxkMjJg3K3l3wPButaqxFUw+oR0LT4gy2dAMgu84FdJ42vpb+2CF/CNwC6bjpSbhEp3U3Gb3+t++hnrK5sz7mZ0G7z/amRukS5E7JHtiF3uB3JHZ/KHZQ7IeQHe2eg5CYIhGFhEQTPXvT9H7bBCdkkS3qby9kz5P9m2unYQ5TOfNB1WW5pUu5vv3K/qm48TX1fkfv6XpqK7Pry7mv/kDsALRKCCGQr5a6YJYypHeMcFHJSXFPn1PA18cj87ooi8Gz/0qvNa+zy2n1fWo7jhfBLTfgcsl8D7/zkq/CfljtB7gCAF5Y7vabcO/pC7mKAYxzHysB/fJz0b61m3U4EuQPw1vCS8Qm5q0q+60XOKTCyjrsMlSjSf9akcW29+Ltp7yzrkrwzTVMI5ZFZ+M6F8+XxHKhJKXnPmTdF+Pzd4dtyJ8gdAAC570DudCt3HoMcqo9RjGrfT1NtoHmk5JvJf2jIHYD3AXJ/TO7U/cTKHXIHAGyOtfYX5K65+fbn9WkD+0QkdjIdD7cuIXu+HMKV8Mex9OWc/OFV+FeFv2LMYXmh7tyZ+MbKJzjJV1PkRvLuMdG6AwC0wC/Lneo3p33Jvfun3OkhudOXcqfz42wr964mdwu5A9AG28hdBlfqihnyKdGawvDag1dj/PEjnbyXcaB8mJLhdqWnP3+89zd3G4YPLtNL3ejK/iHn8g/z2OUUm6shKluM3BE50HlMxNjJQeZnVES1/FqpDADQApD7JnInIfcSst+z3AfIHYBmgNz/68odcgcA3OFF5N73fe0oaW15SZnTo22p+DlOipE5NfKWoi6B9/5wuPiBkyLneea+xrEs1YvwxYdX73lUssCvTsvmP+b7WysGehjKbaWyq8U/tRXfAQBt8Mpyp93LvSPIHQCg40XkHjLPy51vrmmp9dVDRzqJRJllWYhuFWvt0ddC+Mdr1tbCNzHGiyoIa967qMNuTP6VH0DInaiuYZ4HxLtB7gC8Fy8id2pE7vQzcu8gdwBAE3LvqA25y5X7/MeY+jCaI9n1Qu71BPe714cj1Wx4yB2AhtlA7pwHI+WxYWH4vmdjiqqXIiVEf14fR+m5hBc/WWm+LLLapDFS+Ov2p/XZIXcAwAWQ+w7l3j0hd++rwxhjnOdKSeCUhMLFMSXiLXRBmRDy0AMA2mBvcq9V/jJGV/Ds6RM+ZIUCuUT//JSJMp+fn3wckzElu2ZZZHzHuXEc+QYPyp0gdwAA5P4Scq9mLIZwXN9ffr7gUR3GUSqcw//VtM+O4f8foSAkAE0DuUPukDsADeK9J9pG7upsmccVnb1LqpZPZchzC46Xh8B7mtLpVed5FrPE4XDoe66AUDR9OLDKWdqlcenZ+1PvYl9TmRmEra3V5EZyTxJ8TQWgJSB3yB1yB6BBZJ6IzFD3/kalkQMIIprCdxmGp+Qur+lP/ZCPwE9+1LJiquBAChu774/xFzkdsK+HzOlhxnGsZcj3Pc8N8ntm/t05ojXLR7xsCGv3EiJjdLmR3JOcHvA1FYCWeAW5m93LnSB3AMC+2L3c6dsr9/615J6l7lypAixeNmWqDs/NOgF/8VUXBQYAtMUXypUbi2TJRzkj9LnRE3LX34gzwPXBddmndJ2sez7PZWLgDVMppXGUjZZFzhwfHymly/kCcgcAXPHrcg9fy53eWO7UEeQOAPh1jKkZUF+GV594bsxWCfOe6yk+J3cZq3KO4y+1JfrC3Z0t/uG9zJDn5lm6dDuFnaoScCOuoJD1HUK4s6/05qIsgyADTpUJAlnuADTHNnKnV5F75UH7mtzpO3InyB0AoGUHcies3H9u5d73zq0bUgtXWwTsyukeKYn3viPlYYjxXmINctwBeA+0cn+80U/IPaWkfWR5c0WRSHZyrSUn/TjnUro9czsH3MebMDqRyKkpe5rKLWMs8xbkDgA4835yp4blbk2MN9WKnbuQN9eGlOejGjMMd9Seki7xnWcNAEBr5IVi2K3c+Ueelztf0LY0xoj4i6sFajinZprKDMIVCryfpomb8y0hdwDAGch9n3LvviF3trk0bYzOhWBt9a2HodxH4r0MyXBHSIME4F2A3DdauW8vd3pc7gS5A/A+sMK4ouN+5c4xb9m7jK/r5S4zf/hvh6HYma+FEMq1elJMbRLg8gfOWWsrZ5waQ2SMcy7/XEpEYvh4s1ONlLy/8xdJJkGW/gEALfJacu+oe3O5d5A7AKCOfo8S634vcici72XvupLviinAGBmwmqbi5BhJFHf33odQUtzPMZk+xlOLOI5yElgWOSpE1s5zSjJgUnLvs/jLa0iI1jmhRox1hxMhDRKAZvlS7mFPcu+1cu92LPduN3JHjjsA7dLqyr3br9wpy53zG4nWUExKxhDJb6slqOJcXeyln7uetnYY7uZGAvCXvbNdUhuGoaiN/FE7Qzu8/8sWU9zbIIeYhkAg9/zohGxivOzMsSsUiXwrs3LHGW1FSHh9uaNOZPfS0v9b4U69b/63Lfao8oBurjeVZ4Oe21gEIHcjB8qdEEK5f5jcpSV37twJITdQ7h8m9+mde8rFyTlnDD+aHULxpxDuPKtgrW4xhTnjR7qIvCGEfCuooNKjQVh3bgwRWUfujTi57evn0S93HHnvj0fcUT2NYjJ1jjiHeYdwFnm7/IyWu1DuhJAn4teSu1lD7vED5C7dch/FYaxVtWPsmZT05zB+WHU6U937ycCLo9oJ+X6gDuSEPGrdie58IATv/YKSv4vCMrFg+rv64WgYhh8/0F+7psqICMa4BmVwrh79+lWPUlIVCl4ld6HcCdkrm5a7bFPu5q7cTYfcdXFGHOXj0bkY258cwjWoDNnisjC0ca4MSQj5cjYt92/euWu5F54jd6HcCdk9M+7G4/wL4uW6GV8IQUSvKqqB3jPknsrQpmstweSryNXb1KA5xmiVlRGRdp7NhG5rMcjDAWPgR8B7W8Dsm3/R6aLAIsyAJGQn3HpCGnI3O5G7rCt3odwJIS+jOq2lS4SBbzXYL3ecUZUEdP78/cRHMZLzgoLznVPGUasg5DAMyMGpwZuckThUz6WEFammuKNfnwEh5GzPeI8A0O08f/w4XFCLWyNaUwfXhMByMoTshuIbeVju8ha5y7bkflhf7kK5E0I+aefuP37nLmbZzh2V2X7+HPdRdXhRXH0hxvm/oypRoOpGxmgIIXsBT+J09NrDBnqB3HsfbBKMq256hdxFqmix8AxDjLFeJYLKA7hTVyjAOcyIcieEjNmP3M23yz1G506n00RqUkrlp/XVvfIDF+5dKObyHSwhZF9Afogj9AsU8uuXe7+n15E7gkJ6gohC5VzzwTF3VCPQ+TMYw/tRng2qEVDuhJAXoeUXv1/usgW5l4eQUooxqsnHWFzsUfhHEePhCm5vUMei2AnZJfvbuVPuhJAdMOPHB3vtIW1ku3LH9PQEERgZBh2gP/tZSbse4UmtUrP9x031gBJhEZx7tdxZJ4yQ/UG5v0PuZ7y/DowxL7WDQ8DTqTqPHckz81q/VI0khOwUKVbqlipqBTwWuSlsRe5YrbTccbEq5Q7fjvJnWnXEcCdaOo3GoNwJIbdQ7u+Su7TljgrA0i93HGCex6P3Bp9YkTy0fibnub9kCIcKk9oJ2TuU+/N27pQ7IWRLtJpgzz5xtLBL9o/C2+Tu/X25Q9GoEBZCqDPGrzsM+o1PJ4xal7Z6ndRzbjAgBOcQzx8Nl1Jybkrr9Qp7IWcWaieEUO59chfzTLmLodwJIb2s37EDcRhc0BHaWZxi8za5+5KrjrrytfKXCGamu2rXwXPWNcO8r1XXrmOIN/jms+Q2Xq9AUObP96d+Utg1BiNsiEoI+TS5C+VOuRNCvk/uW9u5myfI/WZy5ZoY8fFd72gVecQv4Jy1jMEQQmbwPqXUXT+gv0v2QjF7fzblojSd9lRjoXUVCl7mnJ3DO6D840T+DFYm55yaW6lGgLeh3AkhE1DuD8pdXit3mZE7FC0iGGWkdgNUD1WmORJCOsF+E7EIP21zhBz6QzsluTw+LmaVyR3up6yH0NNpu11+IJSb60tr6yxRkB1XIwSD23E9jtDSaULuhnInhADK/dPlXhuiIp0S/2VwbiIWk5IhhJBtyT1S7pQ7IeTFoGucVi9y+O6ZeGY5wBll3V65t3VvctbBfq1yldujx8XgLbmL1Jg7FpRhGNB1D8uk6qqdc759OgypkEiC9N45X/5pZD1ayxpghBDK/flyN6+Uu1DuhJCVkt0hKRRFeSj75WI0eSjFJqXuBQL0XaLP9MsdrZR0EyYR3F5z2pHq00qF586dEPJCZBW5i6HcywcljY9M16tJqZ4Y5206x/QYQshKO3cxwp37/+/cKXdCyLuwdqYXnXM3F4QQ7shdRKC8B8S8Kbkjgl9OTOXP4M5S/nGYKAKv5e59zrlmzJRlTWS0ppaX5f0JIYRy/0S5y0jugHInhCwmJbmfD4Pe0YjczCXU2AXJ8bjj9XLPOVuLD2VG7ki/PxTmSr7/bZD9N53G2sb6mfNv9s5ly00YiIIyLUKQs5n//9kExcrNuBkaDmP8qlp4bIwbhkWhI7evui4BACD3b5O7Se6WkDsAPDPI/dCRu1nOl+teynVTZDI7n0l9BIDdyFqxNuP8gHgHnzejI8RfBdxQ7kpKOJ2036zc+76lPeq2l/M4jjqCVtquSv/3VofcAWAJ5H4buQ+3l3vOl6fD0K7Fjx9Jv1lKAAA3SQ9TzPv6aRYVWLVAky85jqPZqiWd/HLe++VeStG7X8hd9cexdcacTgrr1QRNuwQfH0p4aKkFyB0AAu4od3thuduN5V6paQPtUv0rQtIAACRG7k81ck/IHQAORbIOY969JH00pNizYodG0eENYjkGspQ1ctdd4nT6Uu61+E9tcXLXu+1ulfN8vHtdh0nfn/79m+tWAIA3kHuy/XK3h5Z7Qu4AcBskzqh1PZRkuMOmI5iVUnautK0QAd/Ur9NSz8uC3Ed9spuYk7t6euq5dZ3PG5PaK1J7AgCoIPf7yt2QOwA8PsidkTsAvCBuhtvHvHv1Ond7r8a9LLG74yae9TXMWg2ttH0JYpfXa66lpvHb75x03m1BbcUK1G3aa17udb2+T2qfXgwDze0AcAPUm4Lcv0HuhtwB4JGQgxZmOIKGml0dN2Yr3H1ykQRr5L6cPj8pt73X+ue7TiddF8b+JPdhQocbx/Fy41FxL/dhqN0yTu1EQALA7bC3lXtC7gDwwti7yv0+I/dLW3vfMyUDADfDu7g5zllxqd1FBbT/no6bYf4Udv5Wym+5knu9FOOonc2slE9yr/EK9eFTsqSTu1+vD7kDQAxyf1K5T2a3qTBqB4AZkDtyBwBYps4sO93v6GU0sx3tlNoSzdvHn+iX5X7VClkzYC6XQiEyn+ReH3TBluQ+NU2aarRvUltoGABAwCFyN+T+fXJPyB0ADiGeV+nWN9T4gn7SJOfsu18i3fuXO28Q/1a7tlJaTIBZKPe6xctd962u0wmqRj7/rY3aASDgKLlb6pA7cgeAp2NZ7pYMuV/J3TbL/UImKgwADkOylu02yfrkwiV9BqN76U5hcfW9rRE2fotdL9A0qdz+v7X8qrPw83I3sx8/1Pvi5a5Wo0jurM0BAF/z9HK3o+QuunvLvZTpwgEAHICXtbe5Wk/Wd0t2y7/9X85st7g5XiXV9LNtaifn2rVTox7bQtZ97+Wu+qHcp1KG3AHgMThe7imQe0LuAABPJ/dkkdztBeXe96UkAIDD8CLcKOtqtK3q/SL0QBXC7Mg9X8oqW0D/Ws75ol/Jenqmak7uetARkDsAPAozcrcXl3s6XO50QQLAkcjd6xMCWniWyDkMNdjQUKMd4vtFPG/vS2ohveX1T83aM0n+fD5fyb227iB3AHg8tsq9/w65p7eSe3cyGtwBIIKReyx3Q+4A8OaE7S4+xf3qE+NoQcy7D6zpdnTcBAPz+WNaLak0glDufd+WyJPu/4QU6ARrIXU41o+XMif3cUwAAAHPL/dkd5B7Qu4A8Fb0mlnYE90VDpv3pIdpKiheFjveoZRyKbkk92FokQT6ZN2iEzSzj4++7y9blEGgjsvp0gIArONguVs6IfdZuadFuSfkDgAbebORex/J3Ri5AwD8Zu+MltOGgSiqdh1s46EF/v9jW2nQ3IYN3qpOioBzXpLIsiTn4Vizs14Jec99ArRiyqKwNbnrfSGbrxdYr9ejOL9GcNUp4y+ftFpFxHW1LFq5QrtdzY3RnTUKrzHOZy1Qbwm9NY08GQBoAbl3I3d7L/fvyB0AOkH2kkrDGIdzsTVl3AzDxtKQPuPGzHVwsZ8VucvwlyVPBT1sVvlZD5Qyx+OHO3dNCABwL/yu91/knj5V7ta13A25A8ADwM6dnTsAPCFO7j7InpUXlIYMvkuKEmr26+f7NeT0rHfQBUXVJfcxowWWZj3s6XQqV83qYpbFy11l4DmeAwAa6Uzuyfb3lrshdwAAoeSVIA7jgiCbqrhL1hogPAIqqtkePJXkruwXzV4uzHOe9Zbcv2XK4mu60LLk/k7umh8AoBHkjtwBAFaYkTtyB4DnQ6VbnCdbDtfbnO7iOzTPENeO1LgflxMws1DuYyapJSOll4byG18wAcA9sfR/5G73l3tC7gDwSqwcWh2YNTgdqeWEJ11vPgJKFQfiAmYa93g86s5Li+6tJQS83Kfppty1rHmekTsANIPcm+WekDsAvBgvIXdLyB0AXosg4B1UitQYQdw+SsAM013ChBrfwS1Bj7Ysy26n1J0ShVfXOue7epLltadxP5L76YTcAaATvkju9lRyt1a543YAuBex3BXzaJD7ekV1tWyvHuZncC1e7rr9KswyDFnbTu4KLJWb/pR7fQVpJccjO3cA6IRIm5aQ+9/LnZ07AHRCKHd27uzcAeDxCLQZJ9TEY8RB9re3MFE9dwgybqKPrzKqyl6uS9ZSeflR+gzDoNkvRQr0qVN9cK3k5886eAIAaAe59y53Nu4AcD/a5a4uG8eIoihJdbzUIUqoCdPvy7JqVfbyjlIZNC93FSkoOTXlqfb7NbkPwzzPhGUAoAeQu92QuyF3AHhcXl7u6Zbck/2T3MmWAYAe2Cx35Zy4DhuKuruW1tKQvkUx91KV/ZIyo6v1LG+1nU4nrTb/eDscbshdLwh27gDQA8i9Ue4JuQPAA7Dfb5a7bymebBpjjuIwpZJXU0KNT7+v2S/TVOaS3N95Wm3n81n5QZeWZKmgNHnkDgAd8mVyT08q92TIHQD6h507O3cAeEJ2OzPbIPfQxPEYeiO4IdfGyAq1hpO2zXIMXXfmjJtluS131Y7U4XqHg3buOhZbY5R3FMfsAcD96UTulqxruU+Se0LuANA/JUThC7i3y921+GmaQjtvOaflM6uHjePh4mbddj7flrvMrZ17Lus+rsg9qaIYAEAbyB25AwAgd+QOAK+Hs+6UW3xwe6PczSXUtKbpxHIf10/33mXm+ao0mMaq1Smd3PWRli9SoIwbyf33IpA7ALTziHJP9ixy/47cAeABcKUDxoz3vxdzLPc4oaa9ZkF7vr3+KKu4KjCgeu51le/kXjJu9A/QZfX68cPLfRwTAEArPcjdHlHutlnu1zv3ZMgdAHqEnXvrzh25A8ADUMTlItfJ6d4XU4/lHneJSrT7MVxiT/jdq252cq+y9nLXaMXw2rnXGdRrGK7i9sMwTFMCgF/snd1y0zAQRjVsaEhMC7z/y1JpRvNBv4kX4ST+6TkX0FGktd2LI812s4Y1cbm/cxi5x73lXu0eyB0ANs/RT+5f7ix3Tu4AsAust4zLvb3bwqdYcnuh3CNCalZKJes3k+bttbg3eJyR+7vFe3lk1KcyuUdEHb1VLaOWNAAAwxxT7iWuY3KPEg+UewnkDgC7xaoazxWvUvFKlzylksvdR3xXyWP4tuP34V87Ug49iuap82NUubfcT1O6pXb0Rah+l5L75VIAANak+iuQO3IHgGPxwJN7IHcAgBWQkKy3zKzcI+JySaSqPPWQ3NPyGAVNY6gxzozce2rfO0XqvX1vbzflrmZiinGtFACAQVaX+9cjyT2QOwAcEJO7FY97dsRP7p6oOVcs7kK5t1KVsRhR21HOyL2NfEjL1MfVnmZyb9a/IXfVvgMADILcR2I8X+5RArkDwDjIfSBGlOef3IOTOwCsTdJY0T3tcvcRqVFYr8R66Vjas0Dv50hi1P/70+gVHS53tRjQnjZNUWLmFR2tVuhj3h4AYJADyb3ETuQeyB0AdkUidxW+WBIm0/1FI1rkcXMxp1O8PGZG7k3WH0oh1dam/lTRntYm9I3K5K69AbkDwJZA7n/LvcQVuQPA/kHunNwB4IDkcvfmjO3Nc0Ny9ylKaluLykVy9wu73H/80MP2PgOS++VSfwV6AWGdpRi98mea5uQ+TRc6EADACiRyT9rPJHJvIPcCALAGudx9ihe+eM5F3dBtl3ANe13O4j7xegLdrVYqaaLt5nQ6Xa96kLbi3LJGJnfFMLlbxQ0AgMjYidyjbFXucQe5B3IHgG3zvJN7/KfcCyd3AIABJFxXY96hwLtCurlHN5KIf/rmUy53G2nS7vp+fY0I3XRtyf69fqoL1qj6A8CXynzevoZ/Qe4AsBEeKPdyNLkHcgeAnaAXKOVy9ykeyD2dB/KRvDh+XO7tBru+Xyq66fbupKb0Ptai1iKhvrxlcLxWXk/VVvwpd6plAGAE5P5MuZdA7gCwQzYv9+DkDgAwgotRBSoDTtaipAn8sNwV2uPapbOoFc1vA+0n/RHhfFa0rmot95frvb7WTea23AsAwAjIHbkDAAzIXVmPQSd7IH15P6/MyUfm6+fPlTRGu8H+qf7R2PWqB1FrMJe7nlhTtQK5A8AWeKDczw+SexTkDgDAyR25A8CnI2m6uEDu3lY9av3MYrn7FO82KfunctftK3PeazB//RqSe1uB3AFgCxxX7oHcAeCT8qIUjMndGgAMy90GrEPBUrn7FN1yfa4Fcm/8/KnlPWF1U+6NtzfkDgCrg9yROwAckCfL/StyBwB4PHJb3i59ody1l3jhy53knjWkee/7OCB36/vYc/n6VH0fdfXTCbkDwOqsLvcoe5d7IHcA2BzNbZ6CSbVd0yvfBuXul+s90O8k90z30zRpefN0RCL3tmKmkr3tIW1YK5A7AKzOceUeyB1+s3du22nDQBR1PeIiFbDp/39sJS28TrFSGSV1cWDvhzYRupg8bHmNxyOA9+UJcjfu3AEAVmTZrMvaFqYno0WvpQoFK8hdq+vL5kEafkh8Ue65hWwZANgW/1TuHXK/yd2QOwA8C+lnUZuHQ7kFlCOrCfPLFQqEmfd+Bbl7r9XzPmRppTu55++Qf5KqW+V+OsWAFXIHgDbeQe7d+nLvkTsAvDDblDt37gAAX8K55seiaivlWtD6npPO0FtB7io/oOrvzunrxk/zM4iZ3M3sUblrGeQOAG0gd+QOAFDDe684SpPIY+zC+25GS8L8cnxnVbmr6/k8aV7VCKarVJAFuQPAN+Kt5W5zuRtyB4DX4K9ytzeQO3fuAPCqOOcWo/A6wG63OyRm2STL/m2Xu4Y1nM3XJHd98OtXZ3f1FHIXTV4W9Y29TifkDgDbBblnuXeG3AHgdVDyujgm9Gs+dOhyufxI7PeHSBrU98Mw5LYQZltA6d8yD6Y08FLLIbGW3Gf59rHL3VUWsRwzGwatMI1E7gCwDT4j9+MHcjfkjtwBYDs8IHfjzh25A8A3YzJPEYVXTsjshR6JPEyisz4RQlCvRf+2y90nfc7a4ppNcs9110vrns8arhoEZlZLsbletcK0ZenTPoHcAeAJLMndqnLvrP9I7obckTsAPBclqpeVB7LX6wXfi5FdDN44Z2YN/lU0p6Ha2PJllRNpjvyPYihFuXYVdS92hOoR2H1CE+UEf+QOAO2sL3erWdQ6u3e7lXK3zcq9Q+4A8KIsy72zmkXtkTv3fqNyNwvIHQBekhxcL10YrSRFy2N1+cqdPlVMnxJbQjCzin8VTW+WuyoUtMt9tuYw1OS+T+tMO4L3CtRrVg3SRJa2SeQOAA+B3JE7AMD/lLshd+QOAM/nmCgzXsZxHsi20k+TuApFm4SYN4iG8jPtJ3y0B+8ld60Z9yF5upS7Bs0qXI5jXe65BbkDwDLry926jcjdPif3DrkDwLvz0cl24zia1dW7T5kjOS3mxz3X69XMZiMvl1p5d/Ure+12DaUk5WntV5p9ll0jues13AW5a5DZlEFzuSB3ANggn5S737Dcd8gdAN6eFrkbd+6T3DvkDgDbpThcL7U4J+UJva2fiVor8mxUj2XfJ7yfFL3f5+ZC0aXcv37Ch1JgykesEm5F7odETe66BB3Wkf8yyB0AtkGz3Dvk/he5dxaQOwBsArNJU8p4j15TmwghfjCzvvfz/HIltGt+537eXutPE7jGIgL9Qq/lVHj5ugyf5OZC7hoer9z7mtw1aJfKQSJ3ANgCn5O7fU3uhtwBAAqeL3fu3JE7AGyapNqJ7G4zi//LnmIcJVrZrjalOJ/POQ5/GxRCSGUo/QOzlWvqnakWuSsKr/euJOZMbA2F3IdhMFuUu4oTIHcA2ALfU+62htytQ+4A8BJkxyprPf46RSKKSIgcJ46JWn65Osbm2+aRh+xSHr2ZVRTddsLHQxUKen2m+I5zd+GkQu7jOP5ZzH1fkbtWcM6FgNwB4EHeTu7WGXIHAHg1uXPnDgDQyuEgcf5ItdsnQ82smyPREldZBF6z9f31eu3/JM+a+2lHyCkqeUrv69oOjxaBr1coKNV7u5Q4v54uyL9/Pg84nU6zi6nJXYOOR+QOAI/x4nL/zd4ZLqcNA2FQ+GqNhYFC3/9hK12t2diijpNCgObb6ZCgSJbpj5XnOJ0s7J5f7kFyF0I8OSiX05bQmmNm49j3PV0hxqzoyW11bbAmRF7G/rhcagc86bXF+n4cRzPc2Sp669kd2+TOoU0+Y9U8csfEeJoLkBw/DMO63PtechdCPACT3CV3IcT/iOR+N7kfJXchxCMgI8as6hXho2/X1VC4ti/Jt+qsHZ+N8jwo3xX8Wq5ef+sdUkrbyj9SBH69F/IF3My4TODo60KMdPELXZW7/7Yidwb5JSV3IcT9Qe7OW7nbZ+QeJHfJXQjxHBSf2xR1WQqflBL3I+4Es9PpFOPaUdnAcGoc5OHTEK9TlhlH1DhLj/9UCIYGaBcqNzDXoH4Ad+IxpzW5m6WUruW5vz1ISnIXQtwZ5B4s5H+3lHv/gnK3K3K3e8t93wUhhAA9ud/+yd1auQfJXQjximQ5mVWz0uzH5lVLkz8zna0B+5Jkss2xFHdvC8OzLyrGXSHfTEqtojfH19dHeh4P1iUsg7n9ZZG1w11SRX4m95TMDLmvpNiw9u1+BCGEgEfJPdjd5G5fJvewKnebyz1I7kKIF2O3c4e7wGmNBcImP9jY74ERUj/GkVgOIL+KmQ1DHn465Zdh8DkrTEy+ys+fuZ8nxZutKNolvJr23o4ku90Nyxo1jlwDE/sdEalC6bUNuRNuqQEaisDTefpJSbVYqiUIIUSQ3O8vd5PchRCvjOT+cLnnifSVqhDidri9XNZmnhmDmKszKepOM+FlfxtjRPgwjoTPMyklXyX63s/t85QSJ0886ZL4vvf3lBkz87HsVloR+cY25MrEHn33Xiw3xNxZ2vgiIkuagHpTSpKyBs6vX78auccYzSR3IcSE5D6Xtr0vcpPchRDfCRdck90+y/bAWijP8Xz0NjCCwg6HrphwS1J6dmaBJPYs/OmIpty833tkiNXn3fz1qydhLyCPvnE9uY9UEsD/y6kxN828rMjd55fchRBwX7n3G+Run5G7vajc7V/lbpK7EOI9XvnJ3V5T7l/w5O53KIQQN4A8FLTJTibSaCr0ctfS3JZpPBw2m7gYNTKy2LMzq5UBxrHWeO/74/HI5ljOwd5QJLKjFyMvF966133i6l9G8knNukLA/5wVTvZQSsidm8o3L7kLIf7Gw+VuD5d7sHvKPTxI7ioQKYS4BZQToGYYf6jqr2Znt/zkNdK3edoloOOKDrBeRYyu9PNzmnx2AiOHgy9GHX7dWvCdfqh8lt9iVk+45pOSnm7GZfxleRR4jHUlYybkTrUxyV0IAXBPuYdnknv4kNzt6eRukrsQYjvf5sk96MldCCE+wzDMVGM2O7uaA7KbrU4Zj35zoVmBAd+WRIWCBRgQ2vP68FxKvr7UbwEOB7+tlBJFCjZWojR2IdUz/PCqX5WRWfw+A0fqtedlkyHEYtCY21jLkDs1GZA7fUzfqQohJPfNcrdwc7kHyV0I8WRkyyDkGJFr1hohB7NZufbci5ANiSFTfw5QaioUMFH0MlndnNPpxBu3rlmN9LBe9P1Q1iN3fSa3DIOn5ucUFJ9z/agmrLnf17UsT8J98z/D2yZgxZlM9YVei6XFj8AmnWYm90n4yB18DRJCiMfI3SR3f7FPy93+IneT3IUQD3xyN8l965N7uP7kbjO5Q6caBEKID0Px9dbOpMC04fbJ7IGi7tSWwXsEuukEMWaLZ71N3uXSbJJiU1JOUFnsnkrpfD5PTs6zusNrFD7G/JuXDlg5h883XVWv41FfMmbLwiLsdD7PtnwRV2GYZ9TMSsRP64DP0MrdWyV3IcSzyj2Y5C65CyGegK5bxHSxM96t+eXoJpvdNTgba2EcuYybtQ3ooDV2+rfVyQD5uR+7Qt+7ZlNK+DH/9Js5HrnvYYr4XC7djDLoeCT2RI2A5PXU3068uHlfNGZnhfs0HiNilUopXT94FVN7PKqVe8m0j5K7EOI55W63l7utyN2C/b9y/3NhIYR4lNwt6MldchdCPJwYF+IitO5x+EUQnC41hJxSurYfqYytgxmOq3zWPJZWqLYDqjyC72Q6HrmjzjuY5ch8jPWjTXfHTEBGIuQkm3b2y8VKR26PryTMjHWFRZEK763c/WPzSXlL5/PZzCR3IcTt5R6syt2eRO5hVe52Z7mHL5Z7nVAFZoQQH8aTXHge5BnR1cg+fNoc6gzEDM1kf89zTdi3Ty5NjFRhWaviDmgT+lITAYGbp6J7mMMXjylusytQK6BdQ6gQxpFONOcW+vln9soKzdkdPmuGe9sXiL5MAq/FIRmU/7qoneZHM0nuQohXkruF7y733VW5B8ldCPHKcteTexeC6cldCHEHBjcgCgULbkUqtlM1AJ/WKHZj9nHaTuR2RtYMn+1pwqPt17meEQPjmO08lSFo6yy6wKsaXdC+ZKVUU2b8A3G1lIZCvuR+T1vuR/zb2Zc/81Umy1nu35Ro2BUWpRxi37MyLc7mI7uHLwDY+yS5CyFuIXewLXI35A52E7mb5C65C/GbvbPdUhqGomiYq8F2oIjv/7C2x2ZtmzBFdHABPdu1/IA0Sftjp965uTF+c9+O3BXaMcaYy3RTBiFKasw6Id8AEpZy527og32p7RF8qtT4wZ6mS/4ahkEaluiAxvKvRDrNs6eJAu5yJwmeWsdImKSpTtO7VCSSmeyV7Sn/4vqci6Kb0pfjzKs9XlzJ3zRHHid90CRFOhwsd2PMneUea3Kn0XPKPe4k9/hd7nGb3CNJ7g7MGGNWQVdSooQFtdnRCp/hTvmcLJnqCL6IoLIk8ZLm+D627KPGkAvf3xdLBlKlMby/q/LACN8qgiPnU6JdTdWOzlkvWrlr8ViEWyggyTA8mXms8k86X5QV4FTtStaN3JWaZLkbYz5b7tHIXdxV7unF5R5JhOVujEmP9ua++3e5x2bf3CPx5h6WuzHmnyDqzVt3C1kc7U6frpPRlOTCKlHsSZHGst2n2WJUOkdXsqcmgz13bzti2FDl6gC1Yqgy0/dFkdrMNDaYrTv6VE0VSN/9QqavhlGJSpY/for5TbcWwXCUVKMmzeLGmYz+5FnxiJF7laajsSx3Y8wryH1nuS/knix3Y0wNgQ6Rc153v1yn1HKJHGRbCZEvMHBizz1JMU12u0SLLonpkG8fEQSAWrAoIE6IOB6PKozAmiZjSvya6CIlXynuoPyaS+Po2ypSRVOCQYvv53IC/bwKMazuffVUbcLyDUqFN8ZsmueTezym3N8sd2PMA/H16eR+y5t7+M3dGLMdVIdwJ6S1FcjwoF2jyzE+/OVLsRFWZJtPyY0hKQZx9b3alC+wOQMuNlM1ZuUwC12nWysMA1cupFoC8FqMZPjTSY5VH2UHkbz7weUgMQ+DbhEiYhjSDKuV+uVYkrmcQFS9LgPuejLInZKQP+i5Wr9yTsaYzXF/uccnyj3+Ve7xOHLvLss9We7GmBvBsL9HFhDRGiUgocZ4REIk+sJ5c4CoWD6qQA2Fw7qJBLOi5+HovD17m8VD5cLGi/b7iGCqiiARV9FLconv0H/O6poATakhfzqNv3G7pMAwUVUPUO326g7G2M98JasVRb846fVNf2pmLAvIXQ04GpUnqHpmNGkT8Y0xW+Db7XKPJ5V7ui73tC53YbkbY54Av7nf/ObeW+7GmMdFAWSlsdxYfgCp1wFn3Kl6i43Zyz7/klfCyXZVUF79Mzf6nQVb7aiSu/fNgXeqApAagqnCNOrx2G5AOk0aZ6KSpdYBngdh/B1Qhr16RpTFJCVIaxPzWIhZX8yofDwPMyJ0ZVXKXWUYLHdjNsuDyj3FneQODAhhuRtjnh0FDEZz3hq0WbtChzRrn//sZARDX6oasBi6Mjs6pqg7Bs85a0b0XBWG50glzNrCp0DjnDMRJ60Sc5cETUbhcwdEoXJe2ymlW5OOF6eGV0W/1IQlS5NiiGEYIpgwVy7aaWG13I3ZHvECco9nlXv6Y7mH5W6M8Zv7s8jdb+7GGPhkr6drKKgs0OaV9ucz25k+2OSjJsWKVAagD87Qq4q64/q+J3+mPWQbCbd90J4ptJkuILMej9URfCXPXWsUJkavQFhclh77p0jkvIyUe1Hqjtoxt37iW1P7sklN0iz0sEmoiQhWXMvdmC0wyz3SKl9fRO7JcrfcjXl5dGAzNlqryo4rrkC+SFMZq3LnMAyIisQQVIa4SrYMAY/Z9e3aMJk9t3dHXs56ZXc1J/sF6LIoHcOrdAAGnu8euS+qDLAEFJoC9RK0TCzX17XFeApdxzPib28T7QpAv5a7MS/OQ8o9Plfu6Qa5x/zrL+QeK3JnrP8h97Dcjdk8Dyn3FJflnvzmfqc3965z0V9jXgnthF+Pm0tSV+1PPgkHzaEXRERJdEXCGX1xwrV6Y89PG27vJ2TKZmVi/B13V+XPgALTw0Duz/hPbft/exv4WNXn0SuVwrS7aV4HSAnCxOWhwLhGMQlQR4TghXqrFtQfP+qFkND6fl9ut+uqOvhajCx3Y7bD3eUe/0HuaWNyD8vdGAM1QRQbACWswL52NuhDu8le6uWMab4nwztPkCDDj1jRsU5FkswYgaaah2InCTg8u0rr7PvDlEZyyXZMIXEE9uFQFgj65QBwaixQ6guInFTI+bqoXSsXN8fCQIV3XdZUX9NxTExeqfNrmfeqM2aMeQnimtxj90Byj7+Qe2xE7mG5G2P85m6513LXxz6LyZhXQAHetAI7/qE1MbUgL+sio8Zp68+RKuSULISI79+/twUpF+kuE4takIDribWjQTmZeUulhPihLSUPEaEC7lRdYGB1Sbs5ZB/NLdKKyZzPZz6h1GN1DzkPpOSweMwT/TaB3PUo+Cft9Pwsd2NelT+Ue3y+3NPfyD1Z7neWe0TXJWPMk0NdrotECW6seZ1DqAGKTLpuNyGFrcUnFCQ5nSKiDe1EEPAoDZA11pedItpgkxLhSY5n8WBjfzvq1Y9VfZ7a6nPqjvLXSy7NvEaKXlM+HMYp7Pd8vJ/gXhiphKJYHkn6J1aFtBffnc/cpJroYCbL3ZhXZ13ukSz3G+QetdyTRn86ufd9MsY8OX5z95u75W7MqyEHJQAqn69H6yXrqzuazucSj8dBwBhylvYNsZ7wnSQlF7LcEPAW7P5Rhkm9ULEiEBZHeamFK4AijXX3x+Px/T3nXGUPHY/tY5fcVbiR/nkULJzttjGVzy/FHPlZAbkvfc/j6XJW8g4rmJZOfhBiuRvzkjyM3PVV3EfuEPeQO0Qt9/hI7ul/yT1b7sZsEv6/v4QzgFZQssgf1Bhj3zyCWawvEm0TxWiT3il6zhRwHMbmC9iTP8PfLi8QXDLK+nDYNYxPTfW+KjVGUr9aXyRQlpsRViQiJy3cuC7TgqPJchslLYZPcqbLiKjOy9aoxJIYWv36B6rGvCQblnt8itxjIcWl3ONmuYflboyx3P3mfl3ux2ty9yamn+yd7XLaMBBFRbYlJeEj9P0ftvhONGe8W5xCE4jNPT86E2xLsmmP3M1qZcwCoYw4INMz5sY8ER8WIlD72BzBYPrjEI8/E3fGj1rRhB2rkzcb5gbGxqn9bnBynSAo8CioLgDcgcalipGCyoujB6CgeSoisNkE8xdg55cXRkn5TLXA5NWPpgLuTNfM3lyuJ8hO25a7McvkZMN2V7nHreUeN5N7zFjuz88uHGbMfGGJOvCvWxLJIKl0tJyAXhsyYc09sQtyN8qwSKI/HA4NxskzOqfvjS01SmdAsjsFxEDHmCDYwfs0yrNm11RUG1IEJ100VBfbJo9H7BXVgfdya/oY66eHR+NKVM8T5TAJbEiUEam11Yrdt5W9ZLkbs0As91vKPS6Re/yj3MNyN8bcXu7Ncr/2zT3u++a+XnsnJmPmC17IRCuH6obTUDNGEFyVuzapo4o7dX/TsGR9ZdoQkYf1gEyl7hAcd8Xu1D1Arz4F8wANMkGwCd/UlFJvm5mGXw/oU+6FW2sZHkV+eGwAnp4Rw9cNUjSeffi4SJUNdB5tWO7GLJCJf91xsdwhZib3+C+5w+t95B4Tco/r5K5TjDEzBZNclPtOsAIglwQj+wSfHo+juaFskaTsENXW6kqSkmvUSJtm0xQp4AyGHat7ejwoc4UaCxibXbUhTSnAbdRTh7IDO7XLiJ4G0vOd3qpaDaVuFc7KX5PS79NZDEs2x9yqXmC5G7NALPfPlnvcTO7x1OUelrsxxnL3m7vlbsziWa0uW7VKJHpCCTioTiM6QYx0nNrb7xX6rkqCGDbg62eBxMkpVJin2ABQ1L1PI8A8UO7+JOvVGF1Oa3VW01FNT4ytVzTgY9W6pFc+OxzqUjItmMLjPJQ0Aap8Zq1iSdV5urHcjVkMlvu3kHt8qtzDcjfmsSHHGShCdT7mwrECkY16pBs2ggTtmkajXaST4Eol82clg0fUsUnRlCFDXKiLeAmlxGg/FS6gPsLTwMnr/WSg7oHOorYAiYoEflT4flx8IahecDgcnjJn9obSDFNDaelUJSQx3n7PA+9135lQ95a7MctgTnJvwY8/P03u8ZVyb5a7MebfeGC5+839Orm/Wu7GPB4IBrBtpiy8qeA9oM2XAdoHRcmpRZOGpfKIozIEiLkmz7DcfqLeY7CSKKWglOIEm6EWgWZBDbAGptmqukbah/29D1zBPewGIi5Yv9Rh8w11WH8bUK7kUWjXQg6MnnPEaaiWuzHLYN5yj3Nyj+XLPW4g9whXczdmlrxX9YaaUVEhxgCYBDNVDgdaRVc911pK1/HUOw5SQruOaT/pWutd6SN4ncsZllRHYvuZgu+cqgx51IjtUt/0mZ6kAlDqUu3yrOTiJ6Ee+BjK9tXcAWLG7BumLHrX+WVeXg03NhqRyrdZ7sYsgceQe1wt9/ieco+r5d4sd2MegseQu9/cL3hzd8TdmCVQTMK/8wuyaziGBivb11e6Q+5EvVer1Dvqlx+7+pEU6DOlseSIeLTx7nJrfimgLJQzBd9lyjQOxJlgXz1gukkbgJ9uQ79YqHk2KlJQniDPg0KTdetw3Y3KLNRhMYWnku9p0PrFQpa7C/4aM0duKffXu8g92v/JPb5M7vE/co/Pl3sUuevvhzFmjvjN/Y5v7vH939wtd2Nmyrkw8boqhj3+G4wvojgM4EwpmrzBkSf3e36MCPxMLFhB52o72qPGZFqKxBRBPmSUwjG4XlbkaF3TVPrW3Z163wwozK1r6R2o2kgCJk+XNVBwamO36z/w0NKkofHyMb3rafENcXlapabmI8JyN2YJPKzcWyxK7i1WlrsxRpBwUlhdGK0hSDCVX8O0kBx0PB5lcyyTRrnbTY07Isq+2RxgURJTiyopvqa5gb3rqFnAtMCN81kPpGy3GlFE59S+0nre3nQKu1kTqiFs8oORMabpbwPvsu4rxcxojVNThYdS8r10pDneGDM77iD3+Eq5x/3l3qJ9O7mH5W7Mg+E3d7+5J7mXb9sYM0POWCMCt9WklcsXNkkiWdroLUklnafKjw0ULB9LSqFyxdJruF3aTsHt9Vr3x3nBCTK2/Ajp8veYuDpcK8w+cdtMHlSKzHF4jVG1Jv9eCS09dCyuo6MSnDRN76ebjUjfUAyZRf2RUdHGcjdmGcxS7sG4P0nu7SvkHneVe3wk9/YPcg+vTzVmpkz8f/+S81HN9FZ9Ve5Sk9otK+1JsdGPdRAUhmffbJDMFJbh8lo/QD/TICk5DIa0d7WG+nX+FZNd31ePhghraaYTxLqla8Di2rRP/TP3ytcRQe9UhVSTfFZS+HV5g3DxAWPmyq3k3iz3Gcr9yWo3Zq74zd1yt9yNWSCXyT2ihpfx0kcLm6rcifGmQgQsI+LH2pfC1wSaa5wfbYMW6I/mBilPQiRbhnmAEZdCk1wrcu//UDRTdu5zH1f06pcDx+NxuJEXaVvznD7e7zWr1cZ7mcv0rT0/p6/u7e0tVcmsX+LKC5iMmStzlHubg9y3J1WH5W6MuQukYYAsd8bUKAPQ8WSJc+ROawPoJ7X26xcOz31RSSXtmw1D6vkW9WIrVK4QDCplbLX8wGaDkzma7F1z6yvk9KQa7PvB1hxLtR6UON93s34f/JkcJ2a80e6C6SHq6ZZdEy13YxaC5X6R3PPR1uK83OMr5d4m5P5yjdxbkbsWp3p1qjHzxHL3m7uIsNyNWRJloRJLXi5weAxS+SBjBLljx/0+7fZPTF0rg7r3ZBj60uIhgsokykCvd55A1k8DI+ejVeLrZMskyW02Uu6YaJoCttuTp1d/ZTeg1J0qd82ypz+ofjkxncrEwISmOHyU5Jx6/u/fqcE+xXpxqjFL4BvJvT2S3MNyN8Z8JQgOMHA10N+dj2g/nCVouu83xDjoZshDX+Ox1BfL/ekdIuIPe+ei4zQMRFG3sxSWDYXy/x+Lc5XVUWZU+qC0TXoPEo80sZ1GOg6z4/F+j3pB3vtMJaHriECIbHQU8dk7fdHQfPvp3XZEN9vtzL0kJHDNapRr120qkaUGs1SNIH3ABkrlqx6GoT4H3QETbIqHMc+qPZKUpgnXW6cas1Qs94vlHs8o97DcjTGWu9/cT8ndGzAZs3AukDuHz1q/hJhrGxJdd1EaB2uPSmV3+upLb7ohUyXDtNsd4oJJ4N9HGih4XyYPCr7TODXhcaJC+/08xsqkVG+ccafaBj9/bqZmBJ1p/ddmQouvWOykaUkLmkTazY+Zp08QZSjaB7AuplUDemqWuzELZwFy3zxW7u1F5b7xD1ONWTK3kDtHi9qPtKGMl1SQHdthI00CcjIaIhO8dvI+guNA7gwy46myhemnVBV2YiL0UYu6q9oZfjxZi2Aq/V7ByUR3IqJkspMXdDgcuuhH2MKcFQs1IsMdUwxCfTI99lOIzSjmY7kbs3D+u9xjcXJvTyD3dhO5x7/IvTdmjFkuN5J7HJN7+M19oW/ulrsxiwapnqr8qP2edxctbKJxUMRbMd4kd/RdS77jKsXpIVVWl/ywKH2qnKI6hJ1I5qaGfETyKscIy3cIz7fMaetH+8CylBDYbt/efv/+zUUnf8DBU+DuSkFNzV96tnwVPCYdI/DuNEhjFs2zyT3uJ/f3K+Uex+UeF8o9pNJMbJ9B7saYRYMoTpWLwgfV+ScTZTCJygqofZ2Af9GgHFsHqNxwxE0nXImpZrEWxTvSKN9Ht8/SXiKIjjSgbPw0NzFsPIpwQensKsfeG99mFH9JiSx56yq1K3ge9T8IlGjgH5rnNLKUkE86O4kyfIP6thyPMWYNLFru8dRy//rMcg/L3Zh18xxyjxd+c4/HvLmH5W7MqkFKcGTfvYsO80GN25d99RQR/0zboDQ7M4eERdC8Dl4rSWkylSknR4bAPwpjRHW7a7be0yinv9VNpWcJLZsRNaQVSg1yu99YoTTpWGDztOHez58/WbOVbjJCE0+HE1JSjKYzHeZ204z+5oi7MevgOeXezpZ7/He5t3h7vNzfZ3Jvt5R7WO7GrJH/Jfcp9FJDJCo6wJUUJOvogH7DcpMxu7hSX5yqNBadJXuBPquJL7uRuls2WS1AcQLS3oGsGk1En0qfbdUE5cp07NP0w3DEsNobWxXFNnNUvSC90qdnoJFRy40Jk+9SX0Y4A9KYdfAQuYfl3ix3Y0xi+XL3m7vf3I0xhWeS+9ElNegpaVXiokH+JtvROx+wXzau6kh0VHukT9C+dq1FUiiSxub83BS6BnWqDK+PiosJ2udaBGTQwBnW341oN2vR/8ZF6g64AkXX50hRBb4Upgp+AKCFXn0GNcasg+vkDveQe/yb3KNZ7qfk3ix3Y1bGuXKvtQco63X+ftkfCDTJnRCCjlbrM1TEPBUEw/UppNJLv5fb+FQu7VK9K7Uvs/bzy71QuL2fQirOydrthG8alOIAZQYRGm0l4ni4LELTCIEiioQxxXHy2IMxZi28rNxD7Yblbrkbs0peVu4t/OZuuRuzXs6Su9wZEVeWg4de6bCJLHf+nrNlZP3SV2jJDhUgaY0TKCDJMSmcqDfLjmqN9RjB3ECpA+pIzuCi1Pu4d/b216/+G2jT7IhUXL7Oit360xWzPrmNNLHt93uGl85/H0kzgTdMNWZdPLfcN4+Ve7tG7nEPucf/kLuTII1ZEefKnfOul/tupyT3elYXUQTVxTm/+45/ynxcS2RBYkTzTCM1KERgBA0yDsSfds6upWak2ZP56xEkpffJ6O2t/1auUBH6H0InloR1zTSzAU6NHg6HYdDO2b3dfgz2+yPPJUKFDtJhHWvGmBXxOLlHkfuUk1fkLqJtL5V7WO6WuzGvit/cLXfL3ZgVcje5E1qve/lpzwrqQ3K+9EqFgpnvaCuFntUgQ6C1RoSd7jgP1xOVBqYF1jQBTdMue10LSsoDcxPWbxEqEC9Umr1E8GsVBbqhqGQhhmFgORPs92oIvtr0xiyel5J7PEDu7Q5yD/06Jfdolrsxr8MN5Y4ayKyu//3HkzpLh5PDUfSRZJgIZbA3XCQ5If6Usc2WRLIz4Q39A5SvQop7QjEipeT/TdDa3BpZ8p2mJmuvACpGvxnp7ZbYTCvoA42jcjjUDzTe9Lxd1N2YNWC5Xyj37ULlHpa7MS+F5e43d8vdmBVyrdzZBO/05ZQRR6bktxCKz9F6ReKxXFoCmlzEQNlDLxUmls1rxQEmAMXZCaiDpp3+QY1YMyntdtrmrpxA8cnT4XYgqs6Ap2VMyhRi8CfFrB8FDMNAUymBqbTgou7GLB/LfSFyj2a5G2PuIHdqdV1QDn5Tdtv/Nkq+yn0Kb6TLRYxBmdw0EQ7VVi+6qjYncoNHOVxnpmGQ+hMMtYqfnvgAqAT/ZaSeQh5/RRnxE31YPAUmF7Lhe0M4P81Ih0NEpGO9rLvruhuzeFYg99jeSO7vTYfjxeTeLHdjVsgK5H7zN/d4Kbk3v7kbs0ao9niR3JHqVXKnErykU+VOJJ5q8hQRmPXAKtBpab1OrYky2E29VrVj/8S4mn+PQBPD0Ndg1fwgisZHzLbeg8Ohd6iuFe6fffbx0fukWn6p1D4riDC128fx8bGd0A3x9GpDsn5ZwqUZzPV/jVk+j5R7u5Xc2xVyj3vIPRpyb/FMcg/L3Zh1QxWA/yV3ct+5ggZxPnLXnyqnVd/O5UBMSkPSPg4HGVvlvGgt77StnjgFdOXh0CCbfaB/4OIpt75DUQDyaxoAVRH0cKg7FqHBl4T5uj1szXxPM7q+lNlcRjKRKug3Y8yf9s5oRWEYiKJd5mFhUZL//9rFS+XgDJVYxGq850GQNKbm4aQMM9PP5li5x7jcl31yj1G5xy65n+/JPd5D7r+WuzFfiJ/c/eRuuRszJZj1GXKnsKlOr3JXUDnlyPB2aiTG6oTi09jfRdm0g2eUkDOqy20gsX85GRioBu49aTD3YFQaDWcUUJ4EbCHWTS8WPF/YaL6uOZX011T+pOm0KUiruveAMXMwv9zjhXKHsNyNMY9hufvJ3XI3xjwid9Ijd8qdDLwRuRNZRu5rYRP9IZPAb1ZVBQ/dY/QBcr0Km3KKOxfo11IBEjdzp11j75051cStkbI4bHYC35tRdU6klWsSJ2sBB5vC+KpoYiNqkF8b6oC7MXMws9yXo+S+WO7GmOOoiqZkaKfc0Wudzihyp7M7F+h3uZTpVDzd3IJG+ApSXro+IlLEIomRMXahvgT7dIoyiWVbawuMq12W3hoKhtJxoGqoH7Gydh5Qqg89CFJlFyfkNUDj+iVjJuJ75R6W+6bc/wHtX0b0rZKnOQAAAABJRU5ErkJggg==');
					background-size: 100% 100%;
				}
				.user-info {
					z-index: 20;
					position: relative;
					display: flex;
					padding: 0 40rpx;
					align-items: center;
					.vip {
						width: 82rpx;
						height: 36rpx;
						margin-left: 12rpx;
						image {
							width: 82rpx;
							height: 36rpx;
						}
					}
					.rule{
						color: #AAAAAA;
						font-size: 24rpx;
						position: absolute;
						top: 50%;
						right: 40rpx;
						margin-top: -16rpx;
						.wenhao{
							width: 22rpx;
							height: 22rpx;
							display: flex;
							align-items: center;
							justify-content: center;
							font-size: 22rpx;
							border-radius: 50%;
							background-color: #AAAAAA;
							color: #181818;
							margin-left: 4rpx;
						}
					}
					.avatar {
						width: 84rpx;
						height: 84rpx;
						border-radius: 50%;
					}
					.info {
						margin-left: 20rpx;
						padding: 15rpx 0;
						.name {
							display: flex;
							align-items: center;
							color: #fff;
							font-size: 31rpx;
							.vip {
								display: flex;
								align-items: center;
								height: 36rpx;
								padding: 0 20rpx;
								background: rgba(0, 0, 0, 0.2);
								border-radius: 18px;
								font-size: 20rpx;
								margin-left: 12rpx;
								image {
									width: 27rpx;
									height: 27rpx;
								}
							}
						}
						.num {
							display: flex;
							align-items: center;
							font-size: 26rpx;
							color: rgba(255, 255, 255, 0.6);
							image {
								width: 22rpx;
								height: 23rpx;
								margin-left: 20rpx;
							}
						}
					}
					.grade{
						width: 40rpx;
						height: 37rpx;
						margin-left: 10rpx;
						.image, uni-image{
							width: 40rpx;
							height: 37rpx;
						}
					}
				}
			}
		}
		.card-wrapper{
			background-size: cover;
			border-radius: 26rpx;
			width: 690rpx;
			height: 314rpx;
			margin: 0 auto;
			position: relative;
			top: -157rpx;
			padding: 100rpx 40rpx 45rpx;
			.title{
				font-size: 40rpx;
				color: #D16739;
			}
			.info{
				color: #333333;
				font-size: 26rpx;
				margin-top: 20rpx;
				opacity: .5;
			}
			.wait{
				margin-top: 50rpx;
				.wait_count{
					color: #333333;
					.text{
						opacity: .7;
						font-size: 24rpx;
					}
					.value{
						color: #282828;
						opacity: .7;
						font-weight: bold;
						font-size: 34rpx;
						margin-right: 6rpx;
					}
					.iconfont{
						font-size: 14rpx;
						color: #333333;
						display: inline-block;
						margin-left: 4rpx;
					}
				}
				.progress{
					width: 350rpx;
					height: 8rpx;
					margin-top: 15rpx;
					position: relative;
					&::after{
						content: "";
						display: inline-block;
						width: 350rpx;
						height: 8rpx;
						background-color: #333;
						border-radius: 13rpx;
						opacity: .3;
						position: absolute;
						top: 0;
						left: 0;
					}
					.current_value{
						display: inline-block;
						width: 240rpx;
						height: 8rpx;
						background-color: #333;
						border-radius: 13rpx;
						position: absolute;
						top: 0;
						left: 0;
						z-index: 5;
					}
				}
			}
			.brokerage_icon{
				width: 177rpx;
				height: 212rpx;
				position: absolute;
				right: 60rpx;
				top: 0;
			}
		}
		.grade_main{
			text-align: center;
			padding: 0 30rpx;
			.grade_privilege{
				.title{
					display: inline-block;
					color: #786046;
					font-size: 32rpx;
					font-weight: bold;
					padding: 44rpx 54rpx 20rpx;
					background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtgAAADJCAMAAAAuGLUgAAAAvVBMVEUAAAD1yaD77+X88Ob77+X77+X78Ob77+T78Ob88OX67uX77uX67uX77+X77+X77+X77+X67+X78OX77+X88eb88Ob88Ob77uX78OX98Ob87+X67+X87+b88ef78Ob67+T88Ob78Ob67+T78Ob88Ob67uX87+f78eb67+T77uT88eb77uT88Ob67eX98Ob77+X78OX87+b77+X77+X67OL88Ob2yZ/77+b2yZ/1yqD1yaD1yaD1yZ/1yKD2yaBGE0+EAAAAPnRSTlMAs4ltgpOFcY18WXlqf19jkFJ2Z1yWVZmcc56hT0xESmQ7QUelpD42LzIrOCQpMx+8t6sVCq83wcCG8KhQhnk6wZoAAAeASURBVHja7N3tTuJAFIDhk9pCxapIAF3dFRGUzwX6Men939kWCcFVNpaC287J+5y/kPDjzWQypa0AwH8yF0ChiQD6zAkbGr02BNDn6UkAfR4cAdRJ0kgAdXppmgigTS1NewIoE6dpeiGAMmdZ2CF7ESgTp2tXAqjipmuGJRuq3KTpKpvUFUCPwWrrRgAtrlY7bLOhxNhfvefGAliv764+anHHAawWD36Y1T4vQZ/zEVgpGY/bfme1Fn6aNRO0iRu2Grc74R6XN2xHYLn5Zfi3h0eWamgwjsKd6FEAHRIv3PISyYEjQVghicINR3Lhvl/YYRyGJpsokTzmbQGsUM+6NmYqufysCWCF2BgT5u314k4AO9TzL9ixMUsBrDAz5k7yaRjDw3VgicSYa8klfjHmhWs4sIRrpnk/mLkWwAoNI7kE5s2zADYYuZJD7BsTvU2X3QhssAxyxH8W7XR6XFmHBbpfhD9tRR91gi4Hf6i4Z/lKMgoeondavakAGiTdaCtgJwJFlvfRMJt7FmvoshiusbeGNkHWNc/ShjrxcOgJcJTXYaleZY/z4UAAi7veX/ZgyIEIjvL6Uro9ZS+bAtjd9d6y6wIU13+ohL58xGvXYX/Xe8r+LYD1XX8um3+sorD+fYX0BdDXNWVDZ9eUjZPo31UOZUNj15QNnV1TNo7Uv60oysYRZreVNRNAX9eUjcJmnUqjbNjUdb2TD2XDpq7zh03ZKGDmlaTt5UfZONDIK0vPO8BIACu6bvU8ysaGoq69p7FH2fgeo2Z5evPmYSgbFnTdnMZNykZGV9fNRJqUjW8w8st0LnLuH4qyUfGu/YZI4FM2lHXtT0UGPmXjxBa+75Q6ici0yG9YCPBPC6dkVyKSOEVQNqrb9SbPOmVDV9dOIplfDmVDVdddWYsdysbJTJxa6RPLm5ZT6NsOT17FJ5Na+Z5k47FWEGWjgl3XlrIR1ygberpuyNYNZeMUJm4FnMeyFbuFUTaq1bU7k50eZUNJ1w15J6lT9h/27a1FbSAMwPBXLIjRKh4QhHqIgkaNm4sdRHfb/f8/q2lti+2qm/NMZt4ncS+XXLwMOcyHnILPJugouRZ9zi4QQIIvJmirAi+LsmFI10MlQtmwreuvSt47DCgbGQUtAwzuZPi8aGVG2U4zouu1kns2A8pGBtOWbpM46wfUetLKZipw2LSt1TiQDwXjdgZ07bi47JaGM9abhkoSUcG0044l/vd0DZm3K9f05n6kJBUV+X2v2U5oLnBe1WV3Pa/v+7tISWrPke95HbpGIvOBHk3PjySp6Kk/HCRE19BY9kV/Jx9Su/4gMbqGEWUPGislj4TeIAW6xpX5RKvl/bS3i0k6dI0rq4lWjZ3cFC0mKa0EuLJq6nUrSPW1mRZd433ZE41Hc6zedT1qprwmuoZ5a/ZU/vXcYb2GDWXv5Zoa0jWKMWvoFV537TXSmglwp+xmI6brT1fJX2u6hjVr9kb+iOga9pS9UPJbn65ReNkdbedaLqJ0V0HX+NCso1FPLsaddOj6veP3109ZfT+KfZYdjQ6/X2GnsxT7fDu9vGV1OoocP+VC2cVaXa6Arr+95XKUc76wz2Kh5VAfJbHuMA0bu5bTWy4n+ZTPq9hIY9mRiER0LW/5vBC2YWX/zNSn69xhcyty23qhiSci3iK5tdgp760ID4+mla1E0XUBD49yPL9mX6+t7Vpk3dPjWaJeYtZ2nfN1n8Vd1rbsrWzpGlcsKXsmc7pGqfyuBisZd5PxBchYdq9b9dmVbqz30Y+uUbM1W7Fe4382lB3QNcrnj6oWjBKga9St7Bldowr7kXH2AuS29wxD15nmaVyfoLlT9siYnxtdx5/UC/yIfmQT1C0bzyAbcUHqTVCPSzyzbdX0st3oWk7pN6o+wqDB/bLHRhyOdC3pRwsIO5PN2AiudJ0hbG5Faly2M11nuBXh4TGjp7F2T+KMYh8ef83TMEFzx1NfM4e6/vW6j5mZimz7adA16kJr2VsBLmwqm65Rou1XTega12wpm67xLzvKpmuULphWLhDgf/Uvm65xS93LpmtUJJhXiK6LF8/TMEGTrmy6ruiT+umYo2s2QWkv29muk2x7yurMttW7dqtK7MRRpyQbVbNi0CBl2XRd5aDBC2Ff1K9sd7tOFDa3IuXYzUrmcNeJbkV4ePyjXmW73HWZD4+XeRomaB44zEp0EKfFr/uYmdHmsCyN411Dr7jsWRkHXSOdmqzZdI106lE2XUO7w7pwdA0DHOgaVgrXhQoFMELoF4iuYYyQrmGlkK5hpZCuYaVwXwC6hnFCuoaVwk1OP9qpgxQFohiKou6mbfllBtn/3iwQ0YFiqZP6j3NCsoJLdM0uDV0Tqf5+UAfYqTp/TdfsWOmaSPX/FV2zc6VrIpWuiVTHD+maKZSuiVS6JlKdNtM1E1nLPm4ZXTOX8q+JtKXsRddMp5e3+gDTaV0TqXVNpLXs8Wp0zbx6vKRrJtZjLOPJ6pq5tX9NpNY1ka5l1/3omghdq/FwdE2Erhr3tHVNiq4bXZOkdU2k1jWRWtdEal0TqXVNpNY18JMLIREgeXnzFmEAAAAASUVORK5CYII=');
					background-size: 100%;
				}
				.grade_list {
					.item{
						width: 330rpx;
						height: 135rpx;
						box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.08);
						background: #ffffff;
						border-radius: 10rpx;
						padding: 25rpx 25rpx;
						margin-top: 24rpx;
						.picture{
							width: 80rpx;
							height: 80rpx;
							border-radius: 100%;
							position: relative;
							background-color: #FAF1E4;
							image,uni-image{
								width: 80rpx;
								height: 80rpx;
								border-radius: 100%;
							}
							&.isLocked{
								background-color: #E8E8E8;
								image,uni-image{
									filter: grayscale(100%);
									filter: gray;
									opacity: .5;
								}
							}
							.suozi{
								width: 26rpx;
								height: 26rpx;
								position: absolute;
								bottom: 0;
								right: 0;
								.image,uni-image,image{
									width: 26rpx;
									height: 26rpx;
									filter: none;
									opacity: 1;
								}
							}
						}
						.desc{
							margin-left: 20rpx;
							text-align: left;
							.name{
								max-width: 180rpx;
								font-size: 32rpx;
								color: #282828;
							}
							.detail{
								font-size: 24rpx;
								color: #666666;
								max-width: 180rpx;
								margin-top: 6rpx;
							}
						}
					}
				}
			}
			.upgrade{
				margin-top: 60rpx;
				text-align: left;
				.title{
					font-size: 32rpx;
					color: #282828;
					font-weight: bold;
					.name{
						margin: 0 19rpx;
					}
					image {
						width: 119rpx;
						height: 15rpx;
						&.right {
							transform: rotate(180deg);
						}
					}
				}
				.upgrade-svip{
					margin: 40rpx 0;
					background: #FFF7EC;
					border-radius: 35rpx;
					padding: 16rpx 20rpx;
					font-size: 24rpx;
					justify-content: space-between;
					.svip-view{
						color: #AE6908;
						align-items: center;
						justify-content: center;
						image{
							width: 32rpx;
							height: 32rpx;
							margin-right: 6rpx;
						}
					}	
					.svip-btn{
						color: #B37400;
						font-size: 22rpx;
						.icon-jinru2{
							margin-left: 6rpx;
							font-size: 16rpx;
						}
					}
				}
				.upgrade-main{
					margin-top: 15rpx;
				}
				.item{
					padding: 30rpx 0;
					border-bottom: 1px solid #F5F5F5;
					position: relative;
					padding-left: 100rpx;
					.item-icon{
						width: 78rpx;
						height: 78rpx;
						display: flex;
						background: #FFF7EC;
						align-items: center;
						justify-content: center;
						position: absolute;
						top: 26rpx;
						left: 0;
						border-radius: 100%;
						.iconfont{
							font-size: 40rpx;	
							color: #DFA759;
						}
					}
				}
				.name{
					font-size: 30rpx;
					color: #282828;
					.add{
						color: #AE6908;
						display: inline-block;
						height: 30rpx;
						line-height: 30rpx;
						border-radius: 0 6rpx 6rpx 6rpx;
						padding: 0 10rpx;
						font-size: 20rpx;
						margin-left: 12rpx;
						.iconfont{
							font-size: 26rpx;
							color: #FFBD09;
						}
					}
				}
				.text{
					font-size: 24rpx;
					color: #999999;
					margin-top: 5rpx;
				}
				.get_btn{
					display: flex;
					align-items: center;
					justify-content: center;
					width: 136rpx;
					text-align: center;
					height: 58rpx;
					color: #AE6908;
					font-size: 26rpx;
					background: #FFDDAC;
					border-radius: 29rpx;
				}
			}
		}
	}
	.hotList{
		margin-top: 30rpx;
	}
	.success{
		z-index: 10;
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		text-align: center;
		.bg{
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0,0,0,.5);
		}
		.level{
			width: 222rpx;
			height: 203rpx;
			margin: 20rpx auto 0;
			uni-image,image{
				width: 222rpx;
				height: 203rpx;
			}
		}
		.title{
			color: #CD8D33;
			font-weight: bold;
			font-size: 36rpx;
			margin: 0 auto;
			display: inline-block;
			font-size: 26rpx;
			width: 285rpx;
			margin-top: 96rpx;
			position: relative;
			&:before,&:after{
				content: "";
				display: block;
				width: 52rpx;
				height: 10rpx;
				position: absolute;
				/* #ifdef MP || APP-PLUS */
				top: 9rpx;
				/* #endif */
				/* #ifdef H5 */
				top: 14rpx;
				/* #endif */
				background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGgAAAAUCAMAAABWIogpAAAAwFBMVEUAAAAeGxsfHBwfHBwfHBwfGxsfHR0gHR0fGxsfHBwBAQH25tDz487v38ro2MPf0LzWyLXQwq+qn5BnYFdHQjwzMCssKSUWFBIQDw0LCgkHBgbCtaS9saBaU0zr3Mfj1cDazLnKvavHuqi4rJy0qJiwpZWkmouglYeckoSYjoCUinyQhnmLgnaHfnKDem5+dmp6cmd2bmRyamBsZVtfWFBUT0dQS0RMSEFBPTc8OTM5NTAnJCEkIR4dGxkaGRZjXVNX44A9AAAACXRSTlMAVPqA/IN8WITLwrIKAAAAr0lEQVRIx7XNRRLCQAAEwMVJiLvi7hLc/v8rODFVkOI2/YEWXKWqYMIjSdQJT7lMnfAUatQJjxDcCQ93wsOb8BTfD3fCQ5/wYBKNhqKoalPTWrreNgzT7HTjJOn1B5Y1HI0n09l8sVytN9udbWdZuj8cHed0vriu511v0v3h+0EQhlEky7KAyldUKOZHcX70TP9HvxOekiDAxH0wsR9M7AcT+8FEfjCRH0x4uOqf5wXaUhSOXi91TgAAAABJRU5ErkJggg==');
				background-size: cover;
			}
			&:before{
				/* #ifdef MP || APP-PLUS */
				left: 0;
				/* #endif */
				/* #ifdef H5 */
				left: 0;
				/* #endif */

			}
			&:after{
				/* #ifdef MP || APP-PLUS */
				right: 0;
				/* #endif */
				/* #ifdef H5 */
				right: 0;
				/* #endif */
				transform: rotateY(180deg);
			}
		}
		.upgrade{
			font-size: 60rpx;
			text-align: ceter;
			color: #CC6C34;
			text-align: center;
			width: 100%;
			font-weight: bold;
			margin-top: 10rpx;
			font-family: 'Tahoma, Geneva, Verdana, sans-serif';
		}
		.con{
			position: absolute;
			left: 50%;
			top: 50%;
			transform: translate(-50%,-50%);
			width:557rpx;
			height:660rpx;
			background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAmoAAALjCAMAAACVs9ldAAACZ1BMVEUAAAAiGiD66crysFD60o3604/72qLz4bIeGSAeGCD63a0cFx8cFx/726T85sD66cr85b7758T74rX11KAdGCD61ZX72Jz726b86cr86MX80Yj8363847j836376sv83an86sv6z4j83af84K/96MX84bL83qr86sn81JD84bLi28v81ZLCkFj86sr968v80Yf968v968r96sjTqmvaqmUvKi3Sl1GWc0s+NDDyzIr86sr947bYs3jerGgqJir968uxhVMsJyv804vysFD70o3ysFApJSjysFDGnWOxZzL94rbysFCxaDMsKCv/9u/NlVfCi1D+9/D67+H47d3/+fT99ez78uU1MzYxLzL88+klIib369opJSkuLC84NjkfHiA9Oz46ODssKSz16dj98ufy3b8aGRv25M3x5dX14sj67Nrz38P359L56dbw2Ljn2svXy77f08UVFBbs4NDu4tLq3s7i1sjw1bPbz8Hqyp/pvnHSx7nszaXv2aXt0arv1p7u0pbtzY7syIbrxH/qwXnq1bfu0q7l0rT+36KwZjHds3DVq2XRpl7oyZH97M7NoFfYxanft3jLnE7hzbDdyazXr2zkxIrqzZnLwLPFlEvn1Kb847rSvZThvoFIREHhxJe3bzn8362rdjbw3avTv6XNu6Ht0aDgzaH96MVUTkdgV0trYVKzlWSEd1++eUK1fzjDjkHDua2UfFaDbEzbx513a1iQg2lyXkTJsoqiiF5USTz0zpHCom/Nj1bZu4WunXqfkHI9NjBiUjzXyLLPsHvWnGFKPzTGhEu7iUK8qYK6sKWebDTdp2uNk3CVAAAAUXRSTlMADX36/n18/joeEBcx+UH6TTUZBSf8/QkhKvxkfVlXcWIk4bRtoMl1M418SDyM52a+rZ7YVLYeZVLB2c2bbtvNjIHaoJl96Oe43eDIncmx47DKDwqUAACCeElEQVR42uzdzW6qQBjGcUOsJiR8GnSwiqi0aAwK7I4sTE668uK8AVbueg/e3HlmGNr1iePu+VW5gn/ed0DbDoj+12RA9GqTma3MmBu90sQOhYjjWIgwtBkbvQhCE3EQuK4bBEEsQns2IHoFWwSu7ydJ4vuoDbFxrtErTETgJ2kHtSG2OLQHRKbZsZ9muQV5nmUqtkCEXKFkmu2muVXAfr9fLBayNdeNBccaGRYmVlHDByA21ZovVyhPa2SUSIu6qqqtgtr61mJuUDJK5FVVXpqm+QTEpltDaoKpkUHCKi/n8/W6kRBb1xrGmhvwsEYGieJyPB7HjrQB1doerSU+UyOjpR09zxs7mmoNY61LjQuUjJZ2Q2lTxZmq1rZbtUGZGhkt7YbSplEHsTlqrCG1nKmROcI6y5kW9aYRWtNjTabG52pkRpiXRw+lDYfDOd79XMNY61MbEBkQptWlK23+wE8XW59akaduzBtQMsFOivIoz2koDZnJ2B5qrG02KrXE5VGNTJi5VnXB87QoGsJDlTb8Sa0usoRHNTJhEmdFdcZTDpkaMlPmD71Bt7WV+QH3J5n5MkddXh2VWrdBH/KqU6tqK/Vj7k96nu1iqDUbmVo/0ORFp9ZU8qjG+08ysT6TvO5S0zegyAzXLrVrWRWZv+NQo+eFbmrV2walITWUFs27A9s8ihxnfC7rInXXA6Lnh5qfFfXnxtFnNdQm33hhqN2PFxzVlhxqZEAYJHmxlalNZWpzHRsgtRapFdmBJzV63kRgf35s+6kW9VMN18hpvWNZW+87PlOj59mBn/2kplrrPpiaz6Np63k4qq0OfKZGZvZntv9NTc81+SNLw/7cn3hPQAbMhJvkOjXdGgzxmrY3pFZ+nLg+yQQ77lPrW9NUad55+8bSyND+9NM+NWXacVqEdjt+fh34nINMmMjUFjI1bFBt6kB7u3k3b/PnxFsCMmImdGp6rGn31oNvh6WR0dSwQDHWdGt3534ft+js+9v5y9LIFFumlv2Otd/S2palkeHUkmyhxxpiU6Whs3a8YWlkkL0O/CVSw1iTrcG4Hd/xvvKOgEyn5i7fu7GG1prm2mk+WRoZTm3n+khNtYbYGgW/ZvzF0sioWRi7vhpraA2xdT6+3vgRO5k1CdeBbG21kLFp+7cTSyMwvUF1a4hNGY1OJ37rloyzQ5zWDmjtfbVajUaj1ep0Oqz5CTsZN5GtBWhtidpgeTjsuDzpFWb2er3bHXq7Hf+SN2nmWwsRGxzwXvMf/NA/9s7fxYkgiuPRRhBEUC5eJXY21traHsjBrpnAYanH+Yu1lAMRvBN1AwqpLFQuNmKVWoixMlyTP8rJzMSX974vUdH1Rnzf3ctk387O7ux85r2Z3cA1ohRDT57xtHmdsX/9aWpWZ8/Zv5g1mew/gpv+CV2+1jKZ/oKubFxqmUzN61q90TKZGteljbo2p2ZqXMeu1bWhZmpelzc8aBY/TQ0Ig6eXzT9NTYl8mqFm+huakWZDNVPzuloHDQZXWiZTg7ocOPOkDcyrmRrVNQ9a1OWWydSgNhJow6F5NVOj2kigGWqmZnXMozYMOjTUTL+l9eObpSuWa5xAOzzcLkz5yZWbx9db/4DWN90PajKNnB2Ox88KU6bazB+281tFkIt/Ln2htCi+RNC8DoJNW+kD1t80owF3/vqaPn75qF87yC29Q3/quqnNti608tbFgBnBFTf5l+eRs/Fk8o4coKNPltnBTo4nZne8HHYQK45MZKEVzk1ZREORWb16h8XLmpHEiemCsUS8V7hJp6fCoEYpAR1v5awLolXCItN7kTOvflk4vpPyYm9LFgYCHC53OJaFPqgF1KOxUR0lvHXoguJCGak4aF+CJx4BHo7VkGxkYJWHioYFkCUTN8qDUh1y9mvrW/OLdthv6A5NAmhT/3eT+h7ruWKbmofR4AQT1G6sleGouY0xSCw4buJtQ8dBAYAfhyUtjAAJpGx6WmV++OYE14xLygYR2THnzD63Mh6vbTJvT5XgLbLVn0SNx4/F3aMNanZH7FJZC2AgCWRmB0CX5+GJ33PKwviQngRCMZUCRIDHXOIWGaNQBvQ5SRBDC0cHSdouGAFutnLVusMb6ZSh0W7gjOYFqlMLBt6VuU9yjpmcHrHZPj2W4YAbGlcQgZnJH8r8VDEdfnDM2rgSB/DMIGqbUlZ/xr4D5wiNEDeydWvHC23EAL3V3Yuc+WnoBNweg4RSiAqKNxR44C7WUHChjCWAiZMjSQbiIfxx96jNI+FstIlOWe1I0IUYQFgwTm3FYDnfmcFmIUfwOjX3I2he4x2IR3hnNOfFZw7MrThYWAzGnqxPP8TKD4AaUsGAPpKJlw0dBOMBloOQEM6pBLyJeFJwB2TMN4KWEH94E9C8IHA29NqhHJRNc0sAhNoxsTGSOIIYjLFh0Lnp0QvOpzadyiJYREaMC9h78ezciAxFkxZtcGfZylQ4fCYEmOFrAm04OADIUgr+AsIscYILGjEEabsxhCJ/+HRukSWWUXcsyzoR8YJEcLQUly1umywa7oLWa/HeulamwmEX8+tkOBhG0AaDAzJztpY3j1xiItngwIlEZZPnSgvEWt7Y4PHQK0GkxIjLDtW9ENZD7MVEj/D6oqEb1lamKvTwgAGuipx5fXaaZ1p1YyHgRYMw4SMHCDA421dzYDOg09OGkFrXCGLfwDkiFlBJfMYhTgmzIKwyejZ1OpM1aqxRZDtUSbvDQVQ9qUxHJ8XPMVPuXo0W2a9dVUR1I2p1XXuvZjoqVbpbIFO+Xg3gEhUot1MFbh16zoI+QWYYnyxdIBfYfq6M/3bZ7iqjAzLkjNrKh2Fed+/Md4/rhNrbn2/qVYYlmX6f2R+W4v44Aa5ovqfE5M5dmFcQb3l7tXCVspkWqrdzP1k9akkPVj93pWJSruXzB7eSNnwyLlNEV7YnbWHeP8gZL1QwQCsd8cvXkNbi/g6fJeB58n3YwX8QA2+vt8u0UXyuo4b4PlkfOgijtrkUJWXCrxYPD5oQSu1hFZ5UAwNedqorVn01eOx6sIzlpwh7y+0Vg+vMAyg97oYm8+pW80703auNo5PQX85RAt6J+KEM6KSWvqpaFjPIa/Fy2CXh61JBsCuicYXPkT4frv4nH4OJ7cXT0UVIfqhtqi6vTNr4F2agbqFeQJqPn6lGFEDvBQNlTglyB/uJCda/eRkpDWLZtd+k6g/yk8iCvYhfBxUuTk0Xx0qXfZNyoYHuq0SbjhE/XQn84WtmiqD4KpQsmb8tWLhaL59USQ93H1ZzDeugr5XpSIRNUpB7nrPrcg6g1F+vn37z5r3XqRMPd++UruPVLTtzbdVBnzumo1XZTV8qV0gnnvU70Pk8sLvzcn/UfvGivTYa7e33+73eu0fVnZ0ZcEWoWLeuB8PJQcd01LpexLSiCE0jvZxnoEHuXr8XSWvPSHva702n0/7+3lr7/fs3H1+9evXx1YeR127RMR213PU5ak7+njXrd6CxX3ya9p7urc1IW1skbbTWfkFa23vdMWWgsgxJVYgA6snL+Zcds8u7cTiZ9vdS+HyyF0jz7O0/YaS1R0ZaJoqsVfRYJ2iGW9YzUOduDge9/mL4DKT1gbSXFj1zkWctjtVonOaCsh6rudvDetJ7OpphJcJnm4XP165jykXl9SKO1dL6T6D2YFDXT8NALYTP/Xn4FAO19gfzad/YO3+WqYEgjJ+FFoIoXqEWFioIop2iCAoiFgqCjhph+xX/cpWwCNqICgoWVhYq6hfwC4idh40fyslk7jZ7T3bXVZENZHJvktvcuzfZ+eWZSfIaa7Lm+k3XKGGKGslavag9ZNK+sIIxTTt2MGqvPwwWap93TqTVZXTt0e1rjTcBjSpGbQuT9nL59t2967ZprG1u3rt768Vj99Y9+czGiPGML3fYCbT6zD1Y3Lp975pdP4mialWby/9GcNuSurlY3Lr74Bovb7BRa80EWa22aJprD+7eWiwUMbFqUTsnz4i/ufZysVremKx6W2jSXFAvidZ6seNkC9qnH+zfhNr4bNEPWu2qdkn+M4Jvk6qN0saE2rnuAfHfW9mdUBudjQi1YwLalx+MWqhqNKE2BlshNoLTgssMWvuI24/NlEDHaCNSNQatJW05oTZOGw9qp5g0eZTyowm1Udp4ULvagbb89nhCbZQ2HtSufNPH2z5vGqNeugm18ZgbC2rzKwIal2v3xUGz8tqYCbVR2GhUbX68A40fOKqkGa9q7sZk1dvCpyLTmIpR23NRQOPTUPXQsrsLWZlUbRTWImYYMkVOaDM1oja72oLW3pdi/6wAJqgZfk2qNgZzGixFzVararOr+sTR952jMrH3osaM2vTHQ5UbLVTFFoqZFcWoEbVzAtrLT9c6H7VWY84mVRuHuX7VI5jVqmqXV48bbXwGdepyiNokcVWa08A5L2iGXxWido5BY7vjHWXEVmeiGbgI1nQd3mWN0pv+OeZU/BEqdupf+E3hCuF2p3S1S33ZOhPoZSHtkaAVqBqvdLUa9faR4izhKmXGjxBXSkaRNj5Gvp2gZ/QMG/H3cBcpj2C0H9xl4Ae7JGhL9LVWNeN66dNWqWqC2hX2LlQ1mRyOZjYEaJRBlP5OESgaozxueUX9J84iUbhKkT6yPWqwQlUzNaraJSZteUJETVnTq4FWz0ApP3iEYKWwy8eHEm+Ko/EPsznl9xJVONFHyffgl4KqGS8Ytj7UtvC///x5fKaqFqR9XmbGoShalNuKlse7GB3sAwJZdhyAa1F9okIy8wNGYa1mZMXwT5VnoKe+/fy5PDDTa39W5iZQNShqwDKjkdTFfLDzKgnflRdihCRBDzpWblnY6c96QVUT0owxs2psPp/v3n/k/JtXy+XZ2Uzd1LtovlYjGI40IVRyrhpto4KCPKsS/xiOCNcUpRqzYG63UocADvfq3qfzd3tMDbXaybNntl64sO3IkcOHDreP4Hj65ufyDLf7y3+CmL8xRemER8W1Tj4bE7RjQx46wvUYGLBW0IBn1Ll9Le82rYsdahI0XhjRjBpQ236mfbRQ77F8P5fH54KaOKl53t+Ykj2ixDGFh2M+QZQnJSq47pS/slFWziOZRUZ/8D1FkK51QYWinVdxu33Phf4DX74++/nzWNts2BQ2QU2Xv5+EKLsxTwxl+ymIQxEFiGf5pWVKCBEVjEWyusU2n0AbXanmHuj200qa5s8T3KaqJr56r3kZvyRalC7LsxIlw0dFaOXVNw0CqjmOSNmeUpFsR72ntaoZPQPVXGpMBQmU7cDhfv4UTdNaTTyUtG/kjV5XKx5IVJpUxAtBBfpT2/E9ZQWqnGikNV+64fdSJFPntJCD5fXBKG6V3C3YvWP9sNEzJ7VN/NNZUKvhSAI+ubhQtLjPske/yzflMC2/tl/MHRV6kP4qAtoiMDujqaidaWKqBbXZUdW1CwfWTaZRB8Vvp5dmHGhahjf8UB4WZBk6j1JNZeeQ9Je5nfKQUfIeCoWr+eHI80pOi58OOUmf9fwV7vzojoM7juzf02tS8dU07zrnjQO4ACOK6z2VxAiDAhaNJiGmBBszAOFaMqt5cJJyB67k83+GQOyag+XP5eq7W7Bv90aDMeqirDh969rxpD8+Syd8SwQ65cMFTENrEg2C0MaLu3yhly/i8NDLQaJsQuNwroBqcziHOpWIFWpdFCtJoAO2Pm+RhdNU6gIYAh60BQOOo0dQf0iz7wWhoGiZAoWfNoBLBD2kq8K4glGAiG+BzwMdwCI4BvxgeUCEXvY3Oi3OnAoaT1Vcwu0Zqtpa2dYHShiZcBD84Ol7P/OxRmh8s854HvbhAeS3fpL3gWh5iilAotdM6LtHkgAz7ZIQelmHtkjx7pGinvdAk+47eScB1IBp/SwFpJNTtlxX9LDJNdyK7oGGJmTJz0qLW3PkB6WnPz0CehjggSuruhZMOvNA9KCAnvzkWfQ9YM8eHoIp9LDfhX952IJvXWG86ZnnexBu9FMX3IYdeYCCX/HQhjjLqtMi20kisvKu5gSqImwbmTFq1qMWgoCaRRjyYKS9OIWjC0jhBFu1G9ywEcDodvAXUI1Pm8DAd/kGGAX4ivjBAEVB/9dgRq4xYs50pm/trFLrhFePCp9AKQCF4uHROW4RwygieQG3fjuIXiADyFAaIOiCLewbjyRUKv9rqIWeDZ8BvNLCqGHGBVjDDdgqaiYJVEmz/FPVHxGFZm2Lmr6sk6zPS6INycZUBGPb46SHp+8DyYPY+ylkKsAy0IfNcwzoF7mLbI3g2l9BsQFMB2sC8BdGMKgpg92BIVwPiFO2nJEYasFdL2paTK691prNw4Ih1gYYSQAF4AnDEda5ylM0J6eI2PCIEnJJgEjQtRpmNqQkUxFiyeEnaEDvsS6QWZBANWk6UQlGTWJZbwK1bZXGfvJSVM2yCWrRMcAhS4gJDDFoIpRRAxIEBMWrrlBmU26jZxFycG8iWdhvxEyPwzDszGYhkaganYTKGrcizUoc60XNdJLGZr0WOxrSDmQJBhIwgQ+nSyrkIUpMUEsPETgsx0loBzUrhCqm6rKKyEUHIukIfgT3sEOtsaIPRknjqd4EavVYkLrSySp7T5BAcL9xClpRiqDCSxMAkhb77KCqUZLo+DETAzukN+Z/bFyQZ/x+bEjvt9PISQKVuNV9BmrFRZ1rAuVldA+hFolPGaIArEwEhhlPdQ3BhdZU+NO7gd7jhrSOyqt88srnuqRpnDKmQSxDbe/sv5keDCs1s2LGDWsCRqZAcvI5FMUHK7oiRUgnYeg8MkFKRxoLnMupeW5UglpNg6aipjVbUfx3zf6bqaR5r1HVkrCUfywfnSgU+RjlnfhTj8p/OdEjJojynqhFzAdNeStEbc8v9qxlR3UYhkZZskDTsriXDWKB1O+5ErLU/fxDfv/OhENo6pLYtK46j5MZWmgT3PjkODbdwa0FmMmopvEGmkEXiZvF41dC+Mznknav5OiSBZarWo9jEg2nwNFXIqg91SxIs6TwzZNVdS+9SfqmtXUYQAE91U6+EEHtqdZnqiajw6yZ03ea4TrLxbGuOQEqhmOCKn76SgS1p9ryZPn2bdmh6kNC1fo5qtZ474+uAEOq9eK9WnmGfi730ok6LGiHj6XbLIBqix2Hi/f+4lZCP71X+3GK9mKKud4j1vZqvZJqELWqrNlTbQ3CMJ/pmlxCigmCjm38JlU2IjBVPPNhVAzFi5xquy5SrfvjxLDPQGftOHgrei07igbENQUPcWagYVJ6z2/zM9CzjygnofZUky486+gx75ZlDNhGrrB4sWPv72jcU2yqhKtsK/p+/W8x+CIzVWt8gnkdF1QjRjX6oNqW5vTf9Yu3hYdjVCM91aBpQNc6e8C83GoK2ln71tmprhkL62QABddITLXDm8/QWesaVI1eC6CS+fmts92bLu0QDMGpRmJV2539GHtnjbQg4l8A8cKadJB9/PqgEtcuLkAr1dWI3mkQQElEtUPTeY7TzjGYBVCiEG1XpAWLRgdZWaS+9HkHfcVkEX7aJigBAoENtnivdrz4SXR72wLbJ8EomRpuxlMQk6JWItO6YFbF3jL6iTTTwFxhBkopMlE5dDYg2jTZLJXtHTyj2wIh0hc7try1Zm7W/ty9FeOn62r02aLTBlvuEs9OvoJTk9hmRTVQLDKOKBQecYss2nIzqwIFihGJAtSMKDLvuaq1+1PnazibhdHb1hJGEsL/UNU+MDlhxjlBts+CCbOCTrUnxjcWaf4Q6ULV8FG/QBH3Xc/dk1TMCI5lXXtrnRlgHt34FvAmDJ07eFCpa/i8MM7kb7Jz1ndyMLYYRgxlPiw4GAdgNAzrk92N4xN+FTNhoEJTvPIZDQhIgeBA6IUro0VJbfW8IFoXAS2mWwDlyKZ5qDiPV4BRJDtj4B8/c0c84TeWRuT0zenBwC9x92dgNrLunPfPgBsyHjOzkqpBJu7qhn9yNbTnaUXbOVPAPLyGeIIAqsCVvZO8vZbHRBMBLtBDZIz9sGk1li9n1x8BFGoBRyp/lQIurTMGZQgQ4rAxhwE1LdsIYJz1DAZKqpbBCfC3G0vawVkjWw+UrF90Lq/bYcEDm+LXSwhp1wMgNDkJdnl5rXHm4KqGtOAX/9m5g9xGYSgAw08RMyNFahxsEcKog6iUURYVyLBkFtzBPcXkAtwiF2DVHcecZ8elTRMiIuFRLb2PtKU7S/5rO1Xpl9cOk3beGtzfWgKXKDUympoF0/D97dIoNTJTarC9vXtSamSm1Ib3oSlcRamR2VITu1sPTFFqZLbUILm1fVJqZL7UIMVf3Qq4jlIjM6bGb/yhN6VGbqSm7kwNsgWH/0WdhqjUx1ErSs0DM6xqkOxgfiKOBV4xiJFVTeHVmhta1bwwTJaalppI4EKczt7Zkifhep2i9SpMuBDvqSlkxox3rb6hDdQPw2ThZ8NOI4wIM/f/4VvwcJVm+7wqpWyklGW1yEIeg3Yany1Nj1rRWc0TmJo6X9WUmUgYsSjBteV2le7yUjZ1UbCjURR1uQu5PavZznRqSik6q3miVcOpRyn1PoswomZbcGsZrnd5JZsCE+u1IzrgR12tuVAneszmB8Sg1HzQ2sJaZW/wQmOpZYzl4FScYGllU7C+67pXo+v6o8HKVJlR2txOo6ZVzQ+tnTj8aktDo2c1XjDGQnBpu8ryqil63dnDZhNFURBFmwdbGzselPa2gZp7WtW8YBJDb5N2+nZkVYslQzUHR+zTWJWsextaEAQ/8YWi1+5oHF7UAEdPG6gv2mHSzlxd1ZaSGY3D1uIwxe2TmdKiYKBzC177z63RWc0jI6kpuLSqmVWH4ArH/bPERc2Wdh5bNMRGqflncmpJxT7IObjxhG8K5Cm14LNhFz0cKDX/TEttm0l2rqhSAWj+1B4rWWBquKhd0q31Zlmj1LwzLTURLmpm/NUvVDh6luDp12PVML2qRcE1m7fWKDXfTN5A433BBsU+Bjeenr///tMd7QZ6KRpao9Q8MzU1xCWzJAdXls/fMLVe76DBVZuHHya1wwul5pc7UoO4ZEYuwBnxj30zVm0YBsLw4owmEGgCHkLToQQ6pKungsgbmMtDhHbuK3jKC2jylsfsL+lIm1zdq0lFrVY/sS0LyxGnz3dYJ68323vAdLR9EbSEW8uoJagBqIED+LXYmanZw6S+s2CtK4uqFzXPWkYtKWmoycTUY+TvCFabrSntAX5tXlQZtb+jIahBy+k09lfsi/WkNq0FTRZ+7RK2m4xaqlJQE3qKv15tgRBagDV2bNUlaR61l4xaahqK2u1S1kVgzXAS6tgBNqcz0jxqTUYtLQ1FbRY7fnIMNVUxt25J5ClxgKVEHjQblkvmN9DUpKD2W1ptaniy0h6Ytq5rsTFoEBaC5wCamEaKGoLo1hSALcyhIZKyXMmGEJpRu0qkXfBfUGPHFhLsAIsFzpzA3PP+YwAds4k/E42hQ6RUREetGQlqJ9iKOYKnDeqcHGtwaq7XzbdRoy/MSz8zWiSOWis6L8vLSL+LjgpdhSNdYRfVq+1GghoyopjO9bRh6tapLNvwZjD1pDWh1w2jpqNAYoSJi6Qa+r2R7qBINJCkkw6NTqqOGe8HPmEkmistlDs4nQbLe7P9bjwBlIWcaG2MqSAc6taTdnBTHezV3O+VLdFj2h6YlCHQWhP/nzryJGwvUD8/I50j0tEbgIYkiouymk/V4CH7BcQCap40bH7fvDFj9qpxA1EUXheGTUgZcO0ukCLVEhchYAjp3HgYcCE1W4q43jfYp0mV0k+XWc1ZfT4cE3eOroRmpJk7f/ebM8uWD5vV2NWnz18uL380+/b7z0nRfj0WnfSH0nOHEI5AxsuqaVxN2PKVjxnWLKMCfZFkYGgiYcuOchzhHJKemaAbS+7oP3Gqr0ptFWrtLgra1HmbyrjbbtZjV1fvr6+/7p6enh4fp1LKdF+EWntOLTUcbEGUI36xCBZuB8StpntGKI/n5IqXEMZXNSKDrIEDIjPJWVcvTo5w9HGSi4HFEmfvOkBL/9+9dMi6XJRxXBdsm+3uYWxWBNfULm2QgqrV2ISxEl5KJuNI0JyGYI8YJd4vdxwWHeJsRcFZwolF/BNg54InPSfAcJ3rkd9psqvZVA4zYRyg47gq2La7cbZ9mRmbUdOxP6cGWg1cfHd6MS7VPF/c9qSx+50TVx2DFjyzTw8c46DvUNtog/HRm6s9OzDFNbWXlHxqWnhHCI6lSB/mpF39cNqPK4Lt3Rm0/X5WsWm+2r0c/3nmVF+6VJ0U+ixysDwm5hzUkMGdD2bGvrVEU2BWrdM8zBz03AvhLQ7JpVbbHootjRd1eLKnDjNeLViKYL9L2e9XA9vF7YNAa1ZOW0Na1katvXGopmR6U0aJawsLa3iqzFbbIfENiyetZQqyjr7JLY3QuXrUiJSEtioJwfWm55Tm9B5sG83q1p5wT4+xVXBFQI+zSpSG2kKaUFtgu7vZ/E+7+S7QhNoyynYdS98pR6blasCC5o+bXBunyBpQnaUyzS+X+wGIRZEKDEjuNKmu5G7g+zjwco0BTdjTF5sZ1VXR6aVd2PQDWu52hXoL8fMBejwpBVdDbR2wbe/GEdKGoUz3XKWPvpRjnxkT1+vyqfKdMo4HnBY/4pDb+BwcOPAShY5oQ5SHUF2qLDvhQ8ugfCa+zJQ9o3Ld+D2fGyjnHjvroI0BBzsfNYPZWGgjs3sfSg/agQjOsjYMa4Dt485Aa3YaLldDrafLHH2/KkBgV8EE3vrCwqHqEhvRAoWowFJDRvMGFZhBC892+6i9ZYJp8ead+iADVvrMW0WmrIB+4NFKvZrG6uvm40Aoa1c1gsavtaGZwbZ72z91+ZEGaB01VzWlCiBPZu1LyEJ6BZxZbBlriHjAG4FHLPicBKoGADJEvjHEcxqjB1oesVGcZqYgdyqa5ShwpZTTgG7YADgvLS7BcrkoQzOH7eH2YvNWlj/SBlk5szYny0Zh7Xz5OwYe8wSnX2m2ynjhmB85e2V4cpjmnlDW42P14DPrqXF3SIMF2nCYGDjLpAxN806jTNwGaJVN1bjKIHsubD/f8BTl7AQ0HaAvqRrB8MPHOYPAVKtkLAIQjTiMQSx5hkSSFXkNS1cy6Rx4QgFgmk9MiDLUS248GEK2lTD+S9UStt1f9swYx20YiKJKl4XbXMWtATfuUgjTGMJWKXkQnjuk+Fdj+os7FgQqZsCfbCJb4ZreeXxDOqfhoDz1TrIa7dV0oVMZ8XhVXaQJKqMWTJ/UYinReifnj8ug9whPSl72rUO0AevI7H5uKV5w1Irz1cmyJN1r1GqOrYY8sHY5Zsf2g5WGYJpsNVpMdCh6pZR6acOp1zYBPIJlUiqkHT3HLleMNEJutiSpHZZBXbUaQnJ9wWoZbPcjmujHbyUNM0BKJ1B6b5ujSx61KpLDzZKubJYZFQ6QMQgjSMbiiuBxCnu5eSqUL2fkS3uvxmKrz9rHhZWGTGWrcYyf/6aybxpHRz8zXO39c6JNJKmY5cevyUtRHxsrLTd20WrT51OOY+30DWmTYTU7/MPgrSwPKt4FThterohCsYNtJ+91wNXfhmFplDGAbtNeLf12Mk1TTpqydv81VM0ZpDFoIabVeBnzGqMYK5pAy7bZyps+ZWCYF1d553u2i+1/sH/oyCrM3yofhXAXl99aLabgtctQM1fs0/TgqaAVrUaAbd+hbdfCSOcvHj5a3rK77O53tB9RBcg6GPG3NPdqU8o6a9ehXk43lhpAM6x2cNiFa0V/q4w7dqD7X6ZsNWSNtftpqJbrGmlxHvFX2Wo9u1J/hZQ/V0NtibXqWrutkvamVuvZEMNqCpseDaru1n5+SS1TWrfaf5BYLAlB0dhq8Yu1Vu0/Da4kNWCGiLgw3261BhMQY6uJZFZT1qC1ih30DNSoeYL8hJmo1SQ+01Hbl/GIb+QlZf573WrqNdXaeaiUC1BT0shqorPE7LvVWogXFxl7bKDCVlPWam/Wbnn/DJCR1TBRJwLUXEethXjI7Ktoc8hqn89auw2VQlIjq4lzaZ5usVpvoC0kWc05H74cYIuXudVYawNSGTWArlZzIbKw5sNVt1oj8dCEd7DFXEfTaorawVabp7ksizT7vldrIsFmqRWhejDGm1htIqstE4yR2cW9gbaRiFiy2pzkthCy2nQYan8eUGOr6YIISbPuqDURH9nSBhq+0p9ktQW1kOqo8VZN92oyexhWiw87am3EQ2Q+Ebbsg1ashhyKGp9AHVZEmnVirqPWQrxDsQSsIStWQ/6t1XAqwEzjAukfdjSSuVhpgw1TxLyv1TBBJ2ig0o8FrUStJk4jb2s1nWP6XK030L/smUFu2zAQRRfZddtFL9Fl0V1XRdEDFBIg+AaFdQUte+7G9G+eJw+K6ipxZcMjWxySQ3LI+fxknKuRX/xscJSw22ZZDVr78eMOtWuSXy1q8MPW72qnPt5Z7aqkBUtQ2zKrIXg9dXfZvLRgXS2rTXeoXY/cBqu93gE65HtZYfRrFntvqMEPu+titROoDS/OdCj6GrANUmTtJjY5a4Blexc6ZyOShYnb0GMsujxdNav5AB0c5HwFt5L/d4IbnKK43M4MuHosJ2oYphxLzLAaNHrqqHJv2CDVFuumqErTkaWgtruKu1rzcje2FKgxt7L6mjwxktHxiVpDRQ2YqEbU0sj0MRNSGaMIEzLFXhU0ldAbPpRFUFPvFjLJuwwVqLV0vA5W2zVHx12BmkhK6Jk7LOZ3pYNtuIBFNZMDMeTBnCIGKq09K0zJeYsNNKOfggGD1oxMo9q4jOEy1HpX2x2j+JjsNs1q459L5ShWy2NWM92jGxZRULXVeQTtF9D796w2rGG1wYjweS1QaBEoeXVWGxPFceus1mjtcUtcnNUoPZPV0Nazmk3JzbFalPNZjfxqVqsH6PFY2j6rtc3w+L6z2pWy2gFi7bN5VjtuiTurLbPasClW2/2BWrSts1pzsL3urLbEat3lWW1YZrU/0dttndXi4PZZbfivrEb2MqyG/M1djbNpt2lWG/M1q/GNCF/akYiaRyNn4iCvhsos5wf/IqYAGiGe5yADGZE12dF+SB2ZptO/lOQ0VIXabmyf7f+uFikH6CBGU/QqTwhhgtWQD1ZJmpIv4W05xiskl8aEDh/BRvWMXrwDDhK1loqlSOkPJBfusRgvLIkRl88wJMWXtJkaQ4yF1bb834Lx6e/P8TGdxlNWM75ARpNuCEJARYraE/MKh7R7stObZgAyo9ejK3bgGJZFS2BqGNM8L/qnH/gmHuNdQR5zp19qYep0hxUDJYlx6RTiY3uxIFML2ThOx6TB7qBsl9Wafw1q8frg/QCtsPuasPgJJFmqDwJYwVLM2avA95T1MPgjIDlP6kBN8mmLgXoEEMc6oogwRKvFGCxApQMTowZXmBgdpRM51YRBygYH6KmfAq3pCLMxyNssq/0cm6NArXk8ga3E6VncK/QK5BCIK01i2B46RUscCAwj5o1K0NNlBH8CEyrK28VglhQ17pA/aQOqBWOapw4Yp7v0lQp8B/1lcnDkFHhNY2I4NtnsXW1ECtTqehtEAgLmFCBYz1tCj9QTU2w0JC0ZyS3oylKLK0NZjFYtlVQhyv6hczjXqdaSafzZeCxQe5Rdi95WWS0Yi5tTMhMT8oKQOEYql9q562Vx1I1B25sUERMG/Ktyzdziju0oRYwnyyW8UjRVfohs967GZngOtZktyMq7ilpboHNbM1ioJ0REKg9FRIxcHalyHVWGpV2YxSeO8KV3nHRjg95uqVLrG1Yz1K6D1Qw1puotGI1FBxJ+0cxZsFD7nCEALb5BLXSTKzhROzCMFJRKtCJlJ7l/wVV9aTSDthVcK6uNhhoBEYi8TA4UAIhGNTaoDoR5FOOoblIwC7UtkwceitTkB73XBp6paTAF7tY8jBVTotVtslqFj48uaiv1uEUU71HeNY8wJEE2oCugsBT2oguwns8s9GRk9zvc1UIWsePRfWLQ9+2wWlkl9Lx8oPEpvwz5APaSwXdaWBabFMEST6yQmBtMwMY1lboniJ+FWF+xMPP909cJjHDz9lhNq1bKqCSvdRQ7CAUKrkmpjsuoVBsz9KDdMTuwwf/i1bC8dDmr/nqpZOpZ4ojx3D63wmosgC//KBFsHFeTmqgBA6Exula+1hrWaJBtIQhZYKYGOht92iKg3QMJWEkNXN84ZHI7rNYpTKYDqiEuwUBSbGUijEnAM4biWuEdXTOQiP9EQ0V7+Q9FM6yxqguvBir+3NZdDfHeo8jiKKF2jjz5uRU2ZihZBq57kuios/WLfwm6DRZ20bO3yKorx8o1/662N9QWf8J0nhV2m+WsFYvHtbGR6+LlThapWQMsLJVHEbG6CtVya6z2HBf9bNRrcT+/dj26xVFAllst0+4yhRh/cwWu72OTef6zeKze3hhq+0YZ+y2z2j5eCmrIGTHvbae20lXk0mVxWJaJwl67ifcYss5ZbxO74259gLYAXhGr7Wehtj7OyAX67ZfL+1Vd4Q2yms768y2BWkht83e1/eEJ2IDaXTYvQO1IFAnllbJaP7yy9GdUnzX+BR3dylhAbX9DrNbnlW9eFEpc6iwpWecW7XALUelCz1JV38sRf+2CfV+JOEwvzWrvL3BX6+cnrMiy5q5wO0fGAbLdMr77M6xRrZ8PBo9nXwxRmcgO5b+x2sebuKv1C5WoK0REvGx/sTl69y1bXprVvr4Vq61Z643cgNZ4SHZjV0jkwqz24eHdpVitV0aiitWE5FYeYqVwXK3tt1/T8Hy5MKt9evi0mtX2L9/VHFlKXLAMMS4gDjVZs0vfiigtOXcae5NUAIHa9dQqidbp1sSozbfeE9f1VV5Q6TZeZyf56fYyv6t9ffi6ntUAG15PmThL3HesTMsQLGwSmFMgoPZYp78+ma6VYNilLPmaEndccjC6ilK8S8vDhy41FzRG7AAeLYLWLjXNFO+Yal7p76TvA9QNyBhSQEPW+ilYxK8lb8FqH74/5ARdxWp7+BeolRVnzdsXVHRgsWqAKesPm4DbhOC0jhS+oR5QigYp7Xuw3NIMESHmDJxyZlkppuIEE6bFqCAmOhhMc+HnOKsnL2OQBqxXquh12h+ZbAqnJXkTVvvy8PDwbSWrZSvEz2kPq50uHQudoqKxjVnjcpqR0hukmbVMn1QmBIQbwz/fWHc+weg7Bl16gntbj/BrwWch4KdxmEZ08j4GKzOBUjzj6HBnlekqjSY7hSWm/Zuz2vvvj1D7/uEV/gI9bI/2mh71g0wDAiZYCErYzWVtxRy1LKhELUOwuICMEHfVMppaExwAizlFNY4ceximtGwvpoKOB5QW9KAXSBdLNczHy9ig1ljtALhwxBvd1b49HOTb6r9AA7UGsebzY8pqM/+CIyqJkVtwtngV6xAqZJSiqwDgAF4NpykIeegwlojMVbQOTWJLrYZOLbu17kKe0vI4Bp5M+yPWppZwgL4+q33+3qD2/fMqVmsQGw/SoLY/yvQcGGTqGlCPlWnOTDef6FNKPXiNIiF89tB7KZujJx45jgdagjpRavXUMhRN1o3YDFNjiRxFLXzt/fqs9v43O2fM40QMRGGkdNemoKZPia5LFUUptqNYaXqkrfgHq/x2FjPsp+GxHoG9dzngAfHYHttj++XZ2dwxHL5jOLaomgfouPujmXvkiyY1ikGv4KSLKNJCWhlT+hQGuBlSrVOKaSGmEtwz0qF2qhklqoyuB+la68Pefe9Kyi72v6tdDj9wbVK1BeXdUYy7B33/9WFXIQU1FTqYUk6cK9yuvuibQ+OnFi/pgiDEDZPwTXsK3jXyydoIx2RmDGvrEVTkwbFYvVXtegAfW1SNKMsbxNPtFcNMNV8baFX9fCIhu9H1WFGx2njCZDm0xJmrYTZV96muAr7Y+scsxrq43jmKwJeeqgbT4FrbXY0o1+i3WFHd+61dU+GqsJg0/UOiyqvHlLamWGtrLK2pti5YzuatIzpOaowOFqmGZPRVtePlEHFuuqsBqFZhVU23gqFu4pz/2TggpRMJZIvkuexqxAnPY5uaPwmB6+GubVVCR6gGz7rf1T4MzjBwed9wVwMbqpbsjuy9UiXfzXSchKCWyGZO8pz8YlSy2fVCPxkJe5N1h2qgr6q9v8IwMJw6qxozS2QLs7q5my5xmAWbQlSPKIiEhCoMTOKiTlgT4yHPQGTJbXGb0BJS/yzyQrXeqnY83+BXwOV5H1ULrGBVqGQbsEs9hvbgCdSQB3eerUlODC66MXjG8WJhhjrm5f/0KoUbrsWRxnSHI0VrRXICWyzdWdWerxBNcTn1UzWYUFYNxO+/WSrTx6lrB15W4N3CBb7r86w38ReLPBzZTvn+meERyDKg7j2tItPMq0UomTXRuQE9R1E3gqJbn1FJae5uXsW86bCAVdxR1Y6n63BIMFxPXVRt9knZurXoE8WQsXgEeq0b46UsNWkUyMAMb4OLg0Zs7+qBzngOPWHPRjSQvWNISszwQaCx3aRHWjOXEW4WuDcDB2cYRd9rkXsx9H6q9ny+iKQJhvNTF1VjcmC1ATVxDcOGu0kOdVoMaAFrqYw2B1ngAVyP8VANHYA64h19mRjTi94EKkSBvUQPUHzIS0i8g2iENq+6sMdd7fjxUuPZ7cp1rVHVAj0ETDwFy6wZ2edYYupDS2CSM3LqwZ7rnLa8SXSs1M8klZXI1w31BnupGre1baI9dfsEOv+Y39uHjX/PXCLmvVQNsl3SD6Dtn0D32Zus1zc7mr0ClaFad1UDH2+Vx2pNqjZDNV/Bt64JewZuvcexB1M1vi4A1yOVLaq2Rj8al4p/hmj2UjLWQFF7GVUDz4N83d5P1XjYofdrhb0mHS0ttoaT0F6Ib0aSyyWjznt+WwCeBmFab1VjYuWlMmmT4s4EMi22UKAmVg7tMBF1FqVZvExWr0J6e3lV48e9YVp/VZP1T1SNassFJy+ySDNTHwkOW9McfElGLmdK6kYdXdIQGAZeLK9wcO+7GjiFHyBqUbVpDXKCarJ5uq0snsKkfUK0pG1F5zQKDbJKfaUWUPGC+oyu4ieNNCQykVy1B4v2CqrGT0deKGlVtalEPTnVKosmyK8ayY7rIFErreKGCWcwcyjZaJi/KRhNits/xGs4zA2qIRbTtNjdVA2U69rt6V0PVfPX2W2oliB595LJL0j5YZVnUoHNAbktaWdJtjZl9RZtTDGjD8X4hv6qxhF6bvzt9mmJcSXbNBcbqoF8v5RsD/FUzv4wjk9dw7ffdrbUZf62Y2XTFiAZfVWNX5q6Hd81qtoSZiFbMeapIFDNHuCp/yM9rH0YLGpWuDY7z/zv1E/VwAd+Ma/hrlbinUrQ36KeSjqCT+N/NOPT5/59ls1aMBdN8x2cOqsasvah9f9X+65pkyfzd8Op9pW7s9lxKoahMOtZIIZZAJsR674Gb5AFUvbZ8A48PNWZT/5kwo9KS1tIL82NYzuOr33iO4Ng9Sg7gQY1f85sKumKuYEgD5RTbNiFf98w4AQRbdnH3mw0yZ2UAzTxlT4tw8uimr8MfXUuqmlhEoSo+/qLPMzUWNxw54Cu80vfFUFsKvfVd3GnPk95YELAmV2LFCeaEGM5XGK3a0rdBGw/U8GarDg38yB3anABVKvPsf0VVHv69OpCqMZ3WU8mjTXyBXLs2RcfM7BBKAn4JmpQ7cQmXpyoYRnutylOeXlUQ5P8M4K21Fyb0Yzp7iCobzGteDO3W+l3tqDJG/6xBBJZgQOUdzlaKu57/Re+G6olQWK9cGGDsmXyqgFTEF6+ug5GKpKGXDqpXbKrZJgeU9BdWlzEgV+QvLKK2NLM6j+xZncSVtkom/A/RffM6aEKMm/dQ2TQ0K2eoJpVT2HGvf5vLOAZlopqwMWx98JJZnLubBC2KBmIp4FKHdDouj6IS/HZkCIPH35CfahblIGKhF97iScEaza6Yw9dF4ACG94Z4hUIN/aUtblJIwlxOV0y+n0toD+xVju/vX24FKqNrUSorEp1QY3RwcFoGROyHC1jM5xtoiDS1riGC4XGWK6lKdoO1TYmXwSoF2Nm4SJ5OiyOObLTCWUq5C5FbREfolsZ4qm26xCxGe7KL9Dsdqj2+HgRVNPBAYVl9RHfFCyZ0mQhLK2syGXyEm2hDXmsyjIEhtLQxzwAkuy2CIwp6JEJtRqBQnsbm+pLDg1lP8qwvmUWs2ArQ+fFOaZ7UaHqvTSWc47M3x7Vnj5+vCSqfX8QgkVjvgzIfOf7+xSTxouV97DmEmDqqyEQ+ITiivjKek2YoRol0bQpK3WRYFPpfvxSjEWqnEjgIUxk77EwnJaVQ+s9kdHBBK3Vc0hoYTRh0e1R7fFweLwIqvE8J1u1ViMGe7Ei6vEQqaTgzjTVciaYNZNRyWMChPRuAVhWhDeroAHBCjNEmGUT2t1wxqCAqsWRn1ELJUoQoafjEtX0UCYWh/yIWtbMwAXQNyMTOnbqgIFFt0a1D4dje38WqqUHMDpoZUAOk/7FAF6MISt5bioehSPGyJnVymNgYApLFuRIwytWAbNVz+d51pR8rA9fNxXBURK5ywQb5wLV4EdnbRyvED2Iph9ajEBh+9RK/U5PVVEGwTq+RzWe3XVQ7en1Ie3xBFTLgYmZsZoDlHpsgQwLp3kW6VyyjCMMsClQA1Yii9Nxv4UM/WqBSpyCp9GQpdCJuhVODIrQ4G5GYKC5sE+RifnELQjDRomQyLEcbmhgBkpNMFh6pNkN5vM+BRfN7eQGOaOSLhriZ7y6oRrfV0G1h+PhSXv+8HQCqtFIkFhPMHHskcq5a5uHNip0gmpAhDAorjXfomwYugAc8TKJ0GAA0izF0Szuho/YfLkDHVfmUBobAac5oIjOuRAGFRFmBkQD+4YoJUTag3esCVVHxF04SG/jBBYKGxhq/LGzr8SXqHatWu3p/ZtDtddvT0C1GJibSpTETD1SoclImWw7zxj6FKaoomY5PY7Um3RQesCBkiqEBX0vGhfBBUaZ7euFGY6hwlnYhAzK2ADkhR0Dze6MjRvqmTIBeFkV3RaMRmuxTlZdkVIv8Kd+eCdJh/ZchQv0V63VHp4PaW8eTqjVYt+OarUn850d5yMemb48LwTxPhIRh7YAwv4sETds8Tnxl6vT4UO95jQwAh5EKciY5AYyjl6LIoC1DIFk9pEzmgypgKyUYHLETQ9UduhjIXSrKR/PhSqsfYRXqdVAtgDb4ylvoK0ZakCEfm2RxTPhT4EfT4U8LMAYPs5IFtm6TZdaxQlWprX0VnV5gmMNUSUvKVA2I4WNchowcGj/lMSmIa5hYhbfamjJ3ayBk7VwJIhLS0X9YZkbzh3VrlKr2Z6NtHNqNeNqijkhepAWShmL/eFYka0OPoYr80RKyOoo6BHC0odab30RVJXRh83t0CLatEgbp6A1NWiKnPRaI9RVjhQJ61DY4b48BpRytLp3hNBmP3XqdoBeC9VsD4fn9OeiGhDBEwpkuWPqIEOOS59zFzbEyFyyHdFSg2LLG4S6GQKOkOlrsBjVoXPJqs2CWoFyjx+Lwg5q3SuhKm2gLuSZVqbWrB3xgY4mFxARNfYeUO3V6/fpTke1HmrGQSu4yOFWB1liU4fpd2QL9X2TR5TgUMzyBiHNaA7HDLr0TMi8IFnAeV4LYijWQmt9RqBl37F2GEDLQIWDe2ReiIJ3oam26OyScxcwQLoVqglr7y6Cah5h5lWloKXMlolxkM5KK7FcuhRRGMU0nawZQKlqrL4xB0H0C1RhMDobrxjtphBHD+Z7NDMv5ugX5CzOTIBpiWU5ushD/aM/NME18Aost0c12tmoZu1lquE0HVZQ1IKLG7ObF30hYcvQCQPIyDqCBctY+GWQSbEUgzA9BK2gn/IynUuM6ahWVE1iDmPrrGQBjC2l5lVRWvWouJBfujQhVHjCcge1Gu1sVDs2qxxxbbt8gcsXbNAKj0QAPJ8/5D5Dz4pe4KERU6BHFXwo5ZILC9QpdqGioNTKnn1AsrzjtuBGY/0BCwljReHv2hhBbRmrK7HYN2ljTwtQeg+12mVQLV7Ft+a7N2Re7sqLuASGqbv9uZQuXTy6LGGVJAYMESzrwTqFjwHjxBShhijPCkwUsLgQFhiPxEyobIENsBL3a3C4+eu4iDCtFSYSl0jl3wcUUVkrmirPYOcELQfO/wXVRv16ew5qihEaqJB0YwTM0PsVeWPE6gglCZJltSYjPbKlGhIXqBZmmZwMmb5ky0p4o2IVWGQ2z1pLSxK+xBjhCBZrHFiU3nDl9Z1lNYQCheDLpGdE5khhTKp938XP1f4c1b60UKvXfnEGbOFR0edPOp3GDHhBLka6Cr8wMIRXWb1MfhczHwN6GsQKDaAU1VPL4Bc9FUJeK4C2lbHTLIhZsrrtAYl8bHsy+NmCVhRKYgTwSL7WDJnVazUf4r2j2pcN1YyjZK0uNCZ0tO+NUpmh5oAAtf8kQQiqCm2hpkEkoQNfj7np2M7nmVgPMDBhcsCTaaf4MI+8moneBrdtllFVouyprQ0DQvSaQb851XLz6/G5ffmnUO0bu2aXGykMBOE75mGknGDFHTj8MrhF0fq2qIy0DyaiTbDd/sfV5YbJ0g/QZY/PDxzGXtuk0DSvrm/Y6/DZpeLvUqkbUWTbRhVrS44DprqpUZXtq9EQotkdIBpyRFW3YfCYcG34OTRANmsRniovtW4wk8ppEa2xWG1gboumZ7VFB2il1maoSiiroEhAQZCRqrJ+arFbIAwzascZe1BBC9hTDTViU9ZGKa2mQlUd3DoJW9Pv6zl9qU6r1jVr37SRWSZntWUPJwNZuUSuWOArhQ0sVwKVGFykmORwNSXTMXg3rANWiOFZkcvmWMItCjqr1d6ttYEVzctqNcNxv2I1ZqHn00d7o6OKPXEQj7Qwl2QjGWkKqNAtiTYRxrKPvaUaq5UPtNzCVyuzaKxmaMTtIVVoyIswgkbJQHCcHrLszdeUyrSjRiGAlAvlstOZf1tW26LGajohscmWmTJ1eEpgr0ETkJZhaWmSObbT7WJynpLYj0koEHViNSHtBr7aH8NqMEuz0wGImeoCLZocO0A1l87oyK6CNRM2yy6sMxtTsbGajs9bsFr31eoFLljyFbrahQITkoeSDyk/oFMH+ognOzUWkdbBYJ/Xj+O2rFY3sloxW/DdL/wYW569NU+W0XdOkDEtnZeUStgFo2xYvg6heHNfDW+g8tey50/bRlF83uHl9Bp4tm/Egdjy55B4lkZDlApaaDgKfLUtus0b6HYNrJ1+LeD3H7LEx7bNB5wQAI2BgrEDBNbIjnwmZOvKOoMJ2mDC9NUOVlumZrX6yDygVjEp251LVHkohkx8yUhaD9nsEuWCQGqJUJVJ7bMl8BPu9jf/b6ADXIPbxGrh1AvfnYKte6LItMYhPbA8ZlzrACSonD6/7Xg7i2ZXt+KFw+sZyJv6N9BF81wX+WpcPi5orz+qfc4ODB5W/nzKh7ByWDAg4ifz0QcUPtP8BtJvBbE6ikZ6I41pWW0c79ttl3VLv6+VuPHJj2ktdMorIdccq5HHCL7wYTohhL1yhu6MNr1401iXXTZWW2rbRjwrqw13suTNaiPOvzHq8k6t6uzSyn6EvjBw9uSTJShFaPwbTB7HP/JLASZLxonsvtZiiYLcyGwbOC2r7YZQ0zxmvfbHTFMEJI6EFFIBXmxbQp9JN6DvGgUS/FeS4ja06lZG3SunUsznio0JRVikJtL77w0l+xFU/FDJN3HMy2qSBjWtnUCTWsWtIipg49BSgpF7a+K/g0/QwrgEoRBKKJbQHNAHViVICrUW8n1NqtI6lFpt1rPXI5mZ1QzUJNgxKZBM8opF6lKxr9smxVIay/+SbnGEnW/D9oSf9L4fQe0sE/tqBmp9ZY+c5DVJd2eo/S5We2Qy+Y2s9siU8rDaI0YeVnugdlN5WO2Rv+yawQkEMQwDe7wujCoQbPEXYhPnk78FGu7I17Dy2GH3ga3mqIliq5kHtpqjJoqtZh7Yao6aKLaaeWCrIeCoKdJRSxBQsRoimAXDURPgq4eWp4LVAvm/G4Q/M562GkpqArsaqlJwnx6gEnxRI6hVgdFWQyBLbqvBVlOAx2r1CPcx22o4W2U2igeoBGyrtdYmW607YsGs1wNUgbNY92TCcKuhL8u01XRgL9gLzL+B3v0Q9K6mAyPJyClYrdsBYasJcawm87agG8I3UCmUreZdTQptq3lXE0LNaogNEEBW7aiJwPsuB4G3BdkLVSexcNQ04PWNRP1Gvy0onSHFRiy8q2nAKC90yrY4plotqw2kzliRc9QEIE7UUhB5YK7VEDh4gP7ZL4Mlt0EgiP5jOOrMYS9719/Hll9Va6oLTXmj2gh52huDgIEBntvORNoQ++LSdI1XdrWdyPrTXa35ozdQ5mqqnYzaU4balV3tF1BrR13tlxbzfp7y+HZ+Hnkop5OjRjmhq329hVrj3VoTwIYdsTNhtJ0MYx6T77+duzBxOWq3drU2Pnb/dCZs0B/bUni9y+qnmU1LUc/tk2LU0bQXdfnwdhdXAzXDxrarqslOLVMGR86gZ2LwttHcjT/TYGs+p8e7Wmrd6h3tu93T1dqQHj2KtzGWLX5yfQzN7nC+FjU3waaapWP9mUNS2EIZiOPlXLbGiHWloBlv6Gq7U/Cvg/TK6XNa4vR27IgGB5ACORVG7aGbaX2N9MWPtu0wWMIJ45JSMP5CdjdytbBLtxjDiBeyPsdN7RE2v1q9HTKvpkMc8y+0yJ+BEtd0O3dIJeOT+LHj66xu6mrsxh2mteSnr4yKV3Qc5mjBq3gMUTSbqzmsFKq0FpBrwoSSFpaJC4SxITcK22QkjgbNQVsc4lszThW7yc/mNq4Wz9Q9hKI9ZMjpcmX7nD2n7J2t2d0ojFBdky3ApFJgSoFmfOxAl81a8TnwoAbq2lgjT40cmD3bYTxpqG+PmypNGd3K1dg7Z8hzCxBwOlQY/gylN/CxP16VNFPqdoSAlicB5ueByIhQdN9dVCQq8K/lgscGqIWFditueZn/ybgVoz04lsyllMlw9+m50/9AOR6/j61GnTE6APHBOB0fFcK2mngWa1o1PJEFQxQc3HKHQHBd2gmWC4reMAVjaVMIb0TxEJdkb0SwpGaONsof8xBGDCnJJInZD7uJq+mm463wFlyfq4mKl6XTG0awDt36Y7EwBoLD3Bol4gU5dGkbIXtaLB0K5iA+EK/SJmH3YpsW8SJBpqgL351E8UbcbX6r7ZhCOt94OuG8xEswEg2xClVjGak9UBTxi1HKyio+v7p9sPCkpNk2jWKst1FlLll63KfgD+Ms8fv8VjsS+39fHmZovRuSL/h+f4Ki91GekBL8HYbc0NVK19ZHuFrpCipXKw1UrlaoTapytdJA5WqF2qQqVysNVK72Ui/UZpOj1udwtf78t76qvVCbQGt/XdujBLJnpV/W1XoHtc4HpD9e/4Tan5bqsrNPpfXBVccfRFu/sqv11+uZ97qR1//7F2gB1XKt3Nu6AffQVlz3t9oz2y3hlxc/K71+q02hFb7WF2Kdx35VV9uS61hxX/vr+YeolR39ph6IvXyhY2vwdllXC1o36H6IWoH2u1oBbOXyMLYruxpS1vU/0Cm0xktD87haoTaNhJpUrlZ6qFytUJtU5WqlgcrVCrVJVa5WGqhcrVCbVOVqpYHK1Qq1SVWuVhqoXK1Qm1TlaqWBytXuhNrSPkjlam9iMc28l1O52ufefapytQFqS8aNt3jfkpNodeunmcqSLbv44ud/EHyNfEOudCteUP0sVxMB713J8jZwJ1xYjsnCy/qThIyBU9EmRLnc2tWWFq/ArCP1QD37tXC/PtmxlS3WlNBLhOdEMYTQU6H0seNdEGRxi6V4pMld7bs/9e2o6URUN1qcAB2aG4aeTE6yM2mKC9j90Wz5JYQanFQsZr8hFUZQ6npqzZORhBr39z2Bq/1l39xyG4SBKLrQ+Svid/6zACvLYKs19oWLdTVF6SO1JU8bAsY1JnN8bFTF1WpKWTByRU1feExwAwkBoGxXPnN7WacIFV3bpNpT7kQ6LHDp6OJhe7F4VMYAos6AVjvCxWpy49iP5jtNXdhMaMMYXl6boclTehRQbSpuk7sqKL0hgYen761mWqYjIV6redl0bjXKl6gpK9y/sVqAGI7jhOoCTHXzutU0jSrI16ymRmLpy1ZrOJaywNCR1XwQq63TagNbzYd4AvXjNa02stW8bKbVptX+0GqFsIGeQH2u1ca22ghPoD6tNrrV6DTv3GpzrTa61Qpn3r3Vah/Z62m1YazmtBqN0a3VDszYa59WG8dqzqTt286t5vl3rtWGtFqTNO99rYbh4BggnmP1abXurZZRc6+owRXe+X8LHL3EBFoOptVGsZqv7rAawr3btdrusPwCcY99Zz6BjmK1oojTD+51curWauhvJe7hdXdabQSrIXdADj89W22P9Rwg+W2u1UawmlWrOaYi7Ofo2Gp7JK+9rQNlWm0QqwE1cJZKHv/TaiAttloCbez1XKuNYTUkC/lDRFYDa+9CTa1WEEtr2bqfA8VsWq1zqxmtVqJYLW9iq30Iam+1WkrJ0zkqHqXP+d1K4I7/zmp2830W+43vmiolDKXAbq0m/vuh1UopT91bLf/uAcRK0pBETzl6tVqqQdRq7+0IcsX0a5hkgxixLGRAy3mKjWkbLYsU2De/Iq2Ovg/WlTsObj+KaECISo8gagjkslerPVMibWmD3h7LspA2EhbRYUx1JBTm46qMVnI4G1/CsIcS1ROrUBjqWzPBQkNbBvXKpA7Fdu4OTW3B5xhSxlhO1DZP6cCsZ6s9n+lC2+Y5gNpiF9yYropeO/GgkOqRjxtFpVbrAE4ghIONqi/2YlZsZxqBRoES9KQYW/RVA4NP9Btb12JnsqVI9rxlxlICqKXtwtkzR7dWq4GebphLt4VxxS1YveoBcdBHN5RfM9bizEQTTYLIRSRQCFaC2gEoml5jdZTQYGft69VOolnE6ihhjWs1kxXuURVH7BL/2jhaG50hMZ/smdFP2lAYxfkzzTRmW194QyMaMt8GyRLdEgzoU6Uv+IDiC2gsxpiMmf1d++7llMPHZ73rYjfMONDe0na9132/nsMtCUIzIWdeq+tqmYCayKFWjRRtFMHg/zLqJCuTa0wdnoMNHMGCBnXBmnhjYSdAn/2RXGxhJ8njB5XU/BckWXO3aQdA2yOwm/pPRavhJF1EkuiriCBtS3ZG1OAPDjOAluNq0D91tU7nS4e4JZm7VatRtbr5LG7qHnRShOAwnQv1YVl5U9MCCJB9YkF/oR/oi2A4dE0Qw6tD+mwUlAPAmUwsEkijwX7u4U6FOfdgK1vZmUTmXrwKpLalBPKiqvNifaE6on/lasej6cbWC67WgYCaW3nUPGsRzW2TuFEsDsvAYm5yhTXjREOKPcxSHCa/ZJCXZHF5AeLHc6xL4CqEnbAuQknqcJwfeFGCScDIIG8Z3aE/kZcGejo7cu3M1UWUIDWBmnjGTLmuJtqYjr5WStIn0XB8D8ysq3W7nUxATSSoQYDNmBs5IhxstUvo46wza0ma8CaN3KZ4Eq9kfEt3qyDVJdXj1oMmttynSFWX0V2Zgwu5z6HgTXO0irS8CcxQW/CHDtTtdq2rAbf78dDhUClJn2Y6mtx9B+La1bpeGW9JFqT1+hw2/za4+ZVFhDv5gbe0PYINbitGjTnRfnjUXo9r3QNZ4W2i3hSrbw5ol4Rn2WHQ7uiBBI8WbI3cuhlVnatez9ws6ZAzJ+1q0Pe7yalwUCpq1NfR9CM5A+9tEXGLEaXJXn0GG3lbxs29lFRWGln7sfbEYqA1hNiz9B4TPtYO7SbLjSYwcNLPxfQSkDZTc+dEhjMpgeJMlCA1Y1LWbYu0q4k+SmqCgdJRo4bjnwANant1oThzt/09J+BG4rQw837exEx6voaYuwV64OEQT2EwbGQz760valnztLfnPDJMaGrM9kQJUjPudsiZSLvaz/HwCMUvGbV709OpZClTtN9vZ3Koibd5d9sX7XnV6W+R5Q0zI1nb8tCq/pC9nG9ooYJSRLIAlKx92K8Z9Vb2jJDlg7RI29miQJlI6gM368QeM6jf79PONpCa1NFwPKiUpPeiy9Hwk9aDy1Kvvoi4xZm71Wq1fYObylITpVGggAWipajxsI+Qil80rDD14d0ATEP2HGd1j5moVsvcLCZnXvC0+9GDqfq9wwFklILah60PvVvyzSyVEV1cXPSJWyoLUHPa9wJseeZG4Jz+pNIlKUxs8XFon3614eNxkhIzk6lJzkQxUjMGZl5ST5eadzbLbnvCQcmo+R5EA/bPLL2YCbSlmbsdHNQg0jY3N2oJNzTlKSdCufnmFEURcvNlN9OYeWVulmacoZbT0fFyal4PwEGpqKEHtFfGVc8fY9KWIkvj3QNRzeAWcjdSt5paLRa1kUFVy5nF7MApRmqmC5zFj+fPp6bU/x04qJSkjDS2G7MsbXE0rTluaeZuuyLilv/NDcy9JdxWRBEVtDPL2a4oRWymmZ3F562l1JJJgKn/VqUkmZ58e3nNLG35VcvTlmbu1tiFQFsYt2h5rrCmLVecTpkHZ8Qs385QGviCKxrtjCUdji513dGW5mqZa5r2/dXkwY3KLy33FnN7QpamOzuNBnB7KUu1t5kfsdbmlo+ZtjNyFrQzr4YoRWqmglkLjGE5nkxVaqq2UpK2l3pSnwfzeWnLvZzOYz/6HaeGxi1sbpExtzVuSgoz2llxzHZEaZaazigAGh6d2XqTtNJQW+rRknc58ua2oOZjnB7uQKQtnKU0t3WW5tiZdTPFWTg1gdkMNWdnmTAJ8Kn5EmmlomZ73OJIvKaT45bW2U37ELgVz9LIfnX7zycKUY6dQQXtTHR4+ONmjhn87FRSM+gsZaKGnkLtQH7AWjA2t5zd/ABuxbKU9rbOUqbmS3YWxqwBOwNn7aTZooS0E3l0Fqhz6c/V2FN4JC5LCVtTdJYoc1vPS4sqCvwOUCA1idlZS0lS8ypQ37//XC3c9q4mpx40ec1oWzS39bz0NewMKmJnTM0zqYhPHehoctcL1lUTVylJ7HH7d4kbXA9P5K8hbM3PSVtl6e4bmJdGVoFOS7YzO9csbmfNmfAVx00CbDYF20pJ4jfE0DdG1V6OHzxplM1S0katwLxUdWFe+cStwqMzg5myMy+fOKKnyVXP1DH/M9vSn6sVb3u3k6em0udveqIQzlJrbqXOSzViRjxqeFvRR2fALPncFJG1kyFSM1THbbv/Lz1X22Yb2I/2F3tn15tKFYVhvPInDjEdDsOFFyZGTdRoDAG98aqJRmNNg9MLtASQC7UgGlMwGhP8Va69eeHt6nLYHWA7U3XR0/fs+dgfaz+z1sye9pxfZ99+9ZA1n0s/CORSsQqeS1mfsiBw9Vg6eyOUNUmaz5rHR5C4qLVKMG/3yw+DeMz8R/QjCW5PyKX2h0HAWoTn0mLKpCV+Wd5eQ9PnwgwSXjoLYKbDGWPa46xZfl6johaOXcFYl8+//RRx7SMBztnNE59L4/8wyC6QvG4Rc1jzy+Zwf5av4RxZU6pSHVCxzGAGyt4oXjrzvmY4++rbH8cl583uj4kaWwprdmj/eJtLHWmwSz4oiJlFt2AuxbyfdueGUMJJVnxpw9aCGHcKZjaWll46I2WC2d2l9zBSidgvi6klKwvMW8HxjUgWjrIldPrT79vxw5BLLW7v2uj2jqENQJwS3Owcg7SAAbiTYStM2X+7pFG0dKYfAlw4A2higtmn386ZNc+gjUhGts+j+Y/f3n+kDItugVu3wKKbtSPm2TL2Nr7Ll1dNm236ZMw06DprvhFcOZOseQmnAravfvlhTP+fRxuRjC2cTyezX76AMz50Hwluo6NyKSf9CNrMLKtYgnBizO3R6VTbCZgVZE2VNG3WZDhD1qTJQ0A7wvw1IhlbOKt2fC4lb2KXIwluKroFnkv1pBdEt6fN9eNgxqxFQ7PBqFqeM5JuMbPhjA8BjGa/fX4jHvSuhH0lWTPCvMVcVyvZk6TE8eP5t1+BNPdxNvqcuIVz6eNpf3ouLb47ImR+npVJWQFXFFJLYBZeOuOzJjgzWfPz0aV3nnejt3DWTI7eH39dLZJOFr/saRPzwe1z0GZzqXmngOimw0w4uNk7NHtrxLSlGmXDbNc0+XTMQFmZcPaeCmejqw/B2S5rrpk1I2hM1NBCPM0ll+4uStjV6LeC51Ixm0u9kbVQLlUbQ7dG78jX/pvF/ABsYc4Ks/Y7IcxsOPNfX61m44jzVaN1teN1PFt98aE2Hdw0bsWvFGiFudSGFIJGzPYvsPlBk0ziulnN99NuzkgbODMrGjZrMpwp++iX2ST2PEVeV0ML0TX7efH7pfbeVdGDQjFuJM3QdmihFOHEBBNrnrh32C5atXQfzJqaspJrGvIQIJgpu1/Pc/ozrkZeV8v+GeLy+foezutvP/33ix8Uwnduh3FTmdPfHDGSIZzQ2KrK4XIaYLNp9DxZ0z4EPOLsi18CWfO/vK4m6Bbvf5hL+w62/tXjB4X3grlU46YI2MIHNFTmtDmLZoFjq4QNlRcajglw9m7x0tnoSvzhPQMP/f799Oh5yEqfl0VdV0vU02/ySpKx7JTlDLovZ9xPNfWxzOOmiw3cKax5e2ouZVIjbliDB2aP1hZ2oDGecZJpNBtVd7BprK0pyoKY2WfNz0feE9sL0GfN1TynH5UqP2eqbPyNeWK5YH6hUX+NRREGtu1ITA/lo8iDJzLst57IHh7vcimiGmjzuZS0Gdw48bxj5/wTOhpv0TjP+q2iNrSLqMpWgTdbAtAqlCq8vfFptzicMWtuOesDtMvNYgL/akKcYDs0y0jgESSa/TFRy0gSiWHswn4SR3LsNeEAhGdEUU629exGvi+P56vLvrJbl0s57cWvFOwDIi3M2ZsB27WrIptvi2kUabqAM99ycdbU4ez9vrb7hcua8Ns+1+yI0n4U4fyo4zBveyWpCY7XRG7nM4uHWqbyuuuY6rnbwJ60UAY5HCnJwnHsOe7bMhz3OIpP18u+ttvPi3MpafNm79zUhFvQNGfuv2B4eW/un/gvpA1sE+yCKFpyhVbC2a0e/RerWS7+25Pj/CzlvZ+zrT+9giwp8woX2xGF7bvzsB/zjPo4jxnmKcsakWzXE6PsuVL0EETZ/bzmAvVRm/PVF31YTz7y/Rq4Pe23FNTbck+efhR4MM+E7OUCA3CkjZENaBdF0dJLZ48xu3JZs2Ae9HYSZI4PzmdQG5GMLQQ0Yfn82p4sNpcPaOv1erd8UAgug8Aw2QwrBI2YCWcvB420oU0Nm6ZNSiZrhh8Crns9DBZZ86d5HvC33h5NG5Fs1/PqdZ9LezvadHCzuJE28saoQs4I2gcPOBstV+vZZDLOc8kmzfFkPluvliNFmwptfBoFbbso6suBXzzRDwHXtz0xYnYpL5wq9/9eG5Gs+pE91PF8feNp29vt9ecfBHMpgdPJixFFczZaLeZ5we9Tzxeb68e0+eYIG2IbQ1kwa+pwBs4Q0pby/jyrif+9NiJZ9SN7pC6XXvlZIG6f2eBG3KzpePY4oC0XE5Jl1Fu+WFrYpDX9A+reRD1jxIyUmaz5mcMMoPn8ebOe5zXxO7URyaofmVW5dVsPetquDW6gDQGHyMlfH0cUd+bH4CwnWYd0vPgGsEmjzKNox5OlYqjJmuaF02e3ekTyEFCjrEmNhlr1IytQeYF104N15dPrdgtyqWeA9pbiDIsKHrTr9bjMv8iTr689bGgSsOlACvAOvtdkOKPVLmtSo6FW/cgO6GSx7BE3TxuCm8WNxqkGZ1/+5pC5W+SaqLDmC/+Y4JvUa20qiiKOKszY+mfXXQwAdrOqYdaExkSt+pEd1ny+zaVd93FfGjfwBube40sncvalD2mjeZskldDZyAc2MfsUTCPjJpx1xXzvvd3KnWIt/HpAG5GskhG1Hm9vHTx+PNtcedxgHrcPMP00N8nyxYkWzsR+G0rqXHTK/dtP1PZazh/+9iVpEysIpBYzgLYlbbCe1zZr7ualldRqXc2QEtaWOU+Vg+21XS7dhgfS9pumjZQBM2+fSVRa5SGiSKAtjzdSxWdSlblTfA+/2+RNUe4xA2nuT28kS2fiBo6L2nqa/1guqMfsF+H5Vunff3pdraV6SmVPWmQ/OALrqdb+fDHTjuxney2QCUKxPZ+v7rra/BqvtS93nH335ccud5Yhi0qdjySJ+go13ASMlDGcEbZt1mxZwlqWDEuSFAPlwvmy9Wtt/bPrai2Q4IwecER4JYEoW7J4HMngcSQH+1GPCMpKZTOON56U7X/MNrddbS64fek/QAyUOftSkt8mJznHar6UJCqVAjcCF8SseycPARw3xrEfL/3gilAcB91t3/qB81VEGueJ9fE8TSK3s/1oqLmOcGS+RRODREkiPQEy9x4yHsTxmqBdvdxPVSTyPNQPlRdYg0exTYIbMABmsE+GLw8XJOYUXQyHw9+EXW+Oa2vCme/OcN+xW8maflz0hxOOV/tbbTdlXrHcj/pIrNmeQelHXunQx/PbiGS7Fp6XMpdeC2jyJbR9IoTR/pTPZy8PR1Nmx9N0Onp5+Nk2VNLAmPxNXjiRM/99sJ5eJDXxVwmNh1r1IztSs4m8rPSw7Ww0+uRrT9nWvrt+ebgc63/91erT9/+6HL58vUdZRVGkTQY0eQjIa+KnchoTtepHdoK6XErQnN19/Q1Q+0aS5xqkHEeY0bUkUan9YfCUB49PfPMSXmHXm8Ukq4d/jtNGJKt+ZCdqPl3dkTRng2+EtK+Hw+u5JSq7aIXIMsexPL8eDj9BzPTEff3J6BomjG2zZqcefjleG5Gs+pGdqs2kJbmUoHkTJgZjkkJilJbePx4Mh5//ibD59Z3H+9rRJmn8eWdNarSoVv3ITtKmkOaseTFdL4ladzhc5WFyymt7JdHScfaNbwywiUnWrIM/zqGNSNZEC89Skz1pL5zm8/XSgXYnOMxI2Hl1Jhh7nsmay5q+H+F+v4AefVx8jYaaZvpFmHnbQ7vf1tcMbTca7leiSIOOZ6uRsDCJQBp0IiSPBjvYBrJ09qD9JEGsLR1Lwn5imWrqKd6foBzwc0TUbM8SO2KWqcmBEQauUdZnPZk8Lqt2sF+2adKoudxObXJmvfNrcyNR07O2kqyp25diwRWSJBiP9nNSQFqQpDCpScEViuMK2ouXQOGZcHRNEq/q+L3H/MWsPMdyourx5SRBOQFZ2gOWLOuZRMySljSno2F3wWfJOCqvDrqDxTTV7aM/HC/9lQRzgfWbPd7Xb7YX1F/g10SXE5zPfsZb7GCPSIwoCMH9h9uMMjzh9oAEEsQYtPM86pUyCMN5ib7GqKjPenzfDxK2UxLXTASCuynJiKUO6NkrqTTq2tX9ADEYvyo74RVIshL4k/MAv3M//AM/0j/0H2I9rmCnrN/ETswP5m0/364cDzX0jC2JwmOi+2uJ16wmkiPjcS0qPOuMnvFFUy/qgaId1scZMIRB02ZbUtsyJxHxNF/KM24mUbSpSYPyylXjpT+wn0riQCjJUlf+Y39AQYpW+hH1sX4dUbDdScR1tZ2Hnq0+IM2tei0C/xeh0SOPd68OBrkjrSZ+OJ82ItnOU89bm440WcsfTUlMbJXmrqeptFuD8Z9VG5Gs+pGdrE1PWrKW5DnmW6TAT0JqbR3zLsEH0aa3WvjhTBoNtepHdpo61JoSW9zN07qtiGgpYqRMog5qi6QacpV2VrKu0v63kRYNtepHdpKK+Zg2uZNslpX8n30zo2q/UXve7Hp4NxbSfTee3O+kaHv1/kwiolb9yE7Q1IMmOut2B/lTCaOefrxDfC79EAv395VmLfwWIDoaatWP/CTSxNIXiSSyVXoaQa0jycyl7XXikf+3PCE0Iln1IzuZtHzg1lPPFdNKE7voDpey6oH+1MAvp2ojkqGF6qL/K6ZcgrRESJuOuncTEnAiaVn5WCgdGE1S9Ef6Va1fXjl1/v5fV6PK9yTdx7RFt7vJA//3d0BJjq2nuD6SOV52uzP0R0hrVu6f/9fVzqL+QWBPWmfT7S6evNZ/cXRsC9S77nZXLfbLx7aa+Ov/dbUT78+gfwy6ozljTXU6H3UHY/QrgdbBX/+vqx2pmMk9cdPr7nJcB9Lcq4Pu9XTbv+ce2x7i8a9dVyuemSbX0TiTkrbWZyAlOQtxbenNAjGXV4QZX3y/hfU/tK6Wlo9lUG/Q9qZ7PW/XI6Z5nd12N22Qpu/bakHQ/+tqJZ4EVEyb3HUHkzoQRp0MundjksZs+ryeSRuRrPqRlXkSoM563VVeD8Ko+aZ7OzekPbef/WhEMkTpFNospzwvjiJbJpq0tNladXuzysn6G13IqgdisCWuhD/j+TU8f41IJi04T7AlD3dq1e1VPWwWeQbn2ZE1ebyth8c1Ud5nS6O5ZKpJdURlB/ZP77rL3JCG8mGymoUkNM0VaP1GlWagaj5VPWZ+qNFQc5cgWqaqHu08wFUGbsf6kXorI39TIzYexnluDwn2h4M8tGdmSrQj31J5E7TJ6xDDrPpXB6PJiw5JSzgOM8P0jwgJgj9YDsYo1tsUsfWQZM6z96sUNMnNmKjxGY8e8aI9sFN9vCun3O4F5z30oPtOMukBkC7qjMqZstlTktSicqKKNVt0e4tmyhhMxfisf6VMTfYK/6Q8nrGREYL1qXm0x3uy0A/jd9bfiGRsQfdY9YxlZ0WKnrMMfVqZhOpY8FA7MoPZpjuall03o4aPO33dbT7qbVppqvpvxlnkVxBEfyYgSMfGrXohMciSnDen5smK5LI+thMPNR3dSUBiPKSPs0pCw8chBqrtAZKRPcdyLzQmAaeTEiayfL3jQW8wlv4eGA/Hn5bxg91PYsNXMpXbbb2NSGbuJw6WrR53fDNwPtTEtHR+21vXIUuGdNW7mnYksAWICfmRGtofPg8a3t6IZKmJZQXlgJY7Pgmcb0hLhTSZuHXval4HksI6k2vC3bB1XqRpIDaF/FA8L2G19Ye3NyKZatnEnrLXTslr6yna8dJxpOVLyUv1ICmsk0Fv0972W/qPcQT8FMwZ58kVyeFs3IhkpsXSyvMDHgw/IfB+Q69ubGdsctNbVU7Q0zXf9G7G0m8xN44SfoM/ysfCIr/a8w60Fw01thBLk+P285kTpC16t7OnzHRtftajNZMepymuFD8eEldjbUSy6kcWIA0zlax68nbdWVJBjMqOO28qcTjBlZI+F9KioVb9yArvz0T3MSEf9Fb5LubUSbOD+yWJLnNPmjOntfBvscZErfqR/b2moiRtetWb6eyW2JlF7Ekybs+43Z5HzUoSZOvLWI8ur3s3k87zyqKNSFb9yIx23HfGNCkv5AbbzDSJUmSRSGrms27mCRAN3ZeBlIzqt6P+jPsfka6Ia0HlKln4cTC2+Qupej8XaSOSVT+y4vszaFuy0K8ywxlIATEiIE4TJkWWqRlUk0ryWAYx4SeGDP3Jivb78njZ22QPxuOlxqRFi2oVkHRgP2PZXi/GN731BWYSM+vVkJBRTYwSzURJFIg0pJBcTVS22y9FHVtZT8bzpcx25Inm58fjqvF9WyOSdRQBSlOWS+urZc9DVnnVzMjs6mrOmXYT72febaAmjHkqtrDMWJUx9iEbOsV21MfYyHZQf6azd7btD1TOYz9J8lTGwHFRn+qflGVqGjjv2HmLhpoiqnN6j8OewB2/OV7MxrR0LS8ItjPaThwR2xnNfBmEiTrJ3H4xX95vF8N2kAUS/PG+7JXEgCBPLo7D9gQkirIddz5iGVZhVPsgcDJwr6k0aRhvmSu0s/Mfj0/NvKVPjRh/S3rMJVz2OA3EHDkOsYd37jwvNSPGfjxLYiSPr9UUHlaE7bW9lBcEmFnMNMjADG8JwX4SwONVrAMRThGrPEkgl1kQ9XtFzER72I+si7JoticSusueyKr5qrds2/HRfyQtfUwc/YhyxxCoiMM8QeV0Sx7aof+lgHIa7V4tTX0PU5AD3d25SnnfA4xElGSlKUaunuZJoh+Aeo+p3wHo+zOjk5urGQkSRZYyZLULSIO2i84vVsauY7Rt65td3fx8wfFpbWKm9/6mgrSU86Oy6n7+7JWOejhfbAfH7+qnNiNGNT1iaFpCm+oaVfchar9pJ9zeoj+Y7Gbs+evkpj/j+E5U5AxHiPZ/2fls2vMakWzXQv30YtXf5NUTcj7NN/1Vkl68qIl/C7URyaofmdWO/PXij/urRdtkT2jh9pLaMlrivNL1thf9Zf7iotOpiZ8LtBHJdqsLtdELQU1C2vTyZno+ok7bz+NO7c/k5nLa6XT8OGvib6uNSFb9yEAYrilHmtiivxnbWFNUfj46XvYXMszteGtKXCOSVT8yeBzacZZt+ut2Le6vzq7tdX+TXbhx1sLvVuOhVv3ISNoFSBvfX85rQkYEnV/e/7Edp4w37dQvtjUiWfUjg6fF8yBt1l+OqycinrorCaS5cacX9SItGmrVj8yTJvkEpDVX/VW7DkTE03zVXzdxZblxu8eEOsxD5HW1ikcmvnZZhKTly8tZTYiIqLOrZRsx3I27FoTttRHJTEsv/lnSLkS9x194z08v7yfVkxBff77/YtLZjpuxrYonBTvf/8C62j//9I1rukOVNY68DiTE13zTn9nxP9l/F89wXW1HVinteO3o7Z2S9XSMp5NNf1ETEuKrvDpYJXr8YvDPsXqhy0fVFw21whZJUofl4pF09EitB8Kkje+/mFZOwJm1dWD/9Iv7XzVpXo+48unfg6TxvlC0oD4s4b4knxio+R6AKKgL5lj3QY+hIjy+oMdbz/F4UfddjciSNr+U5FkTQv4ZlUegKcdP1bkCVyoUJHbgTzxROcXxmDfOT0eXQSbr9ec7QdmjFgM3tNABQaJ+xBwBRs51IDVidyLI8ZrCY6jPCcquHbcbJJpree1eEOgZaZWMFdTWTluP9rcK6msdF5taB49rhdqVVweLVPsByitd+VVUTMdAUQ+UUxGQ47XjDfOAedzVh/lR87E97C/2zu21kSqO4+mDeH1SQd98FvdtvcIq+rL4Ivo2w5BJasB99MEXWXAr+iCYCyGBmRAkLVSoNE1NyNgdE0LchBAi/af8nZNf8u3p2elpujNN1u1vY78998vvM78zM7u2qa2PP//S++i5V1PxsoYVrlW3/xWHZ0YjzESUngY5KDcTnDGRpau5f/SbQVoln0L5aBP2/6x+/OWsU8xXSt+/FW9kW//KSNNNf3IIT2UiPJ7JqCRFxiKQBoWnMyBFJUwtz2RQPk+rBInqGZ246PlQh3r59O/hYTq3CYSx5oL2rFouVPyD5397O9a4ll7/CtO5458eScczaXMlgefhKXg6A0IUEslk+TIfHkd9eJzHyYAwqZeOsTrB+pWAcvTH42z/UzrZAMIW2p+1q+Wil2/UHjz/2/fvxMnaBqzQ/qd0pHqMSWJSkK+ejhntlGJFO/W0A8F6LCNRSWEV1UE66kMxH05r8wHRev9U/bj0yE1vgB+EBeVW8O6tW7fe/fijg99+e/6vrRhZW/cKnfTuZDidxyB4FsRkkM+xjJXT9E1UfSaF05mlIqagXFTnNAjm8dT6TAhIIUW/2umrjCsVV8Kiv+ZwMnI2gbRRq3KYy229LO3WR998c//9GFlbO2lH/j8uE6R6QPEUqxabuJ4QkAJFjER/GAdpEAwyMQ8o+gXxipJxOUhHfUEw+sM49FDUTKfXTto4f7BLQpi9KOzlO8//8P5WfAfoulZGf9JCH5aOsfPXqSBsfeOD2Ic/HefSayYtaDx4JJRIY/v4/q2t+J5Br39FaVJppKPBsLnY+WdbKbjbcl/WRlzPf7DniiRQe7dCqBFrT+N7NbmVTJpzL90f/ru7GZ5ev44mk930cn/WQFrpwcEjcdgAtY+rhTlqT+N7NdpEkOaclB6u3cObo9uP/CO5L+Ru3qfrPD1LOwe1vjxzGLVbn3fKhXcFaqmtp+69WlohLUdbuwEe3iA98XsuXYFpaXK/rou09LT0YKc2mY8rUfvg83qnWiy++zKx9tS9V5MG0ujAONwMD2+OHk4GrqPs0xPcD0df8TppucnvB6Wfj+fjvnzr3Tu3y/UqWeHFl+M7QR3M4LEzdIwzNpenSR0mbKHNxqNta0M8vDm6/c/wEPtEJlW9YkGScf9V/4mPfirLwyZ4/qBU8m0RAZrHH/l+pVgV1rnzcoxRTZkJyNBjksjGCkykoX6ORCft2D/ZAM9uoB77AfaJFWRp/onMl4A+rlzPp6q130u+Pzw6/ufvWq1E3+bLkjQKajFGNTGQ+hZioZiZci0humMFspxXyMr15DfOvD6Ic1qTw83w7OZpc9jK8T5h30AKK0kaMQ5pMkQC3n/4Q+aTIl9mO8EDwqvhE2U1iVrFI9ToXu1dRi0eYyJABs94ma89O0J5priG9PIcrk3oaPLPNu2snSEzqe4RcztT/Sfsx0q2nTuYTNX9UvYT/tL9RIJ8Jk2pp6dH/TDYL9X8RqNSOqgdSNpKDY9A6xTffTHWqIaRsaJYVSet6R+vPXZstD5sNLV9I2PV9hn5q6k7DnqDSmH2a/GAQKtUSoSZJK3kFzud8p3XX1+gFo/pMzWs0ECUkbR0d9g8s7PZa/Zkdv0kmfWo0cW+QaMIQ6QwE2nTi41+8+j44T8TeVpWiu39hk+g5Ssltp9KjcLtO7del6htxRfVsJLVNH3F8tFgsLvKztsb4Pnrmg/63x0M0gY/GFWKln64VzpYGKHmN4r7M584y0vUfJ8+H9359INXXnmdDOdnHLbijNMGokzaHz78OiYPWyvcD6HdE9ezosrN+dblic30hn3sW4w6evDg4PffH0jQCC06K/fLPpFWKFZKfmPQOzm0XpH2Op+f8R2gmMl16EnjyEyWxSRFELRCe6SjSLEiCbGuSpTa/5Vj4knjJBE/HD9YRLQSmU+oeRTSvEKxddwcUbnjMGi4U4uJteskze1NDmnz7egdliTY7BG13uqxgfpBvyDIWF/t1xL5FghV5iWzz7ezdaJV0vX5WXIcNf9w0ksn4Ye9eUijjzwwi7N8wfMK5fKu41A52TKm4a8KYrFrJG06ebQtdjJri/3lO3TLojQlRD57hMplmhQ7z+WslpJmj7HK/rgc44AQjENlspzbY3wLSgSgfJGvjYt+9HLUE91xOfo9r5hvujUYJeCH8EDYj7U5apPgNF8oFMudss2kOUpMixG16yGNvnGawxPeUSYFO0wZHDssVoU0C+SBRAv9sOeQLxFe5DvoRxvf0jxuPYZcqmbNyROKefE4y34xb+RbyvxApMy3SJEmtVi5v+PhOAF/TB4c/HhQ8yetbjAeOU5A92nVTru1IM2RoMVGGux6SCPWupNDvmalIHYhJsw9CbJABscgJoYMxMn6IjZaiEUgzUIMo0rwMCliGKelzvsDQSBMjMuECV3GPCncD40H4ii1VCaJ5yHbgTSRwyrnhSukOTmW++jE6Y/0cRCOpyMmK10ulKud2awn0tKIMwKNSYuRtWsizW61tqUHHcWTvNNk0kOIRVxPLed2yn2XLAdZshxkSRXZ6jhSSeBhMR7GYeJFCRO2zHfQD8co8RXrwfiLfmU3qLdsz/dpWA+uODLW7VbLERa3P8hYR4VqvV7vdE6W+cSZBI1Ri82uh7T+5FjxKHuMd5rVUlQSgXJoBv3oyuVq+4zeTk+jvmVSvmJAHpOi9CNJ1NvL2uhH75dV1hLanUwdslWfwPrj6XQUUQ7SyKZF4qzeqfaXBIKzeH+SQlKEfXeWtHDSxI5eh2bX0x7tYtSjSbgg4/JPYLP2PtlpMHYiYxprWCbS6lXPXeSnCTKcnTEayGCNgzRHqiPVcXK9wfaVdtrOGjzKaq/ocfuqxGQNauzvSu13B900SMP+XuCvWactSDvd32+fjm3Fv3MDcd1qp14uFAacpnrzgCY/sdpFMcms0St2lqSNBl1r4eEbvZL2WjZIAGmR/go7IqpJa7c79WB6L5K0XL1aLnh+4yGnqSJRoYS0DX2v5gjAlPuBw8l4EaNu9Kp6Muk72FfDaeq49T8XnLVns1mnU+2Ntfs01n657FUatcYRp6naecw29L0aVsIaDEbr99TTr4eTYEEY6wVPCqedNlDrkFWr1VYwmpef88+4kG+UfL9iM2kCNdU2872atLPqtnrOJnjq6deve72sur+R98nTzv4pGaEmYxq9yiDUysVCt79sD+0SaCU/PwBpTiohU2dKH2af01Lpy/yc53oyKfNJOU3lOmnTwUnMO25padYNIcKk1tXbHQ9GOilk3+EN7/zuZTZrM2siqM1BK5eLxUK+daS1H/h+o5EvHMv03K+phEwQgqgKwhSiFmlWMlqhTC0Ie2xMa04ODTsemyc2jAyjOlcYpzkZ66SRpkGc0LBTLZbLdUKtTUaoEWhVIs3z8g1/cqLGRrvRaFTyhfwIp3NiUU2Q5pBBhcg0VoB0VD0odqDb+tqww8addjacmOudx3brGLEMKj2CdEcclvn8YDoat8XbWQ5qBbr792u12t7D0Zn2YSWfz3vFVhbtE0MNxCgz1sjS8w2k2a1j6+nw4NOjTrflIiZF+G0mUCsUGkPXSY/3CbR6VZ6elUapdv/753d27j/aXdbveVS1WBjdy6K/VEKmkYIYZtL0RaT1B83ree+kx8CnZtzs6vWOBlOVNF3HMqoN9yqVw+y97LRbLparlNHwS7WDnZ1fvv32l/v3H/ETQtYrEmnlEO2TRc1M1uoxLRzsrj0G/C91dxCqpOk6o/uy4V6jUsmPRawaBQWPTk+/JECTn/t7vj84sah+SDGtXDz5DjEtQdQSIS3d62Y2wzP/P7W6XZx2j9UR8eMTavRk2ZShKx1MxOlJlH3//c4PP/yxN5x4+cqkF05bFNRaY5CWKGpxkpZl0kaDo7V75H+sRy1+6xFF3NjL7xFqFNaKAZFG9XLh5GDnl192yPb2hlTg0fNovkIPn4MjpZ9kUdOJMRFlIG082N0Ej/x/tT/oM2kRfuiWSpI0ug3rZrle85+DnR/u7+35w4rAjEATNYLH+DOVkMVwX8aaZQ16X2+GR/6/ut0LokkT+b2GIMkr0hMBh0Airt/buz+klxtL0Bpdm/K1flIJGZg2aPZS6Wy2dbJ2TzwDGvTS8/0+v/+sxJpXEKRVO/XxMt8OBxTJJGl0eramqE+a/Hs1lRxNTeVSMeNR63ATPPH/10OKVjop8EfXE38XNf+33MGZetOwN5CvbXv9iPaJoWYiaTXSxq3tC3bo5m/eY9Tt1jiaNNKAQpoMavVZuzdV6tnT6dR1IkhLDjWMEIN2j9fugWdIg+69i678sFglo6DWmbU7XZvzIwiDJoeagSDzzLLLtN1qboIHnh1tttyL/DatV8X/oDIj1NrteuBehrQkUTORZSqH9lvbm+GBZ0d3lTt7zU/uPrE2I2u3JWy27jcSxb9JohZN1oqxLugmu7Pu+j27gdoN4YfHaFjvEGhsnWq36UaTudRUQoYRLlBzTEv3jm5IWYeGXeciv0xnHYJsf39WLYofAlMYX8LfqYQMIzyJjnq7K8aoGyJj0n5vFOUX8bkXEGplT7y6pY/XN/szsQM0FtLG3Yy1ITv/7OnXvX6EX7JZ0uy46B+UGl7By5ONzP5MDLU4SAvCDdjxZ1jD4PGkSQ1btQe1xpBRc43+TA61JyfN7fWveIfvxtMO6dXyoaZxnqx/c/4Trs897OUi/DNtVUpkjYpArZIvGP2ZIGpPTNq0m1FWblY7Xg+YxzOkk1J7hXpPON/t3vSx/gmL4l/flmp+3iuIm7WWyZ9JovakpIXhcif+z2pvyDwiNRjr/nFO6+VKo1Gqlfz5Aer1nKzZr6mE7AlJ604jd8CGquX2VT1p6/lXaCdS5+Zlm8axoWiH/vT6er+62rESPA7IHQpJ6dN2R0a1Wo1QK4p7te5jSNu492qKZllHXfcCgmz2DHZcK1fb2agf7TkSkwftuZ4jzFbGRb5GkKZ6OeaB8VSCkU9iuAJskKyq2i/nR81jt2uTY+Afl96m1cv5hmDNr3heJe+1+tn1vlcTf1YjTtbPZvsBVkpf1B20l/nnCbHVa9peEgbyIglCrOQ0yplUYZyP/ng8JjBiHG0e6AfkyuIFse4ZAmyVIHs5jjDsD2UjrRJrWS6uNJRjn/T5qiR2+9I/WfqImLbfnnXmqJX8yqAbTt3524+1vleTrGdB0rkYhjRWQl+DJu+Eq+wgCMJOU6aygzLX4nZqDGSPgEgbd8Zoj50mU8kVHpOAc30mkJIgXyY5HwRwe1bkq8RgnS7ItdX525g/z1eNgTbaoV8eTyXVYkV/C+V6Z9uNQ+GXuX9OJWrVQoVQG/b6WWlzfypkZa/xvZpKFlkE80xYljXd3T3rSeFhEIYdsBFL5gSosQv1OUao7eAh+gZkImYKg2dlKROEcnfpMYwjjWOSStp8HJCKmOYiDXJ53TwO74cNMtRx1Hmzuso4uHJRT18vGWI7rrx+N81Ehaf7c9QajUmYht+EPe5NLyJOkk+g52fAaWZeqhCuxzrqzlcOAlyk4VEQpKZRbkH19mQXqoX27NHz9VRS4ElWEML5Z4kBQSAtYn5Yp7oOpNFeX79aT58/iT4/VyOWNNMdSf9MCTSyWTnvBdKP0hDzHPYvCafZ/wk+gcoR6AuIw0ykqrHM4RmPw4t2HKej5skID6O9loZa6FcjThnXItPqQSOuEKiReMzP0A7z0sjQyNXUipi/ZWntcaWGfeG3033B2n6n0HXhV0QKKSDs7Oma4L1aVmMeaei52Bf0o649/ZSCQq3IfFdNGz1qq6qRg3KQivogDvVURX0llqDc0A6KcfTxo9drR7ZTFf33Q4oE4vikT3UMP2oa5fdUQqaPhDRUzXe7X6s7aLjmoSg35iNtrm+sd2Ea7Q1qG+Znbm8YXy83r0+v93XgngrQTvdnI40oTfXyVEJ2qZimRtlpgBVGxSrDjtjmfKTN9c31LkqjvUEtvR+TmuZpjvHm9en1AgpogjR39ZiW4Hs1Y0yDkggNDw2xAmloZLm5H3P9eOtBr1o/vphtbqcrWTj/SfLOObIuFdOSO0Aj2I5UJ9g2xQqkoYZyQ8wz1Y+zHsrN4xs0hphtbgfFvE/bgjQtdl0qpiWHmkNjrXCejwLsyMrPYub7HvOzHuqZxosnZur9r3hft/J9onG/zPsqjs/26GoxLcH3aivFtH5T30k74pkQ9Ywxy3w/pHtu1VhkGN+wHvrGUB+qtbtwfFPs1+qZ553bb5/uj/tTjSRzTEsStburPKOEu6ZrXCtfsT7UXM88np4fQwxKRFeJ3eb1EmqnuexorJNljmnZu6mE7JPLx7RsYEVc+6ur6Vq2kvKoHQMJcY5nxz5+Tj6BTrM51w5xf2aKacj/JJWQvRf9xhYqbRQuVnSjBk2UYDNpLj2BEmlk45HJr7q+l0rIXsBIF2u/v3aP3OjlSHP7+2HOlTbqX+a9mkLiC6mkzLkcaWFmI3byRs1KgLX7EjQiLxMqfjSrk0rM3puPcE+KrnNxw/Xv4I1eXmcStXk6dOFH+DUqncD5iRNUG1HXaX8zdvBGL6O5bK5d2GbSyJS3HkbiXkglZlt3jTFtvL0JO3ijl9WcGxa8XVJKiPR0DKJMZ9jdrVRy9qHp/A4t7c5TTce1Q6umN8SziZOzar7r9gvesJ8TnMn8TAh/GvTDVIK29cmFM3BCrCxCYyDHkJ8Acfr8415PPOtdff/Eg2ex4DW6GeSHlyTtk61UkvbKhaSNTSuMa8dNuprHzePEN765fPV5rr4eKLE2o7DWmJxkcov8sYE01ldSydpnNMa9qNNzQ06RG72kSsuNC15l6JeGx1M6QmV+GE0Y7tc+SyVtX0Q+g47tzdjBlU/JZ/S+jsAio1jWKuSHvl86KPWaNqWpfKyRpekXqcRt6xOMeJ40dzN2MHl1VY+t3n4z1jEnTT4YEGq1g4PS392+S2aP4d97Omm4UUvWXr6LGZzR6ejZIS0Zvf79k6QRWYFXkazt7ByU/EnvaOqORgpZmt59OZWo4TFUJy3dlyu49/g7XxGV9XI9DX3CehiP1YW6XJ9En4+r90OSU9J6fZRr6rLKcdGO00o7l9N6zON6Lo0XMY8L98mN2ndJGllX/F7jUo3i2kHNb1TyrSBws2uMabD3FjPAeT52L9jpHNJQV81HezfSQznslMx2lfZRO+2Kei6JSKOdq9VTxlGI1D0qSrV2Sv2odaM+iNPr6e2pGfaFVS1H/1D3onkzaXQldSvEGqG2U6v5gjXP81ryJ3eoEYX1vdT12YcORpY2NcQcV/WYShal+dlH2QlXaa97JMpjvINiPOwoCTwG0l2RrRCsXSFIYzylnPthksly5z0P0kH+2XFNVyIIdl1cCXo97Qrh9YA4VqyL55sLxM/rkFGtRKwNK574VXrlYqsbjKeOStrdD1PXap85SnTtg5BltM9hZSIbRKGecABOBxDDBGBnXfTL5apnXHUcnGqu6AceJ9ViIOfL+q4wzNuFR7AeUqyPSkAe1iUKUO/cFYc0xuF2iDUyTYIrRO4DxkF/GpEKiUvS5/PlcpFeXhlpN5ebthp+jeJajaxEga1QLFfrdfEplntB2B+xv53kX3LosN3F+T2WM+cd5hWwBynNK4Tai7SLnXBxjSHNHgRxHAsQO5gcUcAewnhcj/tdEqXtNCt7hMfD+Dh1WRVymWSsi/tnRb6L+bpQxOzlurEOG2mh6Fe5EqVSPtTW9xvrw76RMmkusZYeD0RYq9F/4idfeYVylUDr1Gd1YdUyATee3v1sS96uyz/XaFuffXHXkW90+/Ao65Ik9qStkiSVBOSgHLoki1TNZz3rUaRBJucLgcdAVMR4ej7mrZIL4vV5cSxk8tU0ylFf3wdbufKQxrrQD+ajtNP8oIyH8Ym0bDoXDmqLM7RS8egArRJks1mn0yHkRHwreLfvfPzurS1JGwN3Yzd2Odva2nr5xRdff/31V8he+ODzYU2g1mg0vEJRxDXGrM6xrUi4eQK4W+8Lym54u7FLk7Zk7RXJ2gsvfHDndqk0fwotEmwMWbksUauWpQne8rc/XwJ3g9uNXQY1Na4J++DT25WK+N0/jBrDVq1SWANtxYL4SeCTj+7MT9Qb2G5sBdYYNrIPP/j8dj7Ph6g8QsvFsnw6YCuSFYR5xFtF3MKtF7bXXntD2GuvpW5sU41ZU2Fj3D79/HahIF6wibcexFdVmgStLFETtJF6grc762PttTdeeumlV199lb6+8cYNbBtrYG0OG9MG3r66fbtQlHzRCSqP0OLcZEyTrEnitq6ZNYBGmL1J9qqk7Ya1/9q7g9W2oSAKw5EhgahgdK2AIiLLMggkcKGLFLrtsrvmvbLqIm/UB+uZ0di3Siy8ub6xzPnjBJz1x4wkW/blBmse2xFtfsC9AhyoQR0ewzR7NWp4+j1JPsNakcJZKQ3caO2Cgw/D5rUZtw/engWVHay9/fl7oIb/PSefYC1PwcxpJRqs3bCLDUQ8NmgzbubtIzgMND0lQJAmyXGcjLXI1vKVOFtKDqm1NOVYu+AEiGkbcZv29vLrWdbnG5jpkRwO42SsxZVWPAqzLMuW2mCNY+3CS+RnpA3cpr0ZOHhD+9fmv0beoGkpzOpsyKyR2hxK8BhxU28nwP34OVwTwQZ9SaJaSx2c1fV6/bRGZk3GGjfo5ZeYNuN22psHJxPud9QFmi7rummaJ+1grSxJbR4lnpv3dhKcPHm4v/8ScapBWtO0bbuRFJtac47UZhS46J9T3ixAE2mRqaVZ23VddSepNrNGajMrGY+30+AeDtSiWIO0brFYiDTNrJHaTDNt4DbhDeB8kKbU4kszbMNYc47UZprZmQb3cK/OVFocal7arbanBmukNvPgB48JbwCn0GJKW7Yi7faQWdMNKtRu2KwDo8kBp9AiUYO0phtLU2sYa0aNl3CvoYkBJ8U6Jyhc3dr29NlYwwItSe2aUnBDI2kxhlpRZk13RJqnxkO1a8sGnC/K9swfl3XTmbQxNqPGQ7UrLUn8I0Yrl9UtrnK8l+apcX+yUG/maFq4OjrV6kzOCrg/WZg3qNXNxlPz0oxa+cj9yQK0wlCrnzYTU62pM1dyqLFAQy2DtKNTrWob7E8ONRboToJpal2L/cmhxsIMNezP9QS1qpP9ueVQY0FuxHNGDb2jVi1AbdlzqLEAFatyihqkLdoGQ43X1FiAUk9NeietazHUuD5ZmP3pqUkjadifWb+6YSzE/sRZwf9TTX5NGmrXuy0P1Fggam6gBmuGTVNp3ROlsYCHakoNY80yadJm3VMaC1K+p2ZjzaoGaXffep58suDUbKxVdxWlsfAVQs0ZtcGaSasqSmNhqenFDrO20eVZwRmlsbNQ89Y21dBmQ2ksPDWMNbUm2FqkdxpTGgtZLtR0rJm1xj7takdpLDg1jDW1Bmz7T/Db7fgSOwtbXqww1tQasFm7Xc/XCFjoitSsARvKdktA4xvUWPjydLDWO9XmXN/3W97Jzs5QIda22xLatO2Wdxezs5SbtX38HDVmnckatOGHX7rCzlmeF9CG+AV57Nzloq3I+RWzjLHP6R94XIq1gHKNPQAAAABJRU5ErkJggg==');
			background-size: cover;
			.btn{
				position: absolute;
				width:380rpx;
				height:70rpx;
				left: 50%;
				margin-left: -185rpx;
				bottom: 77rpx;
				line-height: 70rpx;
				text-align: center;
				color: #9A5D08;
				background: linear-gradient(90deg, #EBBD7B 0%, #FFDDAC 100%);
				border-radius:35rpx;
				font-size: 28rpx;
			}
			.icon-guanbi3{
				color: #ffffff;
				font-size: 70rpx;
				position: absolute;
				bottom: -80rpx;
				left: 240rpx;
			}
		}
	}
	.instructions {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		background: rgba(0, 0, 0, .5);
		z-index: 10;
	}
	.instructions .setAgCount {
		background: #fff;
		width: 656rpx;
		position: absolute;
		top: 50%;
		left: 50%;
		border-radius: 12rpx;
		-webkit-border-radius: 12rpx;
		padding: 52rpx;
		-webkit-transform: translate(-50%, -50%);
		-moz-transform: translate(-50%, -50%);
		transform: translate(-50%, -50%);
		overflow: hidden;
		.content {
			height: 900rpx;
			overflow-y: scroll;
			/deep/ p {
				font-size: 13px;
				line-height: 22px;
			}
			/deep/ img {
				max-width: 100%;
			}
		}
	}
	.instructions .setAgCount .icon {
		font-size: 42rpx;
		color: #b4b1b4;
		position: absolute;
		top: 15rpx;
		right: 15rpx;
	}
	.instructions .setAgCount .title {
		color: #333;
		font-size: 32rpx;
		text-align: center;
		font-weight: bold;
	}
	.instructions .setAgCount .content {
		margin-top: 32rpx;
		color: #333;
		font-size: 26rpx;
		line-height: 22px;
		text-align: justify;
		text-justify: distribute-all-lines;
		height: 756rpx;
		overflow-y: scroll;
	}
</style>
