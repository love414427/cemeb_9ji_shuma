<template>
	<view :style="viewColor">
		<view class="PromoterRank">
			<view class="redBg">
				<view class="header">
					<view class="nav acea-row row-center-wrapper">
						<view class="item" :class="active == index ? 'view-color' : ''" v-for="(item,index) in navList" :key="index"
						 @click="switchTap(index)">
							{{ item }}
						</view>
					</view>
					<view class="rank acea-row row-bottom row-around">
						<view class="item" v-if="Two.uid">
							<view class="pictrue pictrue2">
								<image :src="Two.avatar ? Two.avatar : '/static/images/f.png'"></image>
							</view>
							<view class="name line1">{{Two.nickname}}</view>
							<view class="num">{{Two.count}}人</view>
						</view>
						<view class="item" v-if="One.uid">
							<view class="pictrue pictrue1">
								<image :src="One.avatar ? One.avatar : '/static/images/f.png'"></image>
							</view>
							<view class="name line1">{{One.nickname}}</view>
							<view class="num">{{One.count}}人</view>
						</view>
						<view class="item" v-if="Three.uid">
							<view class="pictrue pictrue3">
								<image :src="Three.avatar ? Three.avatar : '/static/images/f.png'"></image>
							</view>
							<view class="name line1">{{Three.nickname}}</view>
							<view class="num">{{Three.count}}人</view>
						</view>
					</view>
				</view>
			</view>
			<view class="list" v-if="rankList.length">
				<view class="item acea-row row-between-wrapper" v-for="(item,index) in rankList" :key="index">
					<view class="num">{{index+4}}</view>
					<view class="picTxt acea-row row-between-wrapper">
						<view class="pictrue">
							<image :src="item.avatar ? item.avatar : '/static/images/f.png'"></image>
						</view>
						<view class="text line1">{{item.nickname}}</view>
					</view>
					<view class="people">{{item.count}}人</view>
				</view>
			</view>
		</view>
		<authorize @onLoadFun="onLoadFun" :isAuto="isAuto" :isShowAuth="isShowAuth" @authColse="authColse"></authorize>
	</view>
</template>

<script>
	// +----------------------------------------------------------------------
	// | CRMEB [ CRMEB赋能开发者，助力企业发展 ]
	// +----------------------------------------------------------------------
	// | Copyright (c) 2016~2023 https://www.crmeb.com All rights reserved.
	// +----------------------------------------------------------------------
	// | Licensed CRMEB并不是自由软件，未经许可不能去掉CRMEB相关版权
	// +----------------------------------------------------------------------
	// | Author: CRMEB Team <admin@crmeb.com>
	// +----------------------------------------------------------------------
	import { getRankList } from '@/api/user.js';
	import { mapGetters } from "vuex";
	import authorize from '@/components/Authorize';
	export default {
		components: {
			authorize
		},
		data() {
			return {
				navList: ["周榜", "月榜"],
				active: 0,
				page: 1,
				limit: 10,
				type: 'week',
				loading: false,
				loadend: false,
				rankList: [],
				Two: {},
				One: {},
				Three: {},
				isAuto: false, //没有授权的不会自动授权
				isShowAuth: false //是否隐藏授权
			};
		},
		computed: mapGetters(['isLogin','viewColor']),
		onLoad() {
			if (this.isLogin) {
				this.getRanklist();
			} else {
				this.isAuto = true;
				this.isShowAuth = true
			}
		},
		methods: {
			onLoadFun() {
				this.getRanklist();
        this.isShowAuth = false;
			},
			// 授权关闭
			authColse: function(e) {
				this.isShowAuth = e
			},
			getRanklist: function() {
				let that = this;
				if (that.loadend) return;
				if (that.loading) return;
				that.loading = true;
				getRankList({
					page: that.page,
					limit: that.limit,
					type: that.active
				}).then(res => {
					let list = res.data.list;
					that.rankList.push(...list);
					if (that.page == 1) {
						that.One = that.rankList.shift() || {};
						that.Two = that.rankList.shift() || {};
						that.Three = that.rankList.shift() || {};
					}
					that.loadend = list.length < that.limit;
					that.loading = false;
					that.$set(that, 'rankList', that.rankList);
					that.One = that.One;
					that.Two = that.Two;
					that.Three = that.Three;
					that.page = that.page + 1;
				}).catch(err => {
					that.loading = false;
				})
			},

			switchTap: function(index) {
				if (this.active === index) return;
				this.active = index;
				this.type = index ? 'month' : 'week';
				this.page = 1;
				this.loadend = false;
				this.$set(this, 'rankList', []);
				this.Two = {};
				this.One = {};
				this.Three = {};
				this.getRanklist();
			},
		},
		onReachBottom: function() {
			this.getRanklist();
		}
	}
</script>

<style scoped lang="scss">
	.PromoterRank .redBg {
		padding: 45rpx 0 30rpx 0;
		height: 460rpx;
		background-color: var(--view-theme);
		background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAADdBAMAAAAWQurTAAAAFVBMVEX+/v5HcEz7+/v9/f3+/v7////////mhpnIAAAAB3RSTlMOAAgSFyI9KYj6FAAADqZJREFUeNrsnct2qzgWhreRM4+pFwBO91wVkbnXAtU4awXnDSrv/witGyCBMDfbSGptjI1PJSn88fvXRtoCuIQQaVqwyHN/9hj8Z14AAhmIbRR55P6CKABz4GzFGCv8SR65P1fqGWeNuMwFdIYeI3Egisj9eZEBKOCSvNA7B+8BeX+5p8pbkNA7tHqH9mC47Tbecs+w8hYY6F3C59tJ5P5wsSOBttc7HupdbOaR+6M9pmdt5jOa3l0G7yX3jEscK73DtN7Zl6GI3B+bx4Chd2TXO3bW5MFL7LilO53PSL2zpyRyfxB2ZOgd7uvdUfDecc+EtY/0jif17iZ48M9kupjPZ7B8OkXuu7HjPhbkM+IJHATvF/d3ALve7/k7f59H7vtOl/BI73P5jDwCkfuenUVorHdYonf8EbnvSGUAYELveEbvriU1HnF/R1a9z+cz4ig4ZvH+cE+R7Avbks/wn4LIfdueAgK0NZ/h60fkvsllJvS+LJ/hax65b3EZQDvyGbFG7ltcBsGefMaxnMYT7u+yaZzMZ0jNoyL39e6Q04A/cp/KZ8r61kdT4Wm94yRyXxV/qaqwcT6DdOgy6mm94zxyX9Uvgyf0PqYuRD+ld3eSeC+4Z0rbQ38v6W0iKrDqHeAUua+RO7blM/VtOhqr3rEzHZM+cM+QTe+I3u7G1ap3fIrcV5wydf6OurjNRWXVO0Tui91dFuUZep/HLsGP9O6Iw7vPPQVRG4YMfye32zLwI7074vDucxejHZ2/o8VqV2nNSO9unLSC+3LvutmF3pd5e9e4jvXuxpCf89zf+26YVu9zmYweeKx3JwTvPHetzL3V++dy7OLUdaB3J1JJcN9mOnJK7+VtTTRjvePIfb5VxQO9A7mti++R3l1IJcF5uQ/8fY25txY/1HsSuS9qVfV85m0tduY0Q7070B3sOHdjGpPQ+219XId6d2DAz23u5rQ9fhDoBu43PNC7A93wbnP/q9e7zGfOW7DfvgZ6d6BlBddtxsxnbttioHcHWlanub8jMPOZz43cv5H+vXGhN9hp7plKZdp8ZqvcueCxoffDz1md5q5VyAjyn5u5NzDQexK530neNb1vOmXSc0ld7+jwjOZB/39+ga9MzbVLsgdd7CtDyCiDfNuOnfcWaHpnh/HkL/eCgSakrOua1lrobwiGYvMlArqKR6X3HXKXOXynd9ZEJ/5xTxlwhrvjSyl7tFE33RsN/5bLH8nyjd7f98idC97Q+9EZzbr/fcqA67JmlDloM5r+JxrxkAegWsv+3dA77JO7yOE1f0cHj34s514A6sE2nGXTtO/5W/lGbjWm71D584x9suLTZtjQ+3kf9tuXbCy6EuKT89x7lTdCxJKxpvdGHYymET8gDoT0nI54zx4vlT02/f1zJ/dG/rFO7x9Oc08zpDeYtHsdNaV01Kjqgtfb3GWqfwdD7+i2N65g+PuxRgMLmdetXHsTEU1o3ctdN3jaGZLabr8I6gcXoM/A0Pvbbu7fej7DwknujHmpK7Yx1NzYdE070tqh6X6QDvNMMpPJ/WmLZaTe6W7uNzOfOdZowN6ElvUYuiWaXti9ys3vh5bijI7VvXGfFGuTxGZa1Z+fXxX3W9Ze7/jo0mC4by4Gc6pIUyNdpAZSJXqDMTX+XKOb0nQjm4J+Ec67PZG/esx10mhXEs6d4Z5mxNocjlWvs6VTXwfamnr/2v16+66asJt3Te/oXsf7z+8g5ke41R92hHsKqL5D0EqY2n9m8khYwwoANL1jOC8T+wz4q6n3vx3gnmZlfVxUhaUPuNc74M8V2KfBN2DoPTma+7HQrXbzbuqdrsE+DR4besfHcj8euohrYtq7rney1NtnwF8NvR/ZsAJyg/pQ85mh97eV2H//nTx10vV+YBcN1C5FTx4MvdNVLjMNvgFD78mh3Cu2HB+l3Iu2AwEbel+NfQo8NvQOUe8Ce8VepOZTQ+/nlS4zbfFfht4P5V6JpSyPXQVxeQA4+XdD728bsNsF34Cu9wPPnKB2wmWExTDo7b6Arnf7SNMc99+pU1ZN76fYrg4PAnSTVTFswm4XvOHvByY0UDoaNeku835e3ahOC/7L0PtxCQ1U/Mvt4qMu1f3HrJ0EPwu4/zs166ZPlA70GUexs8a2qkTrClu5/06MsmonBtFnJoJMDDUtwW4VvHlisCChKUQk6roIvBYuf4jPuB4Eb5W7VfBXQ++n6dosQKIUrjFrgtTATrWrEE7pnbgNviT1NrlbuX8Zej/ZiZcaZV6L0qiKlIYOxhbI1vuOMr0TTt7lB9tFuknuNqP5Njr2k6nRfFmYRccjOLwMUVYN0T3wgXDB6+Sd2xZ7aJ47LeX+e6drTLzq3IuWuRzSpLSvt6Ka3hv9AGiDZuvYu+0zbePKNoyLuC3FbhO84e8wHM1XZW20LY1rBqOZtC1TVGVDPGhXFLRG71xcUlXyhbi2zRdmhgSXq+Vu5a7rHSulDypqJ4uDpsbx6Wx9xFjvRPus7YtD22JTrKS9JMRy7r/WMSdN7/kl1Ud+mvEBaPTqn2Zu5H9p3TMQ7dMyWVWlQ9sdeC541rqSStr87x7uX4beCzSuH9c4NqPCKzpR52IUSBQLuFfio4oX8ezQtlrK/r8RzMmv4D42mm9d72ebbpvWVqbV3QwLQgfHbbb+E9rvcPfi5LYWuPxnH/f+zvNPHVq+fy4MxL/AdI/RtEMf5OkD+tc8LO6EoNsOgxd1xq8po5jWvJ/cGfntp6z4VdTvNbG+cif4/LOR+xXIK0fO7Jr3ljshH2/bBj9eSp2PGSdhcSd4UQM7bFYPqI+zkAeCvV0IQtltJfeDiidGZgPYZ/AsZm3eEHtdHzVKn4TjM0zwbMGfP0sNvq6qY4aLq2pY469dyN7bIHQR96brVz4okmD03qn+Ns+9cWCYIdf8Hfn/4Cf9PzPcKwewE63OHGHi/YN7zWROKbnLAfLDB4qrj17vvL/C82f+CgmdTGiabkTt2Ad7Uhkl0zvmuy46pH3dlq8E222enyt1AynHPnjXtqwdgYACgzWbZ9hld74T4CtCTnIeUTDB7/L0Mc7mawFdDFwdbTRi/Kzk51Bh6V1eucPE3kwPXR0WSWh6F9NDjE6bbydPORIILvhV4v/z4zZ2QiDQ+O+P09iD5Q7AG9iKRO6vb2bpN4ncDzB6Wleip9jFJVzsZ3q70dpV8AGrXV2k2M0xg2C51911ois3/T1LQnyUTR/11cFBgzCjbMWuXolrIwahtqm0vQy3mIrHyYu7c7vzSAKMcy0mHcmVqut0V+JORK48xBzkwFakpn51F47mk/P4TALslt6DWrMsE/PspM1QdRMMNS+yws7oPQsuSqpdslhNsBboqZjj64jNBCb3JCm7WajdPN+Gdve74GbjRPBvZkjreXS56OGNGConyAdmMn+6GzG0V01vlNTlIt66QD6wFHJhdTuJen9onBdXpBMcuT/UZVaQz+C4JSnCiWzt/JcDNV/8/5m74fMH7SrzmSKUBa2vjJY+f0RnRhEM9mzrJfvwAS0Rv0ttEsZK1CWmVy5M9BVmJ7ovXoJpVJF+faYVSymKJ/GLEzvWrmZFCGtGyObZLzVn/1ryXO9ZCCsqjStjrRF8NyOAmdULufMM3vs1I+IqTZtCVmmLX35hHhmG4B9XYPGaE8lA2tU/D65teYm/B9BBgB47ERkL+33mAlHuU6J/KvgwuJPHFzBizItHeY76hFPrQPw9e96cKdFNnz1yZ5NMjK6GYe9PLd2V9bu8NdwucdGWyvup8z8YiN6fNysRQav79j2owgUo7n0NeI8Rr9WQM93k77d/i3kY++2U/ZTv64snDGpbyPiH9t/QfBUHv0+I52uaHTVPGfCSf7ONNoEQTOrzWhTv3hUsF8Jn/LaZ/MU+8xjuORdNyvbd25WB91Hv3CM9x16Ab/OAAukn8K7Qh/lMAFFA4tki/N3/R5Z5VgZUQADU00LO8/DKZ9I0zdPU8+csK7zz98L/RfTVehV5GO3qs0eHnjDelIYQqq7Al4X35AWid5+MRow3haF33yKP3I8JyC/+Rx71HvU+Gylf4BJAu+qZSNIiz/mNX71f/PQZ/xWfFr6dYudwYXrxvl31rkG6cL3z/fZ4veQefmOF3lP+lPu6cn9PU69W3q6mct+l3/i48hf/fEbtO7cbT1fuNn5phT2Dapk8XuVHST1a2X6D8EjPw1u95966e6paV9FEebLypfX33Ns21c+Ai9cdkrm+4VGD1LarMV6u9xiRuyXud2Wn2sbyatbIfcEO2m4hcVscV9skl8h9PmxzOcgq7BgP1qj3RXtouREfWoi9QmPqOLlE7gsis03oWga+EtPrhuRPkfuiTgCw3HgSo0XY+XzfAXXkxif2II/MbBMY4bwEu0Xv+BS5bxU8iMnm97Oa5iruCDpyGUc+sA/nTSPBC35A7oFvxF2fu5/u11Pkvlnwwi/Yc3k3kRHmjod6j+er2wUv9c4byXpC7FLr8vZUBvlT5L5d8ErH4ooitdVi5NVLBHRT77F/Zofgld7lTYFQqft8U2Gpcrve88h9x0lr69uog0/aexggpK6uI/U+8PePS+S+o5em1ztSlx1pb4yEQfmLdmEYjXweue8RfO/vos9AkEat1Kf1jk6XyH1102rNZ9TpqGhildTRpL+79Fm9GW/K7HrHrbPY9a7nMyiP3LfsqT2fWa735BK570viB/nMIn9Hbn1Sj8a1s3v5jF3vWj6D88h9r8VvyWdOl8h9b06zIZ/5uETuuy1+Qz7zv3bO4AZAGIaBJRuYCUr2HxIEDx4g0og8ksobRKfIvUp1Qe7/I97vMxu5B0S822cWkHvAxnt9Jh/2eu8jm99nBOQecm/1+YyA3GOkxuUzAnIPi5pxnxGQe9zhOuwzAnKPtxrTZzaQe/TN1fYZSYu9bs+m2z4jicev229Sw2dy/5xWuFe29i+f0eROBpQm/+4zqSOmPvczbZ4+k33XZ+B+LL32du97Ey0x9SS94avIWujHgh0Xpnp2ycqJawAAAABJRU5ErkJggg==');
		background-repeat: no-repeat;
		background-size: 100% auto;
		background-position: left bottom;
	}

	.PromoterRank .header {
		width: 100%;
	
		background-size: 100% 100%;
	}

	.PromoterRank .header .nav {
		width: 450rpx;
		height: 66rpx;
		border: 1px solid #fff;
		border-radius: 33rpx;
		font-size: 30rpx;
		color: #fff;
		margin: 0 auto;
	}
	.PromoterRank .header .nav .item {
		width: 223rpx;
		height: 100%;
		text-align: center;
		line-height: 60rpx;
	}
	.view-color{
		color: var(--view-theme);
	}
	.PromoterRank .header .nav .item.view-color:nth-of-type(1) {
		background-color: #fff;
		border-radius: 33rpx 0 0 33rpx;
	}

	.PromoterRank .header .nav .item.view-color:nth-of-type(2) {
		background-color: #fff;
		border-radius: 0 33rpx 33rpx 0;
	}

	.PromoterRank .header .rank {
		padding: 0 20rpx;
		margin-top: 15rpx;
	}

	.PromoterRank .header .rank .item .pictrue {

		background-size: 100% 100%;
		width: 136rpx;
		height: 177rpx;
		position: relative;
		margin: 0 auto;
	}

	.PromoterRank .header .rank .item .pictrue image {
		position: absolute;
		width: 130rpx;
		height: 130rpx;
		display: block;
		bottom: 2rpx;
		border-radius: 50%;
		left: 50%;
		margin-left: -65rpx;
	}

	.PromoterRank .header .rank .item:nth-of-type(2) .pictrue {

		width: 156rpx;
		height: 205rpx;
	}
	.pictrue1{
		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJwAAADNCAYAAABNahkfAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoxNGUyNzRkOS00YmQ4LTUzNGItYWZkZS02ZTlmMTgxYmZlYWUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NUU1MTlBRjBEOEU1MTFFOUEwRjRGRTQyMUZGNDk5NEIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NUU1MTlBRUZEOEU1MTFFOUEwRjRGRTQyMUZGNDk5NEIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTAxZGU2OWItNWM2My0xOTQ1LTllZmMtMGIzNjcwYTFmNWUxIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjE0ZTI3NGQ5LTRiZDgtNTM0Yi1hZmRlLTZlOWYxODFiZmVhZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvxFTDIAABepSURBVHja7J0JmFTVlccP3TR0Qzdbs4kBFDNWFHAlrriTaBwdU6iA0YnjMgoq4zaYzGQzGTOZmLiNCGrckjFRcSmXxEA04oILBEUENGUUcAO66QaabnoBmp7z73s7vdz7ql5VvffqVdX5f98pmlevXt++91fnbufe26utrY2yoniUsqpILNX0TuXXr7MdxTaAbSBbM9s2tnfZlrI9zLaFckGp/v0eqTeJkoF2Cr/epEGzaRTbgWzfYrue7Xa2O9l2S+YJcKmA1otf/4vteyl8agzbrWynawA3S0Z2V5FkgaMeThG2rprC9irbaMlGAc6Nd/ux9lCZ6Cts90lmCnBu2mw/9OhpX/fwWQJcnuonHj/vu2zjJFsFOJt3O4dfj/H4qWVs/yaZK8DZNNWn505mK5HsFeC6ejcM5h7s09Mn+PhsAS5HNZJtmE/P7ksyRCLA9dAoH4GDhkgWC3Bd1cTW4uPzWyWLwzW1VU5qTnKs9jSYBP+E7W9sNQH8/o1s1T5WfZ8HlI+jdR7ux1bKtk7/7vcFOKViPWyAkf1JtuY8G0IbMCG+wcd0bGLb6hNwOzTMfuoQtst0T3tEj/f2sP2ebQHbbwu5SgVgb5Oa8J7kcE+E1ODpm2zf9i0lkdhOUmFGfugjtg98zMcfsb3MNssCW0c5/xOp+eFntfcrOOCOZ3s+heECRGL8mm2Oj2nya+7zObZdPj37EbYbScXnudGZbAspHh1fOMDFo2O1a0+nV3gz27k+ebnXSAVSeqlaUjFyfgh5MSONz325/UsQjw4rDOCIfsb2pQw+f4ePQxjXsnkZBv1jDZ3XOilDb78v2w/yH7h49FB+nZ7hU/Ziu8onL4e24vUePe0h3dnxo6P17x4850ouj4Py3cOd4dHvPVMPpfgB3W38em+GT3mFbaZPeYipsq95VP6n5DtwJ3r0nIN1D9avXuvlGVQ5aLMhzNyvgWT06L0KBjg534Hbz8O0j/Q1pZHYTdpLuZ0lwGD12bod2Ohjyrz8u8fkO3BeZlYf31Mbid1D7kfpH2N7KoA8LPXwWYPyHbjPPHxWfUBpfsPlfUsDSs8OD5+1Kd+B+9ij5zQFmFl/clGt1uuOQhD6q4fP+jzfgXvbo+dgUnp9QGn+kJLPFOAL8ElA6cHv2Rmy8ggtcM949JzH2RoCSnOVBiqRNgeYn5jzfdaD56BjsyC/gYvElvHrYg8y6q4AU73VhUfZSMHFvGEmZL4Hz3mUy+OjfPdw0GxdiOlqDoVvG4Wg8/Ilttsy+DyiV36U75nU4eXWkIrdSkf/zTYv4BQPpuRDMPtT8CuzrmN7Ms0mwvlcDp8XBnBKT7BdwPapy/uxNdZ3KP39PjIR1juUJbmnLEv5iDy8O4X732E7jWFbUQjVQE8hROk4trdc9KSOJRWOkw0NdeG9+mkvF7TwRUTgJTbcSxYRjXi/E8i/QNPQA0fawyXrudbob2a2hEIqduHhTshiGp928aW4J8CefWiBg7YleR+xX/+QxfQd7/K+47KYRlStyWIEt2a7oMMCXLLGKxrs/5iVlKno5Aku7/4q+RUy5Q64REIQ6BYBTsnNaqx/zVLasOVWpct7EQlzVhbSiKDWE13k8U4BrrMdl2xCGmtWzwnYuyEqI9UwboQzBb388mJS20kkA65ZgFPCtNF6F/dh3KlXgOk6O42242Td5gxK4zRwybSaQrD6PyzAwbu5GRc6mu3CgLwb2o3/keanbwrQy2GoqJ+L+z4OQ0GHaW8Rt3FymGkYGUB6fs6W7trNI9j+M4A0Ttde2I3eF+C6a5XL+7Bi6yGfvRuGN67J8CnfJ+ezHbzQAeR+hqGe/N0mIyeBQ3zbHpf3nsr2C59g+7JHQGMQFlsrfMmHVJbqNLoND0enrFqA6661lFr4OdZlXusxbFhQ8gJ5twk0hkkQtzbYw1RWkNqY5ogUPrOSrU6A667qFKrVDt1KXu01Eo+iXYhFMPt4/HcdqgHxYlcmpA37saS6lnRVWAo5bBsSvpdmL+0u/c1PFzasIX3dxzYXdkbHeodMBoUxvbaQ1LBLKtrjcgSgIIFLN2OuIHXU0BkpgjaQ7Zf80x/I/7MUsJfH0/rLMTaFz2Gr1ls0sOks/K4Nk4frFbLjKxF3tjrDNs/TuvcGj2WLjMCIPDoGl7B9U4MQtLDa7CWdTmy4uJ06ZwEQldJffwGw+v8bKQLaU0utnjtLx1dmDzhnEF9Lo9pwares1j20rRriMboddBglnwoKSvBAWFeAgVnMolRS55apXgwe38Rw/SAsxRvG4ysXeQTcRG1hV6W2I316/uIw/bFh3MX8NRJ5pTo9JCLAJRDCn6uEFU+EjsYWAS6RIjF8K18QVjzRi5yfbQJccv1ZWMlY6PW+HLZEhfXM+5d0VRDccUHFA4j6jCIqGck2nG2YutZuFcrw/exVzP/oFYF7mojaEGK2h6i1Xtt2Zbs2s1Wzcetg5xfqWrBazrZGgHNXrX5K8egSUmcL+PBXDyIqO5CodH+ivvuwjVXXUq4fyroDm0i7txG1fMK2nn3PR0RNf+Vrvh6ws4jzcY8A514LPQOuqB9R/0PYDifqN56914gs5PQgZf27HEsBD9i4mmjHO2wr2FF6tmkm1i48FcZCDd/Ab4fUZPqatKvV3pVEFUcRlR/N3uwrqioMs1A1w+s1vEVU/yZ7v4x22l/G3u1IAS516HDKivuDL4pKGbLjiAaeoKrMQJc/eEofw/c+Ud0rDN9r7PlSXvtyBQM3P4x/We8Qw3YiqXWeyVU6jiE7lWjA8Qq6nBd/UcrGKxt+MdH2Vxm+P3Hbz9WyBPRiNob2LwvhXCqq0v+lpMcbcaH0P4wr3LO4XTaRCkKNq7jv/oxq8yU/LAebBc1mT7dJgLODhvoPy90QOj44IWgV3C6rnM69yzFUkNr5GVHNY1zdvpEMPGyhgcjoB8IyABwO4OJRRMM+SMkiWcuPIBp6nhrKEKkhlhpu5jYsS3YnBtIvYug+E+DiUVSd9yT0an25jTb8Iq46Jwhk1qp2NVE1f19b1ia6CyFaMxm6BYUJXDyKUdO5lGjVeHE50bBvc4dgSg73OAPs2da9SLT5N9xtSLgj1wO6bddYOMDFo4iyxcDkIY73VExmr3ZJejMAhSzMaFTfz+27JYnuQkTOVIZuXf4DF4+eRmrnS/uALgAbMUu110TpC+26qvkKQLswV419fhfmL3Dx6BV6yMM+7F8+iWjkVfzuQAHGC7XWEW3iVkvDcsc72K5m6O7KL+Di0SI93HGdPRUl3Fa7kLsNp0tbzY+23baFqlPR5niYjlrfG8Bkv//AqV2I/o9tmr0KrSQadQNR2f7Chp9q/pDoi5sTzdHiZJ8LGLqduQuc6oniD7Fvl4qpm73nSBUaZBX7BVc0TY5hclifey5D15R7wMWjWFuJfTXsJw4POJHba1dyCnoLCIHWsLu5XcdNtu0vO92BVV5nMnQ7cgc45dl+b4eN22iV5xINnSHttWy262oeJap9nBymxl7S0DWGHzjVZnvKXo0yYCMuIxp0mpR5GITORNW9TtChep3qdZvOW+DiUQx38FfHtvkzd1T3mq2qUlF4tJ1r0I2Y8LF2UBFxMoOh82xvYK9Xbf3UEbZR1wtsYdSAk1TZ2FFAWf4snB4uHsV5T/Os1ehI9mwDT5LCDbPq2NNtutOpevUsgtgb4NR0FToJ5gxCe5vtG1Kgud2ma9WdiD9mv0qNR7Gt1G+tsA2ZKrDlktCZq5xqe6e4vYxVWWcRuHgU5wPggFhzIh7rC4ZdIIWYaxp6vio7U4Pby1qVedY8HCp9M8QIaz/RbpNxthyUbnP3sx5RgbKemx3gVKSuGTzZPjc6R2YQcpq53qoMe1vPtLuIy35asJ0GtQZhJfUMC0dCR/9UJuLzRZjw//R7ajqsuxCufnA6aySK0oAN9eSDZFuDgDWUAlv+CHuvDL/YqT33kGbB9yoVmzGbq6sQPClTVvnZc0XZmjpZs+BjlRqP4pyrNYZ3Q1j42Ntk/UG+CmFN66+xhaujah3PVavrlf6perjbrFUp1iAIbPkrxCuOuMKpar3dnyo1HkU1Ot24XnGsLHgpBJV/Va2kMzWN2TjJW+DiUYxx3GGSX86NykulMApFIy5VZW6r+VSkkGce7hKyHVY79J+lKi20qhUL001hl8VLvQFOhYrfaFzvuy/3YKZIIRSaBp6iyt7UD3Wkd8Ye7iqyHfndPj5TJAVQcCpSOyKYwjlpV2QGXDyKCvt6swF5hGwsU8jCPKu9o3iDrhHT9nAz2YZ1v9RLbZklKmy1M2BMNAxnm5UecKpnOtu4XnGM7M8mUgxgSMzUbM1Oyh4OY25jDO9WOU0yW6SE5Z6mlwMz56UDnKXtdnjhbnMqsni5MU7zrNemBlw8it3DDzWuDz5LMlnUgwnr2S2HaoZcezhzEA/bnkrPVGT0WCcoNkxd5g44NRTyLeP6oFMlc0UOXs4aljZDs5TUw52N1lr3u0qdFlaIROr0H/NAFjB0jhvgprl8oEjU6ZDAiAuWinpUp1ju9zXjYzi7SiRKJDsjU5ipykQe7ptsJd2u9B6iD0oTiRIIjPQ2lieXaKYcgTvTrE6PIVlfKkquXk4zD2fYgYtHS9pdoAHc0ZKXIpedh6OdqtU+Ng832eyd9lOH24pErqrVCDPT39ZbPdYGnDnQhmO7JeZN5L672v2I9U6dZgPO7NfiPFKRKBX1P9x2dXJ34OJRDLKZd9o3NBGJnNXPOqIxSTP2dw+HKf++3W7B4piSkZKBotQEZsyFVX00Y38H7kizAShjb6J0Ow9Wdo7qCpzZ0iuVTWlEacrOzkFdgZtovC1h5KJ0ZWdnogJOxZ8fYH5orGScKE3grOwcANbg4cYZHYbiAbKiXpS+wI7JDxgbB+DMZdR99pZME2XYW93LdnVfAGdWuCXDJcNEGQJnZWgfAU4UOHCjBDhRQMDtBeCGGZfRaRCJMpGdoWEArlKAE3kPnPVY+aEOwFVIhokyBM7K0BAAZ+6hWdRfMkyUmYqsR3JVADhz/V9RH8kwUYbAWRkqBXCWkF5ZNCPKmDhrRYurZmVbVCb5JcqQN+vC+XJZsCAK3O81GFf3NEnOiDLTnmbb1QYA12peb5MME2VKnO1iK4BrMe/dKfklypA3K0PNAK7evHmHZJgoQ+AabVfrAVyt6fjqJcNEmcnO0BYH4LZLhokyBK7OdrUGwG0W4ETeA2dlaDOA22Bc3lUtGSbKTHaGNgK49QKcKCDg1gtwosCBW2dc3rlBMkyUIXAbbVfXAbi11HPwFz2M3dsk00TpCeyY/ICxtUUUie3mHz4wPtTyiWScKD3Z2fkArHVEi6wyP7ReMk6UJnBWdtoZ6wDuPePt5g8l40Tpyc7Oe12Be8t4u+l9yThRemr6wHZ1aVfglqNvajT8dm2SzBOl2DutYna29rwKtv7SCVwk1qyh665G8XKiFNW4xnZ1uWas20qHJcZtO96WDBSlJjszr3f80BW4heaHV5JD5KZIZBGz0vie7Y0/2oADhd3XNyAQsyku+Shy2VlgVlqNJTK48IYJXCSGht2LxkPq35CMFLlT/Zu2qy8yWy02Dwc9ZwdOFtWIkqnNyTn9oet/egL3DDq23a7s3iJjciIX1ekHzIoRPA6WYs7ARWK11mq17hXJUFFibX/FqTqtTeThoAVmtfqa08JWkUixsf1V2zuP97xgA+4Js7farKATiaydBatDanAHXCSGGx81rm9dKBkrssvOxqOapaQeDrrXuNKylqhxtWSuqLvABNgw9SvbRTtwkRgmWleYJD8rGSzqwcRztqsrmKFl7oFTus240rCcaf5UMlmkaz1moeEvtndud/pIIuAeYetBVxtR7eOS0SKldhaMSQEw87vUgVNrHe40eySvS/i5SDFQ/7rtnTs1Oyl7OOhuthrDy9U8Ihle6Kp51ObdqjUzlB5wqlt7i9mWW+YUaCcqBDVx2Tcstb1zs20oJBUPR7parTKuVt9PEitXiOIyr7rf9gZWPs9L9unkwEVi2J3wRrMOX0dU92fJ/0ITyrxlne2dnzArTZkDp3Qfm1mHbv6N0z5gonwUyhplbgphvr9y8wh3wKlex7VmAri6rrpPCqJQhLJutTbRrmFGWr0DTkH3AlkjSZY4Df6J8kko4/oltneeYDYWu31MqgeDXMO21SR/nlSteV2VbldlbAo71lydyqNSAy4SQ0/kBuM6Fk1vmksSip6P4jLddKfTblo3MBMb/ANOCX1i04VinnWbhDDlnbYtUmVrarHuTJK/wEVicGMXWqvW6gdkE5x8Esqy2jrmhrL/F82Cz8Ap6D7j11mm9+XO7Bc3yy7o+dJuQ1m2WadFZzEDaYUNpX+aYCT2GL8+aLbnaok2OCZUlBPNNi67Db+wrcKi9jJXZU/BAqd0Fdu7xlXMs6KhKZ2I3O0k2KO7V+oyp+wAF4nhQKWzre05rOKp+Z2UX64JUSD2FVhb28talXmWgFPQIaD9fLIdg1n7pPRcc6pHutApwLa1vYwjsY8z/RXenAgdiWF3nNlW91x1L39jFkthhl11i1VZ2ZtBs3UZUziAU9DN59dfWqHbOFc2xQmzUDbOA/e36rKlcAGn9F1SC6l7aA/3em5hT/eyFG7YhDJB2dhjG7lNZJlZykC92to87knGo31IbWByuuXXEY24nGjQqVLQoWizLeJq9B4nz/Y8W1Rv4xZi4BR0/Uht/XWyFbqhM4gqp0mBZ3Poo+Yx7iAscIINje4zMu2RBgecgq6cX7Fy+iTr+wOnsLebySkolvIPlLXd3F6bl6gjh3bPmcnWJoQPOAVdmW7TnW59v2w80d7cRCgeICAEoY7pqibHBVCoRs9xEyoeTuA623QPs51rfb93pYKudH8Bwk81/41h+7nTdBWEAbgLvG6zBQ+cgq5ID5lca09FCdHwi7gzcZpq44m8ba9hQLf6Qf5xl9NN2NZjjtsw8fAD1wke5uGw74S94VY+iWgk31I8UDjxqgrFvKg9nq39DlLrEeYGlaRggVPQwY1hknWwvYodxJ2JWQzfEQJMJsJi9ar5ic693aqr0OeDTFbwwCnoxpEaVDzE8Z6KyVzNXqIAFLkXAEPQpH3BS4cQ4XO2ngen/AdOQYexOrjyixzvKS4nGnYh0cBTpG3npq2GRcqbf+20lK9DD7Fd6ccYW7iB6wQPI8B3O1axUN9xqlPRb4JwZRNi19ApaEnosFCFzmTQFmQzqdkHTkE3Wn/zTk54H9p1Q89jAPcRyCAc9Y2Yw4Zlye7EKO+FemkACXAKOtSZF+vhkwQNN76t4hg1NdZ3TGGCtvMzNTWV/JSgbe3DHVhpl8aCl/wGrhO8kaR2bDonSdKJ+h9GNOQsrmonFkjVuYpoyzNEO94hF+H7mOG5OtV1o4UHXCd4JxJisYgOTXpv6X4qAqXiOKKi0vyCrOOMDER2NLsKuMVm4NcxaC+H8c8JL3AKuqL2hi7R99n2Sno/YAN0A08gKjswh3u2bep8M6wtgLk7BQi7ItxEOPIgwZanApw78BAEgHWw32Eb7uozmKOtOJrtWIYP87RFIf8j9zBkH6p9c3EMpPOcZ09tZvsftvl+TroXFnCd4CHk6XJSG6iMdv05RKP0P4TbegezjScqGRGOv2dXtRrSaFzJ7bJ3U11Ajh7nHWz3+BVKJMB1glfCr9Pb2ypu2niG9xukqlxEqGCIpe9Y/2c0MAOAYQzs/t38EVucgduczpNW6LbtYwzarlwrutwErjt8mHS9lO08tvK0n4OAgT6jlPcr4Vq7ZJi6VlzRaaiWEdlS1FfXgi06AoOrw9b6LlanYIIH21VFtHNDptuZwYNh6/j7nE54EeCyU91iUfYMNsyFleT4XwSSsYky9qd/MpeqzcIArjt8QwgLQBAqreArz5GUN2jIsB4kxpBtybeiyU/gusOHiOPJbKfqfyex9QlJ6hBdi2A1hHYsav/X54hbAS47QyyA7ki2g9gwTXFgABACpPfZVml7qx22HBjKEOC8h7A3vyJGb58u/3IPgiq1DWUbou9Gj6Gf/hkhPi36Z1R/OCaqVhumlLhLSmv1v+tysVfptf5fgAEAz+JzEYHECRMAAAAASUVORK5CYII=");
	}
	.pictrue2{
		background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAACxCAYAAAAfz/U3AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoxNGUyNzRkOS00YmQ4LTUzNGItYWZkZS02ZTlmMTgxYmZlYWUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODVBODg2MzdEOEU1MTFFOTg4RTM5OTQyQjhDODMzMTciIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODVBODg2MzZEOEU1MTFFOTg4RTM5OTQyQjhDODMzMTciIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTAxZGU2OWItNWM2My0xOTQ1LTllZmMtMGIzNjcwYTFmNWUxIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjE0ZTI3NGQ5LTRiZDgtNTM0Yi1hZmRlLTZlOWYxODFiZmVhZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PuM0xM0AABKbSURBVHja7F0LdB1VFb0vSRuSJmk+TWM/KJC2gAgUBWVVQCyKrQsVqC2ggFCgtFC0pbJc8il/qC6WRfn/EVCgUAu4lLYsiiIgVflJxX7oR2kS0jRJbdqkaZPWs+fdV+bd3pk3783Mm3kzZ6911ry8+eae/c4599xz7yT27Nkj8oG1a9eKEKKOZCbJZJJRJKXy+z6SDSR/JvkFyQdBP2hjY2Mg9y0S8cUFJO+RXEdymIkcQIkkTOqY+XFtpLgS5OckD5KMcHAsyDKL5HmSAUyQ6GMOyRU5nPdtkseZINHGF0huc3H+GdLtMEEiihs8ukYpEyR6+BzJNz24znCSbzFBoofxHl7r60yQ6OEwD691FBMkehjp4bUamCDRQ7uH19ri87MmwtJoJQHeG8HeeSRfJfkUST/JJpIlJE+SNHt8vw0eXmu1D+1xKMlZJONIhpH0kDSRPEeykGRrEEpKBDQWM43kFpEcC9EBRLmW5F4PH+FUkkUeXetGkrkeXWsgyfUimcCzytSi8a5obGxcFAeC3E7yI4en3Ucy3aNHKCNZJ62VF13mf3n0XK+QnOjw2OuIJNdHOQaZlQU5gItJrvHo3jDZd3pwnWc8JMeiLMhhEIR+aOdG1YIMpc16kvIsT+2Tv9hVHjwG7o0h/KNzPL+T5Eskazx4FoztPJ9jsD2GLElH1CzI+TmQIxVIX+rRM3SL5HjKdhdxzBqPnmVOjuchbsubFcknQdxkH0+UwZwXQBxyPMmKLM75D8nJJK969Ayo/jnOxflfiyJBDnFx7iibHk8ueEc2shOSLJbKfMnD+3/GZduPiiJBqlycWyq8z9m0kvzSwXGzSTZ6fO9BHvTIIkeQj1yc20LS5cMzvSGDYCv8V4rXcJsE/DiKBPnQxblQkh/pbRQj21VTr5KBrddY7fK6G6JIkN+7OPd5H5+rNUOX0g/AGv7WxflPRpEgC0j+l8N5O0Qyo+oX7MY4mny87105nrfG5x9MYASBIqbmcN5U4e/oqd3IabmP932X5Ooczju3sbFxTxQJAvyO5Mosjv9pHsxpjc2+T/t875uF8wFJuKXTiBxv5lNhQdSD3EpyeoZIfKVIpqLn5eF57AhSkYf7zxDJSnm7wBNjP+OJHM/lW1lBFQxhkOpnNvvvcBnUOgUSTnZzGo8U3iborPCwSNbBWLpZIsc/glBUkBVlbTb7TsnTM2DgzS6FX03y+Tw8BxKBE232dwSlpCAJYudiviKSFWd+Y6KDY/IxxeFkm3gHxVOb40gQJL922/QeLvT5/lDIdxwcd04e3MzMDD+knjgSpDWDm0Hw5ueYww8dBqHVPpMVtSl2I90IXnvjSBB029632Y/SwJt8ujeKl6ZlcfycDL0dN8CAoV0uZlWAOgqUIEj2rHNgeg/34d73k1RmcXw9ya98eA4UQo3LcMwHcSUIkKk6Cz0MJMq8HOr/nsPYQ8XZJN/18DnGCmflBuvjTBAnvw5MmVzg0f1AjMdcnP+USM7jcQvkXv5AUpzhuM44uxgA4xFOJgSdRvIbl/fCfNqnHSjFDjgXVe1HuLjGKEkOJ934lSKPtR9hJEizbASnrmGR7FVkC8yteU14s64HurzIal6Sw7nIqbxNcrDD45cHrJ9QzM39WxbHniob+CyHxx8oY5h7hLcjs5gBh+H65xxakxHy+BeyDI7fDlo5iRAsgzmJ5NkcLrlMJMcwMLqJcsadMqjFzPuDRDLBheUtq3z+11Cv8qJIrl+G+pGN8llgafaXzzA5h24ykoiYD/RvI2gJaBnMvBHEhjgNsjdTmeMluqViUIw0WOY4Bgf4L2HcZBdJrXC3KuJbRIqjg7YggbsYaoRWGazmCriO0SKZkRwdMDmEJEaDcL9k5lshcP+hWR9kuWCoeJ0J8gleYj6kAYNzS5kgn+A14W+BcKFhGbnej8PwICVheAhqjG4KVlGvepkv/2RJiRg4cKAYMGCA8RlSXFxsSFFRkSHGr0Vud+/evXcL6e/vN2TXrl2G7Ny509imjvMBC8PC1JIQ/Wpe8IIgUPp+++0nysrKRGlpqUGMlOIdm1WFMFYAaUAWSE9Pj9ixY4fxnQfuZQkTRO9mkFnNqpIskUgYhCgvLzcEhMgXQEYQETJ4cLLzBLJ0d3cbAsLkkEZYTha1mQmyr5vZQW4GYyWzHfVtiQwVFRVi0KBBWVsIPwGCQqqrqw0XtH37drFt2zaDMA7xQJiCocATZSkQOTBq+wjJMXaxRFVVlaisrDQ+FxL6+vpEV1eX2Lp1q/HZBlgBaSb9YFYwQZLEGCKSq/xNs7JocCH4RcJaRAGwKlu2bDFckBWfRLKo6VoiyubYEoTI8X2RfJtTvZUbqampMQgSRYAgnZ2ddu4HNbuXE0meiBVBiBj7y1/IBN1+BH21tbWRJYaOKB0dHUZPyAJY5WgaEeWjyBOEyIGyPczWr1X3IU9RV1cXGVeSi+tpb283ciwadEqSPBtJghAxMIUB65RO1XVV4UoQZ+BznAF9ID6B67HQzcMyiO2JDEGIHCjcQaZ0rC4Ara+vz2v+ohCAfEpbW5tVIIvR79OJJOsLniBEDkwrfFJ1KbAUiDNgNRjWgDVBfKLRE+pOziKSLC1YghA5sKwByv0GqLFGQ0ODkQpnZEZvb69obW3VxSb4YgaR5KGCIggRA4EE3ohwlboPAejQoUNDlf0sBCAru2nTJiOQ1QAL0Vzjx8pDnhNEkgMFujPUfXApCEYZuQPBK1yOBrDUl3pNEk8JQuTAvBGky89R4w1YDYydMNwDYzuwJhrdoXD6fCJJf+gIIi3Ho0JZaB6uZNiwYbFJeuUL6N20tLToalJ+LUniiWKLPCTHXSo5MBw+YsQIJocPQJuibdHGCn4AXUidhIMgIvl6sbSYA6Ot+Ac4v+Ef0LZoY83I9gypk+BdDDEVD3O3znKgO8vwH+j+NjU16arZLiFXc09gBCFyYGUczCorNsccbDnyD2ReQRIlJkGeZAKRZFneCSLT55jEXGvurSAgxWgsI5jAtbm5We3doE98DJFkXS7XLMqRHJjNtlAo6XN0ZZkcwQau0IEC6Gih1FneglSsjJP2/nokwTjPETygA+hCAQZJ78gLQWQ9R9qqf0ifc4Y0PIAuNDU1U6Xu/ItBZCXYu2bXgp7KyJEjeWwlZECwunHjRnWAD0VHR2ZTmZatVu9Xg1KMyjI5wgfoBLpRCrBqpA69dzGywHiCGnfwkH14Ad1o4pEJUpfeuRg5NQEr3QwxR8zIdzDCD+RHlMo0TKU41MmUCqcW5AYzOWC2UCbIKAxAV4qrGSJ16t6CkPXASsd4EXGxOUrWmC5GiIEaEtSSmIC8/FFkRd53a0Hmm8mBXgt3aQuz66uMjRVL3ebuYsh6YFXhk8zfYd5K3KcmFCKgM+hOwUlSxzlbkLS3LSCNHtdJTVEAdKcZCrkpJ4LI6Qrj1G4to7Ch0eE4qeusLchPzH9gIjVXhhU+Uovt2Ok6I0GIURiIG68GOYzoBKwKxkudO7Ygs1TWsfWIlhXR6HOWI4IQk+Ckppi/4+mR0YNGp5Ol7jNaELxZaS+9UBDLPZdo9miUYucyqfuMBLnA/AfWBGNEExrdXmhLEDIxeP3E3vefILmCBeMY0QR0qyQ9D5ccsLQgU9RgptBWE2Q4B3SrSZxNsSPIGeY/uMY0+tDoWE8QMi1jaDPG7F6YIPEIVhU3czBxYbTOgkxQ3QuXEkYf0LEmJzIxI0E06VhGRKHRdTpByKQgEj2BCcIEkThBcmKvBTkS7ii1F5OveW5tfABdK8tIgDFjzQQ5To0/GPGCRudfNhPki0wQJoiCY80EGcsEYYIoMDLqRRSMYObTGNUnMeIXhygYA27AghwiTO9pQfqV8x/xA3SuVL2DE4eACaPYejAAzZJho0GQAzMcxIgvQQ4AQQ5Isys8ehtbaHRvEGQ4E4RhofvhIEjadCvNwqyMmECj+zoQpJ4JwrDQfT0IUsMEYdhZkLSaM56YHV9odG8kyjgrxrA0KiBHWtk6Z1HjC43uK5gNDHvSkHSZv9C8oIYRE2h0vw0EYUYwrNAPgqS9wTnfr2pnhAca3feCIOlL3/X3c0vF1Vzsq/t2EKSNCcKw0H0bCNLOBGHYWZBm8zd9fX3cUjGFRvfNIMgGJgjDQvcb9iGI8n4RRoyg0b1BkDXmb/D2RAYTRGINCLIS1sVsZjibGj9A5wpBwImVRY2Njb30YTVbkXhDo/PV4EZqsO498x7l5TOMGECjc+M1ISmCLGeCMEEU/NVMkNeZIEwQBa+bCYJXnXan9iCjxnFIvOIPJYvaLTmRJAgFI4hYXzUf0dPTwy0XE3R3d6tf/UVyIq0e9cUMJzHiQ5A/pj6YCbJYtSCcD4k+oGNN/LF4H4KQSUEuZG8+BMUj27Zt4xaMOLZv364WCq2WXNjHggBPm/9ggkQfGh2ncUAlyAK168Oju9EFdKvpjCywJAiZlhVCZtBSbqarq4tbMqKAbhX3skJywNKCAA+b/9i6dSu3ZESh0e1D6hc6gjwG72I2QwhkGNELTpXwYYfUvT1ByMR0qH5oy5Yt3KIRg0anC6TuM1oQ4HY1WOXxmejAQp+3647VEoSY9A5tXjF/19nZyS0bEWh0+YrUuTOCSMwz/4F0LFuRaFgPTWp9ntXxlgQhRi2lzRvm7zo6OriFCxwaHb4hdZ0dQSTmmv9AUoV7NIXdc9EkxubanWNLEGLWy7R52fxde3s7T/AuQEBn0J2Cl6WOcyOIxOUke6tJUPnM3d7C7NYqVev9UrfCFUGIYf+kzQNqFMwVZ4UD6ErTc3lA6la4tSApP7XZbK7a2tq45QsE0JUSFmzOFHtkRRBiWptqjtBdYldTGK5Fk564XOpUeGVBQJLHabNE7TL19vayFkIK6EbTrV0idSk8JYjERcK0IhHMVmtrK5cmhhDQCXSjuJZOqUPhC0GIeR/R5mLzd4iMN23axBoJGaATzWTs6VKHwi8LApI8I5SaESRgeKwmPIAuNAnNR0h3C7K9Vq4L6V4m5MQaczzCNazBAzrQxB3Q1cxcrpcTQYiJGO2ZJJQVEmHWeEAvOKDtNe4eOpokdSbyZUFAknW0OVOYsqwIiFpaWjiJFgDQ5mh7JSiFbiZLXYm8EkSSZKl0N2nRc3NzMy9llUegrdHmmt7kZZnGWnwliCTJPUKpJ8BEYCZJfsmhWcJyntSNCJQgEleS3Gv+AgWxTU1N7G58ditoY83cpfukTlwj4dXQ/dq1a/G6okdJzk1jYFGRGDZsmO7d8AyXASliDo1bQWX6eWQ99oSKIJIkeOnZIyTnpN0kkRBDhw4VFRUVrFmPurLorWh0hxT6+UQOz5bLTnhd/CMtyd0k09V9tbW1oqamhjXsAkiCWZR+wsVf4pXl8I0gJpLcSHKVum/QoEGGNeFXn2UHuBJYDYuSz1tIrvaaHL4RxESUC2mDSDrtlc54R3xDQ4MoLS1lzTsARmUx8KbpFSI6nUHEeNCveyf8ri8lkpxMm6eE8n5exCVwOdXV1cwAG6CeAy5FoydkSM+0q0gvCIJIkhxEm4UkY9V96N3U19eLgQMHMhuULiwqwSyGLjC2MslNhjRUBJEkKafNnYiy93kIsiYIXmFN4v5iZ+gDVgPBqIVukEq4NNexldASxESUKTLi3qc7g9ikrq7OCGTjCASgmJpgkYGGS5mey5B9QRFEkmR/kayU/4Zuf1lZmRGfxCW5BjeCOMNm6VGUel6UbbFPwRLERJSzaTOfZIhuf3l5ueF6okoUEAOuxGbJUVSfzyZiPBHUMyaCniVHJAE5biWZKizGhkAQxCdRcT1wJRbV5ubu6/0k1xI5Ngf5rImwTKMkohxFm9tIxlsdU1JSIqqqqkRlZaXxuZCAATWsCYZlnzIsDIhlN+ZYLccQW4KYiHISbW4gGWd3HNwPxnZgVcKalUX2E9YCYycOVq7GSgpz3dZvRJ4gJqJMpM2P7SxKqosMFwTCgCzoCQUJ9EBAitR6Kg7adxksJxHjxTDqIRH2mfpEFCTXZpOcQZIxN19cXGwQBj0hpPKRgPPLwqTeigFBDwSEcPjeYQQf6K7OJ2K8G+b2TxTKUg5ElFqRLCO4gOTwbM6FVUkJYhcIiJQSWKGUAGiTlEDhKYF1gIAQ2OYwYQxr0GKpycd1C8YxQbwjCwgymQRJt4ND/rirpLV4hkjxfqG1daLQF4MhsoyizQSSU0iOR/wa8CMhGv2TSL5eZTGR4sNCbt9ElFYLIrIgQj2G5Fi5PYJkjFDKDbzsvYrkGzKwzsbfSd7ElkgRmWrtRNSXkyLSILD9LAlGlA+Q2+Eimb2tkzJABsDlJiuAZQug6HaTNJGsl4KR1A/ka2Uji/8LMAA3i+ZmMc/g0QAAAABJRU5ErkJggg==") no-repeat;
	}
	.PromoterRank .header .rank .item:nth-of-type(2) .pictrue image {
		width: 150rpx;
		height: 150rpx;
		margin-left: -75rpx;
	}

	.PromoterRank .header .rank .item .pictrue3 {
		background-image: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIgAAACxCAYAAAAfz/U3AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3ZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQyIDc5LjE2MDkyNCwgMjAxNy8wNy8xMy0wMTowNjozOSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoxNGUyNzRkOS00YmQ4LTUzNGItYWZkZS02ZTlmMTgxYmZlYWUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6MTExRTlGRDlEOEU2MTFFOTg0MDg4RjQ5MDM3QjNGRTIiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MTExRTlGRDhEOEU2MTFFOTg0MDg4RjQ5MDM3QjNGRTIiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTggKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTAxZGU2OWItNWM2My0xOTQ1LTllZmMtMGIzNjcwYTFmNWUxIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjE0ZTI3NGQ5LTRiZDgtNTM0Yi1hZmRlLTZlOWYxODFiZmVhZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PudLP2EAABWKSURBVHja7F0JmFTVlT690xs0zdLNbqTZJAoEghnUjOKM0fm03EIhSfCLaDQojlsmziQmdIxjcL58EaPGJYtJdEQLo1LJjOh8okkExbBGhO5mR6C7aegGuhvofc5f9zVVt17Vq+29Wt67//edovvW27jn73PPPefc+7L6+vooWWitLqM0wxCWJSzzWKpYCrT2bpZ9LH9m+RnL9nR42NLq40m/ZzY5F7eybGWpZpkaQA4gVyNM/zGPO7WTnEqQ/2L5FcuoKI4FWe5lWcWSpwhifzzA8m9xnOdieVERxN6YyfLTBM6frw07iiA2xcMmXaNAEcR++DzLv5hwnZEs1yiC2A9zTbzWPyuC2A9TTbzWDEUQ+2G0ideqUASxH46ZeC2rQ5pZ6dJpuSm8N5y9b7JcxlLJ0sNyhOVtlhUsh02+3z4Tr1VnQX9MYVnAModlBMtplkMsb7L8geWkkwhyO8ujJHIhoRzA77IsZXnWxHtuMvFaO0y8Vj7Lj0gE8IIjtYjbIED3fRLBvTecMMQsZ3kuDDn6MZzlGZMJAsvUYNK1XjX5uf6djMP441leb60uW2p3giCncU8Mx9/B8gOT7g2T/ZQJ11nJ8qlJzwSLcGkMx1czSW5OpsKykpXu5/8YrMJelqIYT0XqHUGuWhMeA/dGCn9WnOe3sFzIstOEZ8HQsSpOZ3tiafXxZrtZkFviIEe/n3SXSc9wikQ+pT3O868ziRyk+RzxAENz0qxIMgmSSPTxUs2ZMwN7WC5h2RbDOftZrmD5i0nPAJ/i4gTO/yc7EmRyAudWRXBqY8VmrZOjIclqTZn/Z+L9xyXY91V2JMjABM4tsGBK3sjyRBTH3cdy0OR7Fyd4fqEdCfJZAufWw8+14JnWaU5wOBzQxGwkGgRssCNBdiVwLpRkRXgbxci7Db6v1Rxbs1GX4HX32ZEgf0zg3FUWPldjhCmlJbN+lpcTOH+FHQniYTkRx3lnSERerYJRjuOQhfd9Os7zdlr8B5MagpRWH4ciFsVx6iKyNntqlDktsvC+W1geiuO8m7kv++xoQYDXWb4Xw/H/kQRzOtjgu7EW3/s/Kfp8E4al65kcHyVTYalI1v2E5YYInngNiVD0siQ8jxFBSpJw/8UkKuWNHE/kfuYyOd5MtrJSVTCEJNVjBt8/maBTGy0QcBpv8P00MjdAFw6/IZHVNRpmN6RCUamsKGsy+O7qJD0DEm9GIXwsJv5CEp4DgcCrDL5vTpWSUkkQoyHmH0lUnFmNq6I4JhlLHK4w8HdQZXfUiQRB8KvXYPZwm8X3h0KujeK4hUkYZpZE+EM67USCNEYYZuC8WZlz+NcondAyi8mK2hSjTDec1w4nEgTTtk8Mvkch8yMW3RvFS7fHcPwDEWY7iQAJQ6NYTG0KdZRSgiDYsycK03u+Bfd+nqU0huOHsfzcgudAIdScCMdsdypBgEjVWZhhIFBmZqr/a1H6HsH4BstXTXyO6RRducFeJxMkmr8OLJn0mHQ/EOP3CZz/Col1PIkCsZf/YcmJcFyLk4cYAPmIaBYEXc/y3wneC+tpX41CKUbAuahqvyCBa1Rp5IhmGl9DSaz9SEeCHNY6Idqh4Q1tVhErvs3yAZmzrwemvIhq3hnHuYipYAHXpCiPX59i/aTF2tyPYzj2Oq2DF0R5/Oc0HwaLsMzMzGKRE9L1b0ZpTUZpx3tjdI43pVo5uWlAkPfJOFAUSukva7EJ5DCQ3UQ5Y6fm1GLl/bkkAlzY3nKghc8On+YrLG+R2L8M9SMHtWeBpRmjPcO8OKbJvZSi/EsgspK5T2rIYEh1WYU2mymN8xKnNMWgGGmQFuMYlML/EvImXSzllNiuiBtLq4/PcrwF4U5oZJLAWb0kzktg6JgQ/k8gm7ILiyk7v4iyCwopK38AZecNoKzcPCE5bHSyEafK4p9Fd/T1dIswTW8f/9xJfd1dPuntOkN9nWeot+M09Xaeot7T7XyYLltQblLXbEwD654WQ0y/M3ZJwlfJyqKcokGUUywku7CESVHsa4/pMhpRMGfJyjNI9rL17e1oZ6K0UU/7CSGnTvjaTcBaRRA/sCjpO3F52QVFlDtwKOVASgezwchJ3lMz8bIHlPgkd3Cl4ExvD/W0tlDPyaPUzdLbEVfxOpJz7yiC+PGB5keMiooUrJA8Vkju4Ar+uZjSCSBo7qChPsGcuvdMO3W3NFJXSwP/3BbtZdbw0NuQFv+fVDupAc4qch13h31Q9hfyykdQ3pDRvqEjNi9lGFHJaP6X/ddilsKhPN/hyU1+qRD4IeyrUK6WPO4+LXwL9j+os1VIBw8dpxqJ2g6zMJfb6tkVjW0NOIairmMHqau53ufTGGARE+QFZUFkeEMRJLuwlPIrxlFeGZvw7CjCNgVl7CZO5EnmFKKy8ewFj+W5RIwhkH6i5LF1GmAwOwVpQJYTe4mO7eD5Sx23hS/AB7ELRk+mgpETqYsNRGfjfiZNa6jh5e20sYhpZEEGkFjl5gtB5w4cwsQ4h/2KCLU68DnKmQzDpwsZODa1/5GTB4iObBHSzKTp7TE8vKf1GBNlH/srZ9dovc/W4zJFkNAk+VlOafl9BSOqKKekzGigJxp2AXssFxFVzhJ/6ekIDEENG9i74glJ099DTYn9RGk7Th31u5gwzV9ngrysCKIbYNxT+3q6X+Ap5hfDHlPIvsS4uURj+Q9sQDllFM40Ex14j2j/Gh5Emoymzn/m2dEScnm2KYIIYrDH6Nvl7/awPlH5JKLxV7O1mB1zTCPtgP5u+JgH0z/xEBQ2k49IHYqaljJRjjqXIF7310m8zWlYyO+HTyOa+FVBEDsCBKl7jf2VreGOgKm5n0nykrMI4nWP0f5Crgz5PWYgUxYwMSaTI9BcQ7RjhZgJhcZqn4V1eT6zP0G8bpTtYbW+3okoqiCaupBoxGxyJOp56Nn+IlF7yB0pWjSSvGZPgnjdCC5gn1L9Cv9sdj0mXE9Uda0IWjkZCM7tWkW08w2eIofc/AglDnBiT9uHIF43ajiwsn96SAd0GvunpWNIIXDOf5Bo63PhHFlkv29gkuzNfIJ43VhWuEI3pMBqTJ7PsxNX5s9MrJzx7PYS1XjYmuhC86g7WcAkeSdzCeJ1Y1sDlPvJhTPFI4hm3kNUdq4iQTQ4vodo4xPsm9QHfwPWLGaS/DqzCOJ1wyT8mMRbCmRUziSasSR9o5/pCkRlN7ML1xCyjggb0fyAidKX/gQR5HiaxNrawFvxkOImmngDpdH7cjJtzCGqe10MOaTTGyz1XWaTxFyCeN2o1kGaeqHsb/AIM+NOkTtRSByH1rE1eTqUX4LC6VuYJD3pRxBhOX5LwRvNYyi58EHnBL2SBQTX1j8WqibldxpJ+tKHIOGGlYJBRP/wENHAcUqhVuDkfqIPHxF1KRYNN2YtnHpURw5kWy+qVuSwEuhb9LE+s71Y00kaWBCvGw/zC6kN5XwX/4ioZJRSYjKAqrYPlhJ16pY538lW5JnUEcTrxs44WFWWI/kcynKkZrhZWx3sk8CLvZJJsib5Q4wIn78ikQPR0dnfVeRI1XCDyUC2VFKDAOVK1tW5ySWI140qYLzLtVyKc0xfLFL1CqkBZorQgRxnKvfpSugsaRYEO+PI76+fNI9o9CVKSakGdICApAwkSZ9MDkFEPYe86x/C55NuVMpJFyBaXalb971I052FBBGVYPKrOYor2ZbcTSp8nk7IEvmu4srgL57XdGiZBXle8jvgEM26L/aFSQrWAzqBbmSndbCmQwsIIgqM5RpS1HMM+pxSRroCupl8U3DrlZouTSSIWJqwXPaYsRThGqWEdAeWi+hXBSzXdGqaBXmYxX9BZGen3SFWuCmkuTuSLXSVLdVsDdV0agJBvG7sdCxvWz3hOqLS0arzMwXQFXQm43ZNtwlbECxs8kdLsYWC/mYK6Q7oDLrzI0fTbQIE8bqxyvxyqQ3rVrLzVIdnGqCzqQuDWy/XdBy3BZHftoAw+ogLVWdnKqA7fSrkkfgIIpYryG8imPI11cmZDr0O52i6jtmCPCj9hoXUdl1E7SRAh8OnG+s6IkG8biTi5kptSMYp2AOTdCmZuZrOo7Yg90q/DZ4oRMEegC71o8G90RHE60auRc4XT7hWdardUOUKbpmn6T6iBcGblQac/Q3bPlXMUh1qN0CnRdK+PYWa7iMS5FbpN+wJphZX2w/Q6di5wa23GRPE6/48Bb7/JCuHaMylqjPtCmwGmCVtXX6+xoGwFkT2PYZOZcMzRHWkXYH1NMN06Ri3EUHmS7+NmqM60e7Qr5cOQxCvG/NY/1wWOxhXzlYdaHegdlWuOpvEXJgQyoLI1WLY3jq/RHWg3YGFbuW6/MxVkQlSMUN1nmOmvNMjEMTrho35snSIPl6vYFfodf1ljRNnLcg0Fv+eUNi2Qe066BxA1wXSyxOwTGF6IEEulv0PtdmL46DPzVwUSJDZEQ5WsD1BdEbhS4EEkQehwVWqw5yGweODWy4QBPG68e49OZdfOlZ1mOP8EOhcyrlNBDdgQWBb/JESZPjUUkrnATqXs7vgxGQQRB5PStR6F+daEZ3uJ4Ag8uLa4uGqo5yKIt17nc4BQc6RD1IEcS5BhockyEipqXCo6iinolBnQUaCIHLBB7awVHAm8BZyGUNAkGERDlJwLkGGgSDyu8cLlAVRBJEtSKHUlJ2vOsqpyCkIbvEFyuSyQ7UpjHOh130OWmS7kjtAdZRTodd9iTIXCoYAQVqllu4zqlecCr3u20CQXqmpr1d1lFOh130PCCK/wbm3U3WUU9HTEdzSAYK0SE2draqjnIqutuCWYyBIk8yZk6qjnAq97ptAkGOyBVEEcSz0o4fPghyWmk4fVR3lVJxuCm45DILsk5pOHVEd5VTodb9PT5B2RRDnEqQpJEF2Sk1tB1VHORWtOt3vBEFqWLolFnWdUp3lNHSfDrYg4ERNNrk8iI7UyUw6oDrMacB7d0l6h3IduNGfrNsqHdyyS3WY09CyO7jlE3z0E2S99FVzreowp6G5Jrjlw0CCrI1wsILtCaIzCmsDCbIF7unZrzpOhPJoFew8e+k4Lk14NU5oBHF54LH+RTqp6e+q45yCI5uDW/6qcUKqR31LOqRxs+o4p6BxS3DL//b/EEiQ1dIhxz4l6mpXnWd3QMfNO4JbV+sJ4vLUUWA8pJctTP161YF2R8MGoWs/6jQu6CwI8Kr026F1qgPtjkNryYgDwQTxSL8d5WHmTLPqRLsCum36hIw4IBPE5dlGWgTNh74eogPvqY60K6Bb6NiPbRoHwloQ4DfyRdbwRfpUZ9oN0Cl0K+PXwQ2hCPJ7GJ+zvyHD17hBdajtprYbgrO3ZzTdRyCIy9Os80V2eVWH2g27/qj3PYTuI1oQYLn0G+L0LXWqU+2Clp2h8m3LQx0amiAuD8Kosnda+5rqWLtAr8v3NJ1HSRCBZdJvR7aoMgA7ADrU516WhTs8PEFcnnf4U46U7VihOjjTodfhOk3XMRJE4IfSb8e2E9V/rDo5U9HwN6FDIx3HRBCX513+fFdq+5RnQr1dqrMzDdDZtt8Ft76r6ThOggjcz+IPt2Fxzc43VYdn3LTWG7wwqkfTLSVGEJcHlUO/lNpAEFVxljloPURU93pw6y813SZIEP84dVQyV1ufU5vNZAKgo63PBrsFRyP5HrERxOVp0pkjTJdUhDUzhhZ9eOJ+TadklgUBSV7kz7eltloP0fHdSgnpCuim1hPc+ramSzKXIALfosAdiVCJtPEJtVQzHQGdbPx5cLVYi6ZDsoYgLs9n/HmH1NbeQLT5KQpatqeQWsdD6KS9PviLb2s6JKssCEiykoJrRlDXqPeSFVIF6KJBV6LxAuvOE+ul4t1I927SFtacRQ3f++BflXJSDeigRscD6GpJPJeLjyAuD5yOGyV/BGZtyzMqoZdKII0PHcjDfYtPV0JnlCwLApLs4c+bKDDKCodo/TKik2r7iKQDff7Ro8FOKXQzT9MVJZcggiTvaMNNgPfcTrTuYaK2w0ppyQL6Gn2uX+h2d6Rci7UEESSBTZPrCbCVpiJJcsmh3750maYbSi1BBL7H8qzUgjUXa5dqO9coWDOs7Bd9rF+79Jymk4SR1WfWkgavG+/1/i3LzVJ7fgnR7AeJyicphZoJTAY+fowth277bFSmf5OtR196EUSQJMc33yZaKNupPKIZdxGNmqMUawYOf0i06alQdTkIod/C5Ogx61bmEsRvSX5BiNrJtyKa7CaaeIP4WSEO9IkgmC/OodMbhvg7zbIc1hHET5Ifs3xf913lLLYmS4jyipS+YwG2qdz0ZKgIKcDzW3rIbHJYRxA/UW7jT3jSuVJ78QiimfcQlZ2rFB8Nju8RSVF9bgVBj8VMjF9ZdWtrCSJIcgV/vkLB7+fNZndl0nyiqmv5KdSQE3pEYd3sWkVU+yr7Gzq3AhHSm4wq0jODIIIkMBV/YJmu+w6zm2nsrpSOUoQIBMoEUQkWOnWB3MqNiURI04sggiRwOp7yedm6aAyPQBOuZ7lOzHicDITKd74hRA6b9wOhhLviza2kL0H8RHFrHvdg3XfFlUTnfYNoxGxnkgNrjra/JGps9GghUc/hSeYjJZ8ggiRjSFTKfyXk90POI5qywDnBNQwjWPGmX9TUD5R6fivWYp/MJYifKGwu6HGWoSG/H84uy6R5bGsm2JMYSM/XrhTrnkMD1ef3MTFeStUjppYggiQgx09YFlG43NCQKUTjryGqmJn5Mx70NzZv2f0nthg7wkY9WJ5nWcrkSOk74lJPED9RZvDnT1nmhj2maBjRWP567GVEA8ozixhnWsSWT5BThisOsO3GA+G2Y3AuQfxEuZw/H2YJn7jJYkMz7AKi0RcLq5JXnJ6kQH1G40aigx+Irc2NF5phJ4UfJlq/YX+C+IlyFX9+x9Ci9E+RyyczUdgAVXyBqCTF8ZS2Q0yKTWIrc+ziE3qqGog1Psvp8ryVjmpIX4L4iTLd56gRzWcpiHh8QZmY/Qxh0pSNJxo4jii30Jpnw1sxQIgTe9mfqBGzEfmtCWEHHBL7wD3OxNiSzt2f/gTxEwVOB8oIbmU5P6Zzi4aLSG1RhfBjCtkvzh/IZGLJKyHKyReWKEfjH95hj7/8nk7xunK8kRpkONUoKrhAirb6ePayxx602GryxVAbximCmEcWEITnv4SgW7oHS2o1a7GSSfFJpnV1ZhJEJksVf17JcjXLJbAXKX4ihMDfJ/F6ldVMiox+AWDmE0QmCxI5X2T5kvYvT3VoIgWXG5gHeKDYHxT7bPyN5SPfvy6PbbZgshdBQpMGjsV5LMgon6P9O5JE9HaIJnmaA1wUYAXwulgo+liAsPNBezVBJnW79lpZ2+L/BRgAieYEorTRfL4AAAAASUVORK5CYII=");
	}
	.PromoterRank .header .rank .item:nth-of-type(3) .pictrue image {
		margin-left: -64rpx;
	}

	.PromoterRank .header .rank .item .name {
		font-size: 30rpx;
		color: #fff;
		margin-top: 22rpx;
		text-align: center;
		width: 170rpx;
	}

	.PromoterRank .header .rank .item .num {
		font-size: 30rpx;
		color: #fff;
		text-align: center;
	}

	.PromoterRank .list {
		width: 710rpx;
		background-color: #fff;
		border-radius: 20rpx;
		margin: -30rpx auto 0 auto;
		padding: 0 30rpx;
	}

	.PromoterRank .list .item {
		border-bottom: 1px solid #f3f3f3;
		height: 101rpx;
		font-size: 28rpx;
	}

	.PromoterRank .list .item .num {
		color: #666;
		width: 70rpx;
	}

	.PromoterRank .list .item .picTxt {
		width: 350rpx;
	}

	.PromoterRank .list .item .picTxt .pictrue {
		width: 68rpx;
		height: 68rpx;
	}

	.PromoterRank .list .item .picTxt .pictrue image {
		width: 100%;
		height: 100%;
		display: block;
		border-radius: 50%;
	}

	.PromoterRank .list .item .picTxt .text {
		width: 262rpx;
		color: #333;
	}

	.PromoterRank .list .item .people {
		width: 175rpx;
		text-align: right;
		color: var(--view-priceColor);
	}
</style>
